// (function ($) {
//   Drupal.behaviors.autocomplete_entity_ref = {
//     attach: function (context, settings) {
//       var return_ids = {
//         'edit-field-blog-name-co-author-und' : {
//           append : "a_e_r_p_field_blog_name_co_author"
//         },
//         'edit-field-blog-name-editor-und' : {
//           append : "a_e_r_p_field_blog_name_editor"
//         },
//         // 'edit-field-expert-name-und' : {
//         //   append : "a_e_r_p_field_expert_name"
//         // },
//         'edit-field-wiki-read-members-und' : {
//           append : "a_e_r_p_field_wiki_read_members"
//         },
//         'edit-field-wiki-edit-members-und' : {
//           append : "a_e_r_p_field_wiki_edit_members"
//         }
//       };
//
//     	// var return_ids = Drupal.settings.autocomplete_entity_ref.return_ids;
//       console.log(return_ids);
//
//       // close icon
//     	var closeIcon = '';
//     	if( $('body').hasClass("page-node-add")){
//     		closeIcon = '<i class="fa fa-times-circle" title="Remove" aria-hidden="true"></i>';
//     	} else {
//     		closeIcon = '';
//     	}
//
// 	    // Add Item
// 		function addItem(item, key){
//     		var inputWidth = $("#"+key).parent(".input-group").width();
//     		var parentWidth = $("#"+key).parent(".input-group").parent().width();
//     		var labelWidth = $("#"+key).parent(".input-group").prev().outerWidth();
//     		var inputPercent = ((inputWidth) / parentWidth) * 100;
//     		var labelPercent = ((labelWidth) / parentWidth) * 100;
//
//     		var fullString = item.val();
//     		var userFullName = item.val().replace(/ *\([^)]*\) */g, "");
//     		var splitString = item.val().split('(');
//     		var userName = splitString[2].slice(0, -2);
//     		var userEmail = splitString[1].slice(0, -2);
// 			$("#"+ return_ids[key]["append"]).append('<div class="ac-item"><a href="'+ Drupal.settings.basePath +"profile/" + userName +'" target="_blank" title="'+ $.trim(userEmail) +'">'+ "<span class=\"name\">" + userFullName + "</span><span class=\"hidden\">"+ fullString +'</span></a>' + closeIcon +'</div>').css({
// 				"width":Math.round(inputPercent)+"%",
// 				"float":"right"
// 			});
// 			removeItem(key);
//     		item.val("");
//     	};
//
//     	// On Load item
//     	function onLoadItems(items, key){
//
//     		var inputWidth = $("#"+key).parent(".input-group").width();
//     		var parentWidth = $("#"+key).parent(".input-group").parent().width();
//     		var labelWidth = $("#"+key).parent(".input-group").prev().outerWidth();
//     		var inputPercent = ((inputWidth) / parentWidth) * 100;
//     		var labelPercent = ((labelWidth) / parentWidth) * 100;
//
//     		if(typeof $("#"+key).val() !== "undefined" && $("#"+key).val() != ''){
//           var splitValue = items.val().split(",");
//           var html = "";
//           for (var i = 0; i < splitValue.length; i++){
//             var fullString = splitValue[i];
//             var userFullName = splitValue[i].replace(/ *\([^)]*\) */g, "");
//             var splitString = splitValue[i].split('(');
//             var userName = splitString[2].slice(0, -2);
//             var userEmail = splitString[1].slice(0, -2);
//             html += '<div class="ac-item"><a href="'+ Drupal.settings.basePath +"profile/" + userName +'" target="_blank" title="'+ $.trim(userEmail) +'">'+ "<span class=\"name\">" + userFullName + "</span><span class=\"hidden\">"+ fullString +'</span></a>' + closeIcon +'</div>';
//           };
//           $("#"+ return_ids[key]["append"]).append(html).css({
//           "width":Math.round(inputPercent)+"%",
//           "float":"right"
//           });
//           items.val("");
//
// 			}
//     };
//
//     	// Remove Item
//     function removeItem(key) {
//     		$("#"+ return_ids[key]["append"] + " .ac-item .fa").on("click", function(){
// 				$(this).parent().remove();
// 			});
//     };
//
//     	// Submit Form function
//     	function submitForm(key){
// 		    var string = '';
//   			$("#"+ return_ids[key]["append"] +" .ac-item").each(function(){
//   				string += $(this).find(".hidden").text() + ', ';
//   			});
//   			var result = string.substring(0, string.length-2);
//   			$("#"+key).val(result);
//         // .css({
//   			// 	'color':'transparent'
//   			// });
//     	}
//     	// Iterate each item from object
// 		$.each(return_ids, function(key) {
// 			$("#"+key).on('autocompleteSelect', function(){
// 				var item = $(this);
// 				addItem(item, key);
// 			});
//
//       // console.log($("#"+key));
// 			// Append Items On Window load
//
//         var items = $("#"+ key);
//
//     		onLoadItems(items, key);
//     		removeItem(key);
//
//
//     		// Submit Form
// 	    	$('form').on('submit', function () {
// 	    		submitForm(key);
//     		});
// 		});
//     }
//   };
// }(jQuery));
