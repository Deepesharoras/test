SELECT nid, uid , created, COMMENT, title ,TYPE FROM (
SELECT n.nid AS nid, n.uid AS uid, n.created AS created, n.comment AS COMMENT, n.title AS title, n.type AS TYPE
FROM 
node n
WHERE  (n.type IN  ('lesson')) AND (n.status = 1) 


UNION 

SELECT n.nid AS nid, n.uid AS uid, n.created AS created, n.comment AS COMMENT, n.title AS title, n.type AS TYPE
FROM 
node n
INNER JOIN field_data_field_forum_name_forum_type bl ON (n.nid = bl.entity_id  AND bl.field_forum_name_forum_type_value = 'public' )
WHERE  (n.type IN  ('forum_name')) AND (n.status = 1)



UNION 

SELECT n.nid AS nid, n.uid AS uid, n.created AS created, n.comment AS COMMENT, n.title AS title, n.type AS TYPE
FROM 
node n
INNER JOIN field_data_field_is_public cl ON (n.nid = cl.entity_id  AND cl.field_is_public_value = 1 )
WHERE  (n.type IN  ('query')) AND (n.status = 1)



UNION 

SELECT n.nid AS nid, n.uid AS uid, n.created AS created, n.comment AS COMMENT, n.title AS title, n.type AS TYPE
FROM 
node n
INNER JOIN field_data_field_is_public cl ON (n.nid = cl.entity_id  AND cl.field_is_public_value = 1 )
WHERE  (n.type IN  ('query')) AND (n.status = 1)


UNION 

SELECT n.nid AS nid, n.uid AS uid, n.created AS created, n.comment AS COMMENT, n.title AS title, n.type AS TYPE
FROM 
node n
 
WHERE  (n.type IN  ('drupal_wall')) AND (n.status = 1)

) AS  T ORDER BY T.created DESC