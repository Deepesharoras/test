Welcome to Advanced Form Block Module. With this module you can do
the following:

1) Create any number of blocks with a particular node edit form.
2) create any number of blocks with a particular node add form of
   a content type.
3) Create as many blocks as you like of each kind.
4) From  the content type choose which fields to display on a 
   per block basis.However required fields will be automatically
   displayed.
5) All forms will be saved through ajax. So multiple node forms 
   can be independently placed on a single page and worked with 
   simultaneously.
   
Instructions of Use:

1) Download and install the module normally.
2) Click on the "Advanced Form Block Settings" tab on the main menu.
3) Choose a title, block type, and other information.
4) Create a block.
5) now you can find this block in blocks page. Place it in the 
   appropriate region.
6) By default the block shows all the fields and vertical tab options.
7) Go to the Block configuration page and tick out the things that you 
   don't want to show.
8) Save the settings, fill out the content form, hit save.
9) Enjoy the ajaxified Content Creation in drupal Blocks and the power 
   of having multiple node forms on a single page functioning without
   page refresh.
