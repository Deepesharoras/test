<?php
/**
* @file theme  file for community file listing 
*
*/
?>
<?php 
  $communitiname = drupal_get_path_alias('node/'.arg(1));
  $total_count = count(views_get_view_result('filedepot_folderlisting', 'community_files_block', $folderinfo['cid']));
?>
<?php if(og_is_member ('node', $folderinfo['group_nid'])) { ?>
<div class="view-community-content">
<div class="view-header">
   <?php if($total_count > 1 ) { ?>
        <a class='add-form-link btn btn-xs' href='<?php echo $base_url; ?>/communities/<?php echo $communitiname;?>/folder/<?php echo $folderinfo['cid'] ?>'>View all</a>
   <?php } ?>
    <!--  <a class='use-ajax add-form-link btn btn-xs  ctools-model-community-model-add-file' href='<?php echo $base_url; ?>/community_knowledge_repository/ajax/newfile/<?php echo $folderinfo['cid'] ?>'> Add file</a>  -->

   <?php  print ctools_modal_text_button(t('Add file'), 'community_knowledge_repository/nojs/newfile/'.$folderinfo['cid'], t('Add file'),  'ctools-modal-modal-popup-large'); ?>
   
   </div>

<?php
$viewName = 'filedepot_folderlisting';
$display_id = 'community_files_block';
$arg = $folderinfo['cid']; // argument might be an array, i.e array('arg1', 'arg2', 3, arg(0))
print views_embed_view($viewName, $display_id, $arg)

?>
</div>
<?php } ?>