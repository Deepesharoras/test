<?php
/**
  * @file
  * filelisting_record.tpl.php
  */
global $base_url;
$folderclass = '';
if( $hide_folder_column == 'hide'  ) {
   $folderclass = 'fd-folder-class';
}
$folderdetails = '';
if( $hide_folder_column != 'hide'  ) {
   $folderdetails = 'fd-folder-details';
}

?> 
<div class="listing_record" id="folder_<?php print $subfolder_id ?>_rec_<?php print $fid ?>">
        <div class="floatleft table-width-file-depo file-name">
                       
              <span>
                  <?php print $extension_icon ?>
              </span>
              <span class="filedetailslink">
                <?php 
                        if( $show_lock == 'none' ) {
                              echo "<a id='listingFilenameRec$fid' class='filedetailsdialog' href='javascript:void(0)' TITLE='". $file_name ."'>$file_name</a>";
                        } else {
                              echo "<a id='listingFilenameRec$fid' href='javascript:void(0)' class='filelocked' TITLE='".$file_name ."'>$file_name</a>";                                
                        }
                ?>
              </span>
        </div>
          
              
              
              <!-- <?php 
                  //print "<div class='floatleft table-width-file-depo folder-name $folderdetails $folderclass'><a href='#'> $folder_name </a></div>";
                 
              ?>
             -->
            
           
            <?php 
              if( $submitter == FALSE) {
                      if( $show_hide_g_docs_viewer ) {
                            if(in_array($file_ext,array('jpg','png','gif')))
                            {
                                echo "<a href='$base_url/knowledge-repository-view-img-popup/$subfolder_id/$drupal_fid' title='View' target='_blank' class='use-ajax ctools-modal-image-view-in-kr'><i class='fa fa-eye'></i></a>&nbsp;";
                            }else{
                                echo "<a href='$base_url/knowledge-repository-google-docs-view/$subfolder_id/$drupal_fid' title='View' target='_blank'><i class='fa fa-eye'></i></a>&nbsp;";
                            }
                        }
                      if(isset($action1_link)) {
                         echo $action1_link;
                      }
                    ?>
                    
                  <span><?php print $action2_link ?></span>
          <?php }  ?>
       </div>

