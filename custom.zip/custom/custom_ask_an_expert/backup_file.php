<?php
/**
 * @file Ask and exper module main file
 */
module_load_include ( 'inc', 'custom_ask_an_expert', 'custom_ask_an_expert_notification' );
/**
 * Implements hook_menu().
 */
function custom_ask_an_expert_menu() {
    $items = array();
    $items ['ask-an-expert/find-expert'] = array(
            'page callback' => 'find_expert',
            'access callback' => TRUE,
            'type' => MENU_NORMAL_ITEM,
            'file path' => drupal_get_path('module', 'node'),
            'file' => 'node.pages.inc' 
    );
    $items ['ask-an-expert/find-expert/%'] = array(
            'page callback' => 'drupal_get_form',
            'page arguments' => array('node_query_expert_load', 2),
            'access callback' => TRUE,
            'type' => MENU_CALLBACK 
    );
    $items ['ask-an-expert/fetch-keywords'] = array(
            'page callback' => 'keyword_autocomplete',
            'access arguments' => array(2),
            'type' => MENU_CALLBACK 
    );
    
    $items ['accept-comment/%'] = array(
            'page callback' => 'accept_comment',
            'access arguments' => array('access content'),
            'page arguments' => array(1),
            'type' => MENU_CALLBACK 
    );
    $items ['reject-comment/%'] = array(
            'page callback' => 'reject_comment',
            'access arguments' => array('access content'),
            'page arguments' => array(1),
            'type' => MENU_CALLBACK 
    );
    $items ['skills/autocomplete'] = array(
            'title' => 'Autocomplete for skill terms',
            'page callback' => '_skills_autocomplete',
            'access arguments' => array('access content'),
            'type' => MENU_CALLBACK 
    );
    $items ['ask-an-expert/search-queries'] = array(
            'page callback' => 'search_queries',
            'access arguments' => array('access content'),
            'access callback' => TRUE,
            'type' => MENU_CALLBACK 
    );
    return $items;
}


function custom_ask_expert_form($form_state, $variable){
  Global $base_url;
  //Include ctools iff path contains 'nojs' to work, else render page normally  
  $form = array();
  $form['#attributes'] = array('class' => 'custom-search-form');
  $form['#method'] = 'get';
  $form['#action'] = $base_url.'/ask-an-expert/search-queries';
  $form['#info']['filter-keyss'] = array( 'operator' => 'searchby', 'value' => 'keyss');      
  $dropdown_array = array('My Queries', 'Queries Awaiting My Response', 'Answered Queries', 'All Queries');
    if(isset($_GET['searchby'])){
    $searchby = $_GET['searchby']; 
  } else {
    $searchby = ""; 
  }
  if(isset($_GET['combine'])){
    $combine = $_GET['combine']; 
  } else {
    $combine = ""; 
  }
  $form['searchby'] = array(     
       '#type' => 'select',
       '#default_value' => '0',        
       '#options' => $dropdown_array,
       '#default_value' => $searchby,   
      );  


  $form['combine'] = array(
    '#type' => 'textfield',   
    '#size' => 30,   
    '#required' => TRUE,   
    '#default_value' => $combine,    
  );

  $form['combine']['#attributes']['placeholder'] = t('Search Queries');
  $form['submit_button'] = array(
    '#type' => 'submit',
    '#value' => t('Search'),
  );
  return $form;
}


/**
 * Accept Comment
 * Argument $cid (Comment Id)
 */
function accept_comment($cid) {    
    $comment = comment_load($cid);
    $comment->field_is_accepted['und'][0]['value'] = 1;
    $user_id = $comment->uid;
    $user_object = user_load($user_id);
    if(!isset($user_object->field_answers_accepted['und'][0]['value'])) {
      $user_object->field_answers_accepted['und'][0]['value'] = 0;
    }
    $accepted_ans_value = $user_object->field_answers_accepted['und'][0]['value'];
    $accepted_ans_value = $accepted_ans_value + 1;
    $user_object->field_answers_accepted['und'][0]['value'] = $accepted_ans_value;
    user_save($user_object);
    comment_save($comment);
    $alias = drupal_get_path_alias('node/' . $comment->nid);
    drupal_goto($alias);

}

/**
 * Reject Comment
 * Argument $cid (Comment Id)
 */
function reject_comment($cid) {
  $comment = comment_load($cid);
  $comment->field_is_accepted['und'][0]['value'] = 0;
   $user_id = $comment->uid;
    $user_object = user_load($user_id);
    $accepted_ans_value = $user_object->field_answers_accepted['und'][0]['value'];

    if($accepted_ans_value > 0) {
      $accepted_ans_value = $accepted_ans_value - 1;
    }

    $user_object->field_answers_accepted['und'][0]['value'] = $accepted_ans_value;
    user_save($user_object);
  comment_save($comment);
  $alias = drupal_get_path_alias('node/' . $comment->nid);
  drupal_goto($alias); 
}

/**
 * Check if user is expert
 * $pid is profile id
 * $skill_id is skill Id
 */
function check_if_user_is_expert($pid, $skill_id) {
 $profile = profile2_load($pid);  
 $lavel = "";
 if (isset($profile->field_pro_skills_and_expertise)) {
  $skills = $profile->field_pro_skills_and_expertise['und'];
  foreach ($skills as $key => $value) {
    $fcitem = $value['value']; 
    $fc = field_collection_item_load($fcitem, $reset = FALSE);  
    if(isset($fc->field_pro_skill_exp_skill['und'][0]['tid'])) {
     if ($fc->field_pro_skill_exp_skill['und'][0]['tid'] == $skill_id) { 
       $lavel = $fc->field_pro_skill_exp_lvl_of_exp['und'][0]['tid'];
     }  
    }
   }
  }
 if ($lavel == 'Expert') {
  return 1;
 } 
 if ($lavel == 'Beginner') {
  return 2;
 }
 if ($lavel == 'Intermediate') {
  return 3;
 }
}


/**
 * autocomplete helper
 * $string = string for search
 */
function _skills_autocomplete($string) {
  $matches = array(); 

  if ($string) {
    $items = array_map('trim', explode(',', $string));
    $last_item = array_pop($items);
    $prefix = implode(', ', $items);

      $result = db_select('taxonomy_term_data', 'td')
      ->fields('td', array('name'))
      ->condition('vid', '2', '=')
      ->condition('name', '%' . db_like($last_item) . '%', 'LIKE')
      ->execute();
      foreach ($result as $row) {
            if (!in_array($row->name, $items)) {
              $value = !empty($prefix) ? $prefix . ', ' . $row->name : $row->name;
              $matches[$value] = check_plain($value);
            }
      }
  }

  drupal_json_output($matches);
}

/**
 * Find Expert Function
 * $string = string for search
 */
function find_expert() {
 global $user, $base_url;
 $output = array();
 if (arg(0) == 'ask-an-expert') {
  $_SESSION['url'] = 'helpme';
 }
 elseif (arg(0) == 'node') {
   $_SESSION['url'] = 'node';
 }

 $output['admin'] = drupal_get_form('help_me_find_expert_form'); 
 if (isset($_POST['ask_expert_enter_keyword'])) {
   $keywords = $_POST['ask_expert_enter_keyword'];
  }
 elseif (isset($_GET['keywords'])) {
   $keywords = $_GET['keywords'];  
 }
 if (isset($keywords)) {
  // $users = searchUserBykeyword($keywords);

    /*
    to fix a bug reported by Tester
       if($users == 0)
       {
         $output['student'] = "";
       } else {
    */
    $users = "";

    if (!isset($_POST['userlist'])) {
               $users = getExpertByKeywords($keywords);
      }
      if (isset($_POST['userlist'])) {    
        foreach ($_POST['userlist'] as $value) {  
            $userInfo = user_load($value);
            $usersnew[$userInfo->uid] = $userInfo->name;
        }      
     }
    if (isset($usersnew)) {
      unset($users);
      $users = $usersnew;
    } 
   if ((is_array($users)) && (count($users) != 0)) {
     module_load_include('inc', 'node', 'node.pages');
     $node_form = new stdClass;
     $node_form->type = 'query';
     $node_form->language = LANGUAGE_NONE;
     $node_form->uid = $user->uid;  
    // display($node_form);
    $node_query_form = drupal_get_form('query_node_form', $node_form); 

    $userList = "";
    $userIdList = "";
    $users_array = array();
    foreach ($users as $key => $value) {   

      $userInfo = user_load($key);
      if (isset($userInfo->field_first_name['und'][0]['value'])) {
          $fname = $userInfo->field_first_name['und'][0]['value'];
      }
      if (isset($userInfo->field_last_name['und'][0]['value'])) {
          $lname = $userInfo->field_last_name['und'][0]['value'];
      }
      $struser = "<a href='../profile/" . $userInfo->name . "' target='_blank'>";
      $struser .= ucwords($fname)." ".ucwords($lname);
      $struser .= "</a> ";
      if(isset($value['name'])){
      $userList .=  $value['name'] . ",";
      }
      $userIdList.=  $key . ",";
      $users_array[$key] = "$struser";

     }

  $userIdList = substr($userIdList, 0, -1);
  $userList = substr($userList, 0, -1); 
  $defaults = array_keys($users_array);
    
  //display($node_query_form);
 
  $node_query_form['userlist']['#options'] = $users_array;
  $node_query_form['userlist']['#default_value'] = $defaults;
  $node_query_form['userlist']['#value'] = $defaults; 

  $node_query_form['field_expert_name']['#access'] = FALSE;
  // display($node_query_form['userlist']);  
  // display($node_query_form['userlist']);

  $node_query_form['#action'] .= "&keywords=" . $keywords;
  $output['student'] = $node_query_form;
 } 
 else {
  form_set_error('ask_expert_enter_keyword', 'Please enter some other Keywords, No expert found matching the given skills.');
   return $output;
  }
 }
return $output;
}

/**
 * Implementation of hook_form_alter
 * @param type $form
 * @param type $form_state 
 * @param type $form_id 
 */
function custom_ask_an_expert_form_alter(&$form, $form_state, $form_id) {
  $form['title']['#maxlength'] = 1500;
   if ($form_id == 'query_node_form') { 
      /* Tab Indexing of fields */
      $form['field_expert_name']['und']['#attributes'] = array( 'tabindex' => '1' );
      $form['title']['#attributes'] = array( 'tabindex' => '2' );       
      $form['field_query_tags']['und']['#attributes'] = array( 'tabindex' => '4' );
      $form['field_query_attachment']['#attributes'] = array( 'tabindex' => '3'  );
      $form['field_query_attachment']['und'][0]['#process'][] = 'query_custom_file_upload';
      $form['body']['und'][0]['#attributes'] += array('data-maxLength' => 1500,'tabindex' => 3);
      $form['field_expert_name']['#suffix'] = "<div id='a_e_r_p_field_expert_name'></div>"; 
          $form['actions']['submit']['#attributes']  = array(
          'tabindex' => '5',
      );

      if (arg(0) == 'ask-an-expert') {
        $_SESSION['urlpage'] = 'helpme'; 
      }
      elseif (arg(0) == 'node') {
        $_SESSION['urlpage'] = 'node';
      }
      if (isset($_GET['keywords'])) {
        $_SESSION['keywords'] = $_GET['keywords'];
      }
   
      global $user;
      $form['author']['name']['#default_value'] = $user->name;
      $form['field_query_attachment']['und'][0]['#description'] = '';
      // $form['body']['und'][0]['#type'] = 'textarea';
      $form['field_query_tags']['#suffix'] = t('<div class="form-item form-group"><div class="help-text small">Use commas(,) to separate multiple tags. Tags should be minimum of 3 characters and maximum of 50 characters. No numerals allowed.</div></div>');

      $form['title']['#description'] = '<a href="#" data-toggle="tooltip" title="' . t('The length of query title should be minimum 3 and maximum 255 characters. It can be alphanumeric but should not contain special characters.') . '"><i class="fa fa-question-circle" aria-hidden="true"></i></a>';

      $form['field_query_attachment'] [LANGUAGE_NONE] [0] ['#description'] = '<a href="#" data-toggle="tooltip" title="The attachment size can be up to 10MB. Only files with the following extensions are allowed: txt, ppt, pdf, jpg, jpeg, flv, mpeg, pptx, pps, ppsx, doc, docx, xls, xlsx, png."><i class="fa fa-question-circle" aria-hidden="true"></i></a>';

    if (($_SESSION['urlpage'] == 'helpme')) {
     if (isset($_POST['ask_expert_enter_keyword'])) {
        $keywords = $_POST['ask_expert_enter_keyword'];
        $_SESSION['keywords'] = $keywords;
      } 
      elseif (isset($_GET['keywords'])) {
         $keywords = $_GET['keywords'];
         $_SESSION['keywords'] = $keywords;
      } 
      elseif (!isset($keywords)) {
        $keywords = $_SESSION['keywords'];
      }
    $users = getExpertByKeywords($keywords); 
    if ($keywords!='') {
        if (count($users) == 0) {
            form_set_error('ask_expert_enter_keyword', 'No expert found matching the given skills.');
            return;
        }
    }

   if (((isset($_POST['ask_expert_enter_keyword'])) && (arg(0) == 'ask-an-expert'))||((arg(2) == 'field_query_attachment'))) {
    // $form['#prefix'] = '<div class="query-form-wrapper"><h1 class="page-header">Post Query</h1>';
    // $form['#suffix'] = '</div>';    
    $userList = "";
    $userIdList = "";
    $users_array = array();
    foreach ($users as $key => $value) { 
      $userInfo = user_load($key);
      if (isset($userInfo->field_first_name['und'][0]['value'])) {
          $fname = $userInfo->field_first_name['und'][0]['value'];
      }
      if (isset($userInfo->field_last_name['und'][0]['value'])) {
          $lname = $userInfo->field_last_name['und'][0]['value'];
      }
      $struser = "<a href='../profile/" . $userInfo->name . "' class='expert-img' target='_blank'>";

     if (isset($userInfo->field_user_image['und'][0]['uri'])) {
         $uri = $userInfo->field_user_image['und'][0]['uri'];
     } 
     else {
       $uri = "public://default_images/default-img.png";   
     } 
     $style = 'simplecrop'; 
     $style_url = image_style_url($style, $uri);
     if (isset($style_url)) { 
         $style_url = $style_url;
     }
     else{
         $uri = "public://default_images/default-img.png";   
         $style = 'simplecrop'; 
         $style_url = image_style_url($style, $uri);
     }



      global $base_url;
      global $theme_path;
      $struser .= "<img typeof='foaf:Image' class='img-circle' src='$style_url' alt=''>";
      $struser .= ucwords($fname) . " " . ucwords($lname);
      $struser .= "</a> ";
       $icon_img ="";
     if($value['lvl'] == 'Expert'){
      $icon_img="expert-icon.png";
     }

     if($value['lvl'] == 'Intermediate'){
      $icon_img="Intermediate-icon.png";
     }

     if($value['lvl'] == 'Beginner'){
      $icon_img="beginner-icon.png";
     }

    // $struser .= "<span class='imgiconlvl'><img typeof='foaf:Image' class='img-circle' src='$base_url/$theme_path/images/$icon_img' alt=''></span>";


      $userList .=  $value['name'] . "[".$value['lvl']."],";
      $userIdList.=  $key . ",";
      $users_array[$key] = "$struser";

     }
    $userIdList = substr($userIdList, 0, -1);
    $userList = substr($userList, 0, -1); 
    $defaults = array_keys($users_array);
    $form['userlist'] = array(
      '#title' => t('Experts'),
      '#type' => 'checkboxes',
      '#options' => $users_array,
      '#default_value' => $defaults,      
    ); 
   $form['field_expert_name']['#access'] = FALSE;
 }
 
 // unset($form['field_expert_name']);
 $form['#validate'] = array('query_form_validate');
 
 } 
elseif ((!isset($_POST['ask_expert_enter_keyword'])) && (arg(0) == 'ask-an-expert'))  {
  hide($form);
}

  $current_user_roles = $user->roles;
  if (!in_array('administrator', $current_user_roles)) {
    $form['field_is_closed']['#access'] = FALSE;
    $form['field_closing_remark']['#access'] = FALSE;
    $form['field_is_public']['#access'] = FALSE;
  }
 $form['#action'] .= '?destination=ask-an-expert';
 $form['#validate'] = array('query_form_normal_validate');
 
  $form['actions']['submit']['#submit'][] = 'email_notification_new_update_query';
  $form['actions']['submit']['#value'] = t('Submit');
  $destination = 'ask-an-expert';
  $form['actions']['cancel'] = array(
      '#markup' => l(t('Cancel'), $destination, array('attributes' => array('class' => array('btn btn-default form-cancel')))),
      '#weight' => -100,
  );
  $form['actions']['reset'] = array(
     '#type' => 'button',
     '#button_type' => 'reset',
     '#value' => t('Reset'),
     '#weight' => -99,
  );
// display($form);
}
if ($form_id == 'comment_node_lesson_form') {
    $form_state['input'] = array();
    $form_state['rebuild'] = TRUE;
    $form['#validate'][] = 'comments_lessons_validate';
}

if ($form_id == 'comment_node_query_form') {
  $form_state['input'] = array();  
  $form_state['rebuild'] = TRUE;
  $form['author']['#access'] = FALSE;
  $form['#validate'][] = 'comments_expert_validate';
    
  if ($_SERVER['HTTP_REFERER'] == '') {
    $previous_uri = 'ask-an-expert';
  } 
  else {
    $previous_uri = $_SERVER['HTTP_REFERER'];
  }

   $nid = arg(1);
   Global $base_url;
   $alias = $base_url ."/". drupal_get_path_alias('node/' . $nid);

   if($nid == 'ajax'){
     $nid = $form['#node']->nid;
     Global $base_url;
     $alias = $base_url ."/". drupal_get_path_alias('node/' . $nid);
   }

   $strstr = strstr($form['actions']['submit']['#ajax']['wrapper'], '0-0');
    if(is_string($strstr)){
        $form['actions']['cancel'] = array(
           '#markup' => l(t('Cancel'), $alias, array('attributes' => array('class' => array('btn btn-default')))),
           '#weight' => 20,
      );
    }

 } 

 if ($form_id == 'views_exposed_form') {
    $view = $form_state['view']; 
    if (($view->name == 'ask_an_expert') && ($view->current_display != 'block_2') && ($view->current_display != 'block_3') && ($view->current_display != 'block_4')) {
     /* $form['combine']['#field_prefix']='<i class="icon-append fa fa-search"></i>'; */
      $form['combine']['#attributes']['placeholder'] = t('Search Queries');
       $new_form_info = array(     
      'searchby' => array('value' => 'searchby'),
       'filter-combine' => $form['#info']['filter-combine'],
      );
      $form['#info'] = array_merge($new_form_info, $new_form_info);  
    }
    global $base_url;
     $view = $form_state['view'];
     if (($view->current_display != 'block_2') && ($view->current_display != 'block_3') &&($view->current_display != 'block_4') && ($view->name == 'ask_an_expert')) {
      $form['#action'] = $base_url . '/ask-an-expert/search-queries';      
      $form['#info']['filter-keyss'] = array( 'operator' => 'searchby', 'value' => 'keyss');      
      $dropdown_array = array('My Queries', 'Queries Awaiting My Response', 'Answered Queries', 'All Queries');     
      $form['searchby'] = array(     
           '#type' => 'select',
           '#default_value' => '0',        
           '#options' => $dropdown_array,
          );  
     }
    if ($view->name == 'ask_an_expert' && $view->current_display=='block_2') {
       $dropdown_array = array('My Queries', 'Queries Awaiting My Response', 'Answered Queries', 'All Queries');
     //  $form['status']['#options'][2] = 'Queries Awaiting My Response'; 
       $form['status']['#options'][2] = 'Queries Awaiting My Response';  
       $form['status']['#options'][1] = 'My Queries';
       unset($form['status']['#options'][0]);
     }     
    }
  if (arg(2) == 'edit') {  
    if (isset($form_state['node']->field_is_closed['und'][0]['value'])) {
     if ($form_state['node']->field_is_closed['und'][0]['value'] == 1) {
        drupal_set_message(t('Oops! it seems you are editing a Closed Query.'));
        drupal_goto('ask-an-expert');
        drupal_access_denied();
       }
    }
  }
}


// Below two functions are for upload file error checking
function validatequeryCustomFileUpload($form,$form_state){    
    if($form_state['values']['field_query_attachment']['und'][0]['fid'] <= 0)
      {
        form_set_error('field_query_attachment', t('Please select a file before upload.'));        
      }
}
  
function query_custom_file_upload($element, &$form_state, $form){
    $element = file_managed_file_process($element, $form_state, $form);    
    $element['upload_button']['#submit'][] = 'validatequeryCustomFileUpload';
    return $element;
}

/**
 * Implements hook_node_insert().
 */
function custom_ask_an_expert_node_insert($node) {
   global $user; 
   if ($node->type =='query' && $node->is_new) {
       
      email_on_query_create( $node->nid );


      $form_state['values']['userId'] = $user->uid;
      $nid = $node->nid;
      $notify_users[] = $user->uid;

      foreach ($node->field_expert_name['und'] as $key => $value) {
        $notify_users[] = $value['target_id'];
      }

      $headernotification = array();
      foreach ($notify_users as $key => $value) {
      $headernotification[] = array(
          'sender_id' => $user->uid,
          'receiver_id' => $value,
          'module_type' => 'ask_an_expert',
          'nt_type'   => 'QUERY_CREATE',
          'entity_type' => 'node',
          'entity_id' => $nid,
          'created'  => REQUEST_TIME,
          'nt_info' => 'info',
          'other_val' => NULL,
              
      ); 
     }

    if (!empty($headernotification)) {
     save_user_notification($headernotification);
    }       
     //   email_on_query_update( $form_state['values'] );
      //common_notification( $form_state['values'] , 'created_published' );


   }
 }

/* 
* * A function to return comments Count 
* * $nid is node id for which we want the comments counts
*/
function email_notification_new_update_query($form,$form_state) { 
   global $user;
 
  if (arg(2) == 'edit') { 
     email_on_query_update( $form_state );
     $form_state['values']['userId'] = $user->uid;
     $nid = $form_state['values']['nid'];
     

      $notify_users[] = $user->uid;
      foreach ($form_state['values']['field_expert_name']['und'] as $key => $value) {
        $notify_users[] = $value['target_id'];
      }

      $headernotification = array();
      foreach ($notify_users as $key => $value) {
      $headernotification[] = array(
          'sender_id' => $user->uid,
          'receiver_id' => $value,
          'module_type' => 'ask_an_expert',
          'nt_type'   => 'QUERY_UPDATED',
          'entity_type' => 'node',
          'entity_id' => $nid,
          'created'  => REQUEST_TIME,
          'nt_info' => 'info',
          'other_val' => NULL,
      ); 
     }
     if (!empty($headernotification)) {
       save_user_notification($headernotification);
     }  

     //common_notification( $form_state['values'] , 'updated_published' );
   }
}

/* 
* * A function to return comments Count 
* * $nid is node id for which we want the comments counts
*/
function get_comments_count($nid) {
  $comment_count = db_query( 'SELECT COUNT(cid) FROM {comment} WHERE status = :one AND nid = :nid ',
  array
      (
        ':one' => 1,
        ':nid' => $nid,
        //':pid' => 0,
      )
    )->fetchField();
    return $comment_count; 
}

/**
 * Implements hook_form_validate().
 */
function comments_lessons_validate($form, &$form_state) {
  global $user;
 
  $nodeInfo = node_load($form['#node']->nid);
  $val = $nodeInfo->comment; 
   if($val == 1) {
       form_set_error('comment_body', 'Lesson is locked.');
     return TRUE;
   }
}



/**
 * Implements hook_form_validate().
 */
function comments_expert_validate($form, &$form_state) {
   global $user;     
   $userList = array();
   foreach ($form['#node']->field_expert_name['und'] as $key => $value) {
     $userList[] = $value['target_id'];
   }
   $userList[] = $form['#node']->uid;
    if (!in_array($user->uid, $userList)) { 
     form_set_error('comment_body', 'You are not authorized to comment on this query.');
     return TRUE;
   } 

 
   $nodenewInfo = node_load($form['#node']->nid);
   $val = $nodenewInfo->field_is_closed['und'][0]['value'];

   if ($val == 1) { 
    form_set_error('comment_body','This Query has been closed.');
     return TRUE;
   }
   if (!isset($nodenewInfo->field_is_closed['und'][0])) { 
    form_set_error('comment_body','This Query has been closed.');
     return TRUE;
   }  
}

/**
 * Implements hook_node_presave().
 */
function custom_ask_an_expert_node_presave($node) {
  global $user;
  $node_type = $node->type;
  switch ($node_type) {
    case 'query':
     if ($node->field_is_closed['und'][0]['value'] == 1) {
        $node->comment = 1;
     } 
     elseif ($node->field_is_closed['und'][0]['value'] == 0) {
       $node->comment = 2;
     }  
     elseif (!isset($node->field_is_closed['und'][0]['value'])) {
       $node->comment = 2;
     }
    break;
  }
}
/**
  *  Implements function to get all matching terms 
  *
  * @param
  *   String $arg 
  *
  * @return
  *   Form to add query
  */
function keyword_autocomplete($text) {
  $results = array();
  // get all terms from skills
  $vocab_name = 'Skills';
  $vid = kmsGetVocabDetailByName($vocab_name, array('vid'));
  $vid = $vid['vid'];
  $taxonomy_tree = taxonomy_get_tree($vid); 
  drupal_json_output($taxonomy_tree);
}

/**
  *  Implements function to get query node form
  *
  * @param
  *   String $arg 
  *
  * @return
  *   Form to add query
  */
function node_query_expert_load($arg) {
  module_load_include('inc', 'node', 'node.pages');
  $node_form = new stdClass;
  $node_form->type = 'query';
  $node_form->language = LANGUAGE_NONE;
  $form = drupal_get_form('query_node_form', $node_form);
  return $form;
}

/**
  *  test function 
  *
  Commented on 23 May delete next time not looking useful
function test_function($arg){
 module_load_include('inc', 'node', 'node.pages');
 $node_form = new stdClass;
 $node_form->type = 'query';
 $node_form->language = LANGUAGE_NONE;
 $form2 = drupal_get_form('query_node_form', $node_form);
 return $form2; 
}

*/

/**
  *  Implements function to get term ID by name
  *
  * @param
  *   String $term_name name of the term to search for
  *   String $vocab_name (optional) vocabulary machine name to look into
  *
  * @return
  *   Array of matched term ID's
  */
 function kmsGetTermIdFromName($term_name = NULL, $vocab_name = NULL) {
    if (is_null($term_name)) {
      return 0;
    }
    $terms_array = taxonomy_get_term_by_name($term_name, $vocab_name);
    if (count($terms_array) > 0) {
      return array_keys(taxonomy_get_term_by_name($term_name, $vocab_name));
    } 
    else {
      return 0;
    }
  } 

/**
   * Function to return term id.
   *
   * @param
   *   String term name
   * @param
   *   String Vocabulary Name to look into (Not Machine name)
   *
   * @return
   *   Number term ID
   */
  function kmsGetTermID($term_name, $vocab_name) {
    $vocab_det = array('vid', 'machine_name');
    $vocab_det_ary = $this->kmsGetVocabDetailByName($vocab_name, $vocab_det);
    $vocab_mac_name = $vocab_det_ary['machine_name'];
    $tid_ary = $this->kmsGetTermIdFromName($term_name, $vocab_mac_name);
    return $tid_ary[0];
  }


/**
   * Implements function to fetch vocabulary detail.
   *
   * @param
   *   String $vocab_name Name of the vocabulary
   * @param
   *   Array $detail array of details to be fetched.
   *   ex. array(vid, name, machine_name, description, language, i18n_mode, weight)
   *
   * @return
   *   Array associative array of values, returns full array for the vocabulary if $detail
   *   is blank array.
   */
  function kmsGetVocabDetailByName($vocab_name, $detail = array()) {
    if ($vocab_name == '') {
      return array();
    }

    $output = array();
    $vocabs = taxonomy_get_vocabularies();

    foreach ($vocabs as $val) {
      if ($val->name == $vocab_name) {
        $output = $val;
        unset($val);
        break;
      }
    }

    if (!count($detail)) {
      return $output;
    }

    $tmp = array();
    foreach ($detail as $val) {
      $tmp[$val] = $output->$val;
    }

    return $tmp;
  }

/**
   * Implements function to fetch users array.
   *
   * @param
   *   String $field_value 
   *
   * @return
   *   Array associative array of values, returns full array of users
   *
   */
function kms_get_user_by_prfoile2field($field_value) {
    $user = new stdClass();
    $user_array = db_select('field_data_field_pro_skill_exp_skill', 'ui')
        ->fields('ui', array('entity_id'))
        ->condition('field_pro_skill_exp_skill_tid', $field_value, '=')
        ->execute()
        ->fetchAllKeyed(0, 0); 
    $user_array = array_unique($user_array);
    return $user_array;
}

/**
 * Implements function to return experts
 */
function help_me_find_expert_form($form, &$form_state) {
   $form = array();
   if (isset($_GET['keywords'])) {
    $keywords = $_GET['keywords'];
   } 
   else {
    $keywords = "";
   }
    $form['ask_expert_enter_keyword'] = array(
    '#type' => 'textfield',
    '#title' => t('Enter Keyword'),
    '#description' => t('Enter your query / keywords to get help in finding the experts.'),
    '#size' => 40,
    '#required' => TRUE,
    '#default_value' => $keywords,
    '#autocomplete_path' => 'skills/autocomplete',
    '#description' => '<a href="#" data-toggle="tooltip" title="' . t('Enter the skills as keyword to get help in finding the expert(s).') . '"><i class="fa fa-question-circle" aria-hidden="true"></i></a>'
  ); 
 
  /* 
  // Testing purpose to print users

  if(!empty($form_state['temporary'])) {
      
    $str = implode (", ", $form_state['temporary']);
        $form['results'] = array(
            '#type'     => 'item',
            '#markup'   => $str, 
        );
        
  }
 */
  $form['submit'] = array(
    '#type' => 'submit',
    '#value' => t('Search'),
    '#prefix' => '<div class="btncl">',
    '#suffix' => '</div>',
  );

  return $form;
}

/**
 * Implents Hook form Validate
 */
function query_form_normal_validate($form, &$form_state) {
    global $user;
    $form_errors = form_get_errors();
    $drupal_errors = drupal_get_messages('error');
    form_clear_error(); 
    $user_array = array();
    if  (!isset($form_state['values']['userlist'])) {
        $userList = $form_state['values']['field_expert_name']['und'];
        $invalidexpert = 0;
        foreach ($userList as $key => $value) {
            if (!isset($value['target_id'])) {
                $invalidexpert = 1;
            }
            if ($value['target_id'] == 0) {
                $invalidexpert = 1;
            }
            $user_array[] = $value['target_id']; 
        }
    } 
    else {

      $invalidexpert = 0;
      $newuserarray = array();
      $userList = $form_state['values']['userlist'];
      $invalidexpert = 1;
      foreach ($userList as $key => $value) {
         $user_array[] = $value;  
         if ($value != 0) {
            $newuserarray[]['target_id'] = $value;
            $invalidexpert = 0;
           }
         }
        $form_state['values']['field_expert_name']['und'] = $newuserarray;
    }
    if (in_array($user->uid, $user_array)) { 
       if (count($user_array) > 0) {
          form_set_error('field_expert_name', 'You can not ask a question to yourself.');
          return TRUE;
       }
     } 
 
    if ($invalidexpert == 1) {
      form_set_error('field_expert_name', 'No expert found for the provided keyword. Please search for the expert(s) using a different keyword.');
      return TRUE;
    } 
    $form_state['values']['title'] = trim($form_state['values']['title']);
    $experts_count = count($user_array);
    $query_title = trim($form_state['values']['title']); 
    if ($experts_count == 0) {
      form_set_error('field_expert_name', 'No expert found for the provided keyword. Please search for the expert(s) using a different keyword.'); 

        $form_state['values']['field_expert_name']['und'][0]['value']['#value'] = 'foo';
    }
    if (empty($query_title) || $query_title == '') {
          form_set_error('title', 'Please enter the query title of length 3 - 255 characters. Only alphanumeric characters are allowed.'); 
    }
    if (isset($query_title)) {
      if ((strlen($query_title) > 255)) {
          form_set_error('title', 'Please enter the query title of length 3 - 255 characters. Only alphanumeric characters are allowed.');
      }
    }
    if (isset($query_title)) {
      if ((strlen($query_title) < 3)) {
          form_set_error('title', 'Please enter the query title of length 3 - 255 characters. Only alphanumeric characters are allowed.');
      }
    }
    if (preg_match('#(?<=<)\w+(?=[^<]*?>)#', $query_title)) {
          form_set_error('title','Special characters are not allowed in query title. Only alphanumeric characters are allowed.');
    }
    if(preg_match('/[^@?,a-z0-9 _-]+/i', $query_title)) {
           form_set_error('title', 'Special characters are not allowed in query title. Only alphanumeric characters are allowed.');
    } 
    if (is_numeric($query_title)) {
          form_set_error('title', 'Please enter the query title of length 3 - 255 characters. Only alphanumeric characters are allowed.');
    }  

    $body_description = strip_tags($form_state['values']['body']['und'][0]['value']);
    $body_description = str_ireplace('<p>', '', $body_description);
    $body_description = str_ireplace('</p>', '', $body_description);  

    if (trim($body_description) == '') {
        form_set_error('body', 'Please enter the query description of length 50-1500 characters.');
    }
    if (strlen($body_description) > 1500) {
        form_set_error('body', 'Please enter the query description of length 50-1500 characters.');
    }
    if (strlen($body_description) <= 50) {
        form_set_error('body', 'Please enter the query description of length 50-1500 characters.');
    }
      
   if (isset( $body_description )) {    
    $body_description = str_replace('&nbsp;', ' ', $body_description); 
    $arr_body_value = explode(' ', $body_description );
     foreach ( $arr_body_value as $value ) {
      if (strlen( $value ) >= 55) {
        form_set_error( 'body', "In Query Description word $value exceeding 55 characters." );
      }
     }
    }
    
    $tags_array = $form_state['values']['field_query_tags']['und'];
    $tags_count = count($tags_array);
    if ($tags_count > 20) {
        form_set_error('field_query_tags', 'The tags should not be more then 20.');
    }
    if ($tags_count == 0) {
        form_set_error('field_query_tags', 'Please enter the tags.');
    }
    $lenth_error = 0;
    $tag_error = 0;
    foreach ($tags_array as $key => $value) {       
       $name = $value['name'];
       if (strlen($value['name']) > 50) {
           $lenth_error = 1;
       } 
       if (strlen($value['name']) < 3) {
           $lenth_error = 3;
       }
       if (preg_match('/[^a-z0-9 _]+/i', $value['name'])) {
           $tag_error = 1;
       } 
       if (is_numeric($value['name'])) {
           $tag_error = 5;
       } 
     } 
     if ($lenth_error == 3) {
        form_set_error('field_query_tags', 'Please enter the tags of length 3 - 50 characters.');
     }
     if ($lenth_error == 1) {
        form_set_error('field_query_tags', 'Please enter the tags of length 3 - 50 characters.');
     }
     if ($tag_error == 1) {
        form_set_error('field_query_tags', 'Tags should not have special characters.');
     }
     if ($lenth_error == 4) {
        form_set_error('field_query_tags', 'Tags should not contain multiple spaces.');
     }
     if ($tag_error == 5) {
        form_set_error('field_query_tags', 'Tags should not be numeric in nature.');
     }
}

/**
 * Implents Hook form Validate
 */
function query_form_validate($form, &$form_state) {
    global $user;
    $userList = $form_state['values']['userlist']; 
    unset($form_state['values']['field_expert_name']['und']); 
    $chk = 0;
    foreach ($userList as $key => $value) {
        if ($value == $user->uid) {
           $expertself = 1;
        }
        if ($value != 0){
            $form_state['values']['field_expert_name']['und'][]['target_id'] = $value;     
            $chk++;
        } 
    } 
    
    if ($chk == 0) {
      form_set_error('field_expert_name', 'Please select at least one expert.');
      return TRUE;
    }
    if ($expertself == 1) {
        form_set_error('field_expert_name', 'You can not ask a question to yourself, Please remove your name.');
        return TRUE;
    } 

/*
  $experts = $form_state['values']['custom_field_experts_list'];
  $experts_ori = $form_state['values']['field_expert_name']; 

  $experts_hidden = $form_state['values']['custom_field_experts_hidden'];
  $users = explode(",", $experts_hidden);
  foreach ($users as $userId) {
    $airport_tid[] = array('target_id' => $userId);
  }
  $form_state['values']['field_expert_name']['und'] = $airport_tid; 
*/
}
/**
 * Implents Hook form Validate
 */
function help_me_find_expert_form_validate($form, &$form_state) {
  $keywords = $form_state['values']['ask_expert_enter_keyword'];


  $users = getExpertByKeywords($keywords);
  $termId =  kmsGetTermIdFromName($keywords, 'skills'); 
  if (count($users) == 0) {
      form_set_error('ask_expert_enter_keyword', 'No expert(s) found with entered skills.');
        return;
    } 
  if ($termId == 0) {
       form_set_error('ask_expert_enter_keyword', 'No expert(s) found with entered skills.');
        return;
  } 
  if (isset($termId[0])) {
     $termId = $termId[0];
  }
  if (is_numeric(($termId[0]))) {
          form_set_error('ask_expert_enter_keyword', 'No expert(s) found with entered skills.');
          return TRUE;
    } 
  if (empty($keywords)) {
          form_set_error('ask_expert_enter_keyword', 'No expert(s) found with entered skills.');
    }
}

/**
    * Implements function to fetch users array.
    *
    * @param
    *   String $keywords 
    *
    * @return
    *   Array associative array of values, returns full array of users
    *
    */
function getExpertByKeywords($keywords) {
    global $user;
    $termId = kmsGetTermIdFromName( $keywords, 'skills' );
    $getUserProfiles = kms_get_user_by_prfoile2field( $termId [0] );
    $users_array = array();
    $pid = array();
    $uid_array = array();
    foreach ( $getUserProfiles as $value ) {
        $fc = field_collection_item_load ( $value );
        $item_id = $fc->item_id;
        $query = db_select ( 'field_data_field_pro_skills_and_expertise', 'pses' )->fields ( 'pses', array (
                'entity_id' 
        ) )->condition ( 'field_pro_skills_and_expertise_value', $item_id, '=' );
        $result = $query->execute ()->fetchAll ();
        foreach ( $result as $value ) {
            $pid [] = $value->entity_id;
        }
    }


    if (count ( $pid ) > 0) {
        $profile_array = array_unique ( $pid );        
        $get_user_query = db_select ( 'field_data_field_pro_skills_and_expertise', 'pses' )->fields ( 'pses', array (
                'entity_id' 
        ) )->condition ( 'field_pro_skills_and_expertise_value', $item_id, '=' );
        
        $result = $query->execute ()->fetchAll ();
        foreach ( $result as $value ) {
            $pid [] = $value->entity_id;
        }
        
        $pid = array_unique ( $pid );

        foreach ( $pid as $profile_id ) {

            $get_user_query = db_select ( 'profile', 'pfl' )->fields ( 'pfl', array (
                    'uid',
                    'pid' 
            ) )->condition ( 'pid', $profile_id, '=' )->condition ( 'uid', $user->uid, '!=' );
            
            $result_users = $get_user_query->execute ()->fetchAll ();
            foreach ( $result_users as $users ) {
                
                $user_details = db_select ( 'users', 'usr' )->fields ( 'usr', array (
                        'name' 
                ) )->condition ( 'uid', $users->uid, '=' )->execute ()->fetchAssoc ();

                if(isset($user_details ['name'])){
                  $user_name = $user_details ['name'];
                  $check = check_if_user_is_expert ( $users->pid, $termId [0] );
                  $uid_array [$users->uid] ['name'] = $user_name;
                  $uid_array [$users->uid] ['skill_lavel'] = $check;
                }
            }
        }
    }


 
    $uid_array_new = array ();
    if (count ( $uid_array ) > 0) {
        $uid_array_calculated = user_score_calculation ( $uid_array );
        $output = array_slice ( $uid_array_calculated, 0, 20, true );
        foreach ( $output as $key => $value ) {
            $user_details = db_select ( 'users', 'usr' )->fields ( 'usr', array (
                    'name' 
            ) )->condition ( 'uid', $key, '=' )->execute ()->fetchAssoc ();
            $user_name = $user_details ['name'];
            $uid_array_new [$key]['name'] = $user_name;
        }
    }

    foreach ($uid_array_new as $key => $value) {
      unset($skill_name_arr);
      $user_data = user_load($key);
      $skill_expert_data = profile2_load_by_user($user_data,'skill_and_expertise');
      $skills = $skill_expert_data->field_pro_skills_and_expertise['und'];

      if(isset($skills)){
       foreach($skills as $skills_value){
        $skill_val_data[] = $skills_value['value'];
       } 
      }
      
      $skill_arr_all = field_collection_item_load_multiple($skill_val_data);
      foreach($skill_arr_all as $skill_name_val ) {
        unset($skill_name_arr);        
        $term = taxonomy_term_load($skill_name_val->field_pro_skill_exp_lvl_of_exp['und'][0]['tid']);         
        $skill_name_arr[] = $term->name;
      }
 
      if($skill_name_arr[0] == 'Expert'){ $lvl_sort = 1; }
      if($skill_name_arr[0] == 'Intermediate'){ $lvl_sort = 2; }
      if($skill_name_arr[0] == 'Beginner'){ $lvl_sort = 3; }

      $uid_array_new [$key]['lvl'] = $skill_name_arr[0];
      $uid_array_new [$key]['lvl_sort'] = $lvl_sort;
 

      @uasort($uid_array_new, "cmp");
     
  }
 
 return $uid_array_new;
}

function cmp($a, $b)
{
  $p1 = $a['lvl_sort'];
  $p2 = $b['lvl_sort'];
  return (float)$p1 > (float)$p2;
}

/**
 * Implements function to fetch users array.
 *
 * @param
 *            Array uid_array
 *            
 * @return Array associative array of values, returns full array of users
 *        
 */
function user_score_calculation($uid_array) {
   foreach ( $uid_array as $key => $value ) {
        $userId = $key;
        // change here
        if ($value ['skill_lavel'] == 1) {
            $skill_percent = 10;
        }
        if ($value ['skill_lavel'] == 2) {
            $skill_percent = 2;
        }
        if ($value ['skill_lavel'] == 3) {
            $skill_percent = 6;
        } else {
           $skill_percent = 0;
        }
        
         // $score = getscorebyId ( $userId );
         $score = get_user_current_score ( $userId );
         $total = round ( $skill_percent + $score );
        
        $uid_array_new [$userId] = $total;
    }
    arsort ( $uid_array_new );
    return $uid_array_new;
}

/**
 * Function to get User score by Id
 */
function get_user_current_score($uid) {

        $userId = $uid;
        $year_of_exp = 5;
        $num_projects = 10;
        $profile_completeness_score = score_percentage ( $userId );


        $profile_completeness = ($profile_completeness_score) * .2;

        $sql_comments = db_select ( 'comment', 'cmt' )->fields( 'cmt', array(
                'cid' 
        ) )->condition ( 'uid', $userId, '=' );
        $result = $sql_comments->execute ()->fetchAll();
        $total_answers = count ( $result );


 
        //field_data_field_answers_accepted

        $query = db_select ( 'field_data_field_answers_accepted', 'pses' )->fields ( 'pses', array (
                'field_answers_accepted_value' 
        ) )->condition ( 'entity_id', $userId, '=' );
        $result = $query->execute ()->fetchAll ();

        $accepted_answers = 0;
        foreach ( $result as $value ) {
            $accepted_answers = $value->field_answers_accepted_value;
        }
    
        //field_data_field_answers_accepted

        $total_accepted_answers = $accepted_answers;
        if ($total_answers > 0) {
            $acp = ($total_accepted_answers / $total_answers) * 100;
            $actual_val = $acp * .5;
        }

        if ($total_answers == 0) {
            $actual_val = 0;
        }
        $total = round( $actual_val + $year_of_exp + $num_projects + $profile_completeness ); 
        return $total;     
}

/**
 * Function to get User score by Id
 */
function getscorebyId($uid) {
    $actual_score = 0;
    $query = db_select ( 'user_score', 'us' )->fields ( 'us', array (
            'score' 
    ) )->condition ( 'user_id', $uid, '=' );
    $result = $query->execute ()->fetchAll ();
    foreach ( $result as $value ) {
        $actual_score = $value->score;
    }
    return $actual_score;
}

/**
 * Submit handler for help me find an expert
 */
function help_me_find_expert_form_submit($form, &$form_state) {
    $keywords = $form_state ['values'] ['ask_expert_enter_keyword'];
    $termId = kmsGetTermIdFromName ( $keywords, 'skills' );
    $termId = $termId [0];
    $getUserProfiles = kms_get_user_by_prfoile2field ( $termId );
    $users_array = array ();
    $pid = array ();
    $uid_array = array ();
    
    foreach ( $getUserProfiles as $value ) {
        $fc = field_collection_item_load ( $value );
        $item_id = $fc->item_id;
        $query = db_select ( 'field_data_field_pro_skills_and_expertise', 'pses' )->fields ( 'pses', array (
                'entity_id' 
        ) )->condition ( 'field_pro_skills_and_expertise_value', $item_id, '=' );
        $result = $query->execute ()->fetchAll ();
        foreach ( $result as $value ) {
            $pid [] = $value->entity_id;
        }
    }
    
    $profile_array = array_unique ( $pid );
    
    if (isset ( $item_id )) {
        $get_user_query = db_select ( 'field_data_field_pro_skills_and_expertise', 'pses' )->fields ( 'pses', array (
                'entity_id' 
        ) )->condition ( 'field_pro_skills_and_expertise_value', $item_id, '=' );
        $result = $get_user_query->execute ()->fetchAll ();
        foreach ( $result as $value ) {
            $pid [] = $value->entity_id;
        }
    }
    $pid = array_unique ( $pid );
    
    foreach ( $pid as $profile_id ) {
        $get_user_query = db_select ( 'profile', 'pfl' )->fields ( 'pfl', array (
                'uid' 
        ) )->condition ( 'pid', $profile_id, '=' );
        $result_users = $get_user_query->execute ()->fetchAll ();
        foreach ( $result_users as $users ) {
            $check = check_if_user_is_expert ( $profile_id, $termId );
            if ($check == 1) {
                $uid_array [] = $users->uid;
            }
        }
    }
    
    $form_state ['temporary'] = $uid_array;
    $form_state ['rebuild'] = TRUE;
}
/**
 * 
 * @param unknown $keywords
 * @return number|multitype:NULL
 */
function searchUserBykeyword($keywords) {
     $termId = kmsGetTermIdFromName ( $keywords, 'skills' );
    if ($termId == 0) {
        return 0;
    } else {
        $termId = $termId [0];
    }
    $getUserProfiles = kms_get_user_by_prfoile2field ( $termId );
    $users_array = array ();
    $pid = array ();
    $uid_array = array ();
    foreach ( $getUserProfiles as $value ) {
        $fc = field_collection_item_load ( $value );
        $item_id = $fc->item_id;
        $query = db_select ( 'field_data_field_pro_skills_and_expertise', 'pses' )->fields ( 'pses', array (
                'entity_id' 
        ) )->condition ( 'field_pro_skills_and_expertise_value', $item_id, '=' );
        $result = $query->execute ()->fetchAll ();
        foreach ( $result as $value ) {
            $pid [] = $value->entity_id;
        }
    }
    
    $profile_array = array_unique ( $pid );
    if (isset ( $item_id )) {
        $get_user_query = db_select ( 'field_data_field_pro_skills_and_expertise', 'pses' )->fields ( 'pses', array (
                'entity_id' 
        ) )->condition ( 'field_pro_skills_and_expertise_value', $item_id, '=' );
        $result = $query->execute ()->fetchAll ();
        foreach ( $result as $value ) {
            $pid [] = $value->entity_id;
        }
    }
    
    $pid = array_unique ( $pid );
    foreach ( $pid as $profile_id ) {
        $get_user_query = db_select ( 'profile', 'pfl' )->fields ( 'pfl', array (
                'uid' 
        ) )->condition ( 'pid', $profile_id, '=' );
        $result_users = $get_user_query->execute ()->fetchAll ();
        foreach ( $result_users as $users ) {
            
            $uid_array [] = $users->uid;
        }
    }
    
    return $uid_array;
}


/**
 * 
 * @param integer $nid
 * @return number
 */
function getAcceptedCommentsCounts($nid) {
    $query = db_select ( "comment", "c" );
    $query->condition ( "c.nid", $nid )->condition ( "fdcb.entity_type", "comment" )->condition ( "c.status", 1 )->fields ( "c", array (
            "cid" 
    ) )->innerJoin ( 'field_data_comment_body', 'fdcb', 'fdcb.entity_id = c.cid' );
    $result = $query->execute ();
    $array = $result->fetchAll ();
    $count_accepted = 0;
    foreach ( $array as $key => $value ) {
        $comment = comment_load ( $value->cid );
        if ($comment->field_is_accepted ['und'] [0] ['value'] == 1) {
            $count_accepted ++;
        } else if ($comment->field_is_accepted ['und'] [0] ['value'] == 0) {
            $count_accepted = $count_accepted;
        }
    }
    return $count_accepted;
}

/**
 * Lesson's Search
 */
function search_queries() {
    if (isset ( $_GET ['combine'] )) {
        $search_string = $_GET ['combine'];
    } else {
        $search_string = '';
    }
    if (isset ( $_GET ['searchby'] )) {
        $searchby = $_GET ['searchby'];
    }
    
    if ($searchby == 0) {
        // lessons-search?combine=great&searchby=0
        $urlgoto = 'ask-an-expert';
        $options = array (
                'query' => array (
                        'combine' => $search_string,
                        'searchby' => $searchby 
                ) 
        );
    } else if ($searchby == 1) {
        // ask-an-expert/queries-awaiting-response?combine=great&searchby=1
        $urlgoto = 'ask-an-expert/queries-awaiting-response';
        $options = array (
                'query' => array (
                        'combine' => $search_string,
                        'searchby' => $searchby 
                ) 
        );
    } else if ($searchby == 2) {
        // ask-an-expert/answered-queries?combine=great&searchby=2
        $urlgoto = 'ask-an-expert/search-answered-queries';
        $options = array (
                'query' => array (
                        'combine' => $search_string,
                        'searchby' => $searchby 
                ) 
        );
    } else if ($searchby == 3) {
        // lessons-search?combine=great&searchby=2
        $urlgoto = 'ask-an-expert/search-all-queries';
        $options = array (
                'query' => array (
                        'combine' => $search_string,
                        'searchby' => $searchby 
                ) 
        );
    }
    drupal_goto ( $urlgoto, $options );
}

/**
 * Function to return arriving flights form.
 */
function custom_ask_an_expert_form($form, &$form_state) {
    $nodeid = arg ( 1 );
    // Get accepted answers and send in hidden
    $node_info = node_load ( $nodeid );
    
    $cid_array = db_select ( 'comment', 'cmt' )->fields ( 'cmt', array (
            'cid' 
    ) )->condition ( 'nid', $nodeid, '=' )->execute ()->fetchAllKeyed ( 0, 0 );
    $cid_array = array_unique ( $cid_array );
    
    $accepted = 0;
    foreach ( $cid_array as $cid ) {
        $comment = comment_load ( $cid );
        if ($comment->field_is_accepted ['und'] [0] ['value'] == 1) {
            $accepted ++;
        }
    }
    
    $form ['my_markup'] = array (
            '#markup' => '<div id="replace_div_1"></div>' 
    );
    
    $form ['name'] ['public_query'] = array (
            '#type' => 'radios',
            '#title' => t ( 'Mark this query as public' ),
            '#options' => array (
                    t ( 'Private' ),
                    t ( 'Public' ) 
            ),
            '#default_value' => 1, // for default checked and false is not checked
            '#prefix' => '<div id="replace_div_2"><div class="form-close-query">' 
    )
    ;
    $form ['closing_remark'] = array (
            '#type' => 'textarea',
            '#title' => t ( 'Closing Remark <span class="form-required" title="This field is required.">*</span>' ),
            '#maxlength' => 100000 
    );
    $form ['node_id'] = array (
            '#type' => 'hidden',
            '#default_value' => $nodeid 
    );
    $form ['name'] ['close_query'] = array (
            '#type' => 'hidden',
            '#default_value' => 1 
    ) // for default checked and false is not checked
;
    $form ['accepted_ans'] = array (
            '#type' => 'hidden',
            '#default_value' => $accepted 
    );
    $form ['submit'] = array (
            '#type' => 'submit',
            '#value' => 'Submit',
            '#ajax' => array (
                    'callback' => 'query_close_form_ajax_handler',
                    'method' => 'replace',
                    'effect' => 'fade' 
            ),
            
            $form ['markform'] = array (
                    '#markup' => '<button type="button" class="btn btn-default" data-dismiss="modal" data-toggle="collapse" data-target="#query-close">Cancel</button>',
                    '#weight' => 99,
                    '#suffix' => '</div></div>' 
            ) 
    );
    return $form;
}

/**
 * Close Query Ajax handler function
 */
function query_close_form_ajax_handler(&$form, &$form_state) {
    global $user;
    $form_state ['rebuild'] = TRUE;
    $close_checkbox_val = trim ( $form_state ['values'] ['close_query'] );
    $remarks = trim ( $form_state ['values'] ['closing_remark'] );
    $node_id = trim ( $form_state ['values'] ['node_id'] );
    $public_query = trim ( $form_state ['values'] ['public_query'] );
    
    $accepted_ans_num = trim ( $form_state ['values'] ['accepted_ans'] );
    $arra_errors = array ();
    if ($remarks == "") {
        
        $arra_errors [] = "Please enter closing remarks.";
    }
    if ((isset ( $close_checkbox_val )) && ($close_checkbox_val == 0)) {
        $arra_errors [] = "Please Check the checkbox close this query.";
    }
    // if there is no accepted answer it can not be public
    if ((isset ( $close_checkbox_val )) && ($accepted_ans_num <= 0) && ($public_query == 1)) {
        // this change asked by ambudheesh
        // $arra_errors[] = "You can not make this query public, as there is no accepted answers.";
    }
    
    $string .= "<ul>";
    foreach ( $arra_errors as $key => $value ) {
        $string .= "<li>";
        $string .= $value;
        $string .= "</li>";
    }
    $string .= "</ul>";
    if (count ( $arra_errors ) == 0) {
        $node = node_load ( $node_id );
        $node->field_is_closed ['und'] [0] ['value'] = $close_checkbox_val;
        $node->field_closing_remark ['und'] [0] ['value'] = $remarks;
        $node->field_is_public ['und'] [0] ['value'] = $public_query;
        $node->comment = 1;
        node_save ( $node );
        // Fire email mark as addressed
        email_on_query_addressed ( $node_id );

      $notify_users[] = $user->uid;
      foreach ($node->field_expert_name['und'] as $key => $value) {
        $notify_users[] = $value['target_id'];
      }

        $notify_users_new = array_unique($notify_users);
        if($public_query == 1){
          //pub

               $headernotification = array();
               foreach ($notify_users_new as $key => $value) {
                  $headernotification[] = array(
                      'sender_id' => $user->uid,
                      'receiver_id' =>  $value,
                      'module_type' => 'ask_an_expert',
                      'nt_type'   => 'QUERY_ClOSED_PUBLIC',
                      'entity_type' => 'node',
                      'entity_id' => $node_id,
                      'created'  => REQUEST_TIME,
                      'nt_info' => 'info',
                      'other_val' => NULL,
                  );                 
               }
                if (!empty($headernotification)) {
                 save_user_notification($headernotification);
                }  


        } else {
                  //pvt
                
               $headernotification = array();
               foreach ($notify_users_new as $key => $value) { 
                    $headernotification[] = array(
                        'sender_id' => $user->uid,
                        'receiver_id' => $value,
                        'module_type' => 'ask_an_expert',
                        'nt_type'   => 'QUERY_ClOSED_PRIVATE',
                        'entity_type' => 'node',
                        'entity_id' => $node_id,
                        'created'  => REQUEST_TIME,
                        'nt_info' => 'info'            
                    ); 
                 }
                  if (!empty($headernotification)) {
                      save_user_notification($headernotification);
                  }   

        }

        return array (
                '#type' => 'ajax',
                '#commands' => array (
                        ajax_command_replace ( "#replace_div_1", '<div id="replace_div_1" style="margin-top: 39px;" class="alert alert-block alert-success messages status">Your query has been closed successfully.</div>' ),
                        ajax_command_replace ( "#replace_div_2", '<div id="replace_div_2"></div>' ),
                        ajax_command_replace ( ".closeq", '' ),
                        ajax_command_replace ( ".media-body .pull-left li:nth-child(4)", '<li><strong>Status:</strong> Closed</li>' ) 
                ) 
        );


    } else {
        return array (
                '#type' => 'ajax',
                '#commands' => array (
                        ajax_command_replace ( '#replace_div_1', '<div id="replace_div_1" style="margin-top: 39px;" class="alert alert-block alert-danger messages error">' . $string . '</div>' ) 
                ) 
        );
    }
}
    
    /*
 * Hook mail implements
 * hook_mail
 */
function custom_ask_an_expert_mail($key, &$message, $params) {
    $message ['subject'] = $params ['subject'];
    $message ['body'] [] = $params ['body'];
    if (isset ( $params ['cc'] )) {
        $message ['headers'] ['cc'] = $params ['cc'];
    }
}

/**
 * Implements hook_cron().
 *
 * We are using cron to send reminder notification To users who did not answered query
 */
function custom_ask_an_expert_cron() {
    // First get queries which last update date is greater then date which was 7 days earlier
    // Get experts in loop
    // Check weather they have posted comments or not
    // if not send them reminder
    $queries_posted = custom_ask_an_expert_get_all_queries();
    $get_experts = custom_ask_an_expert_get_all_experts( $queries_posted );
    
    // Send email Notification
    send_reminder($get_experts);
}
/**
 * 
 * @return multitype:NULL
 */
function custom_ask_an_expert_get_all_queries() {
    $date = strtotime ( date ( "Y-m-d", strtotime ( "-0 day" ) ) );
    // get nodes posted before 7 days
    



    $node_type = "query";
    
    $result = db_query ("SELECT nid,changed FROM {node} WHERE type = :nodeType", array (
            ':nodeType' => $node_type 
    ) );
    
    $nids = array ();
    foreach ( $result as $obj ) {

      $changed_date = date( 'Y-m-d', $obj->changed );
      $now = time();  
      $your_date = strtotime($changed_date);
      $datediff = $now - $your_date;
      $diff = floor($datediff / (60 * 60 * 24));
      if(  $diff >= 7 ) {
          $nids [] = $obj->nid;
      }

    }
    return $nids;
}
/**
 *
 * @param unknown $nid_array            
 * @return multitype:unknown
 */
function custom_ask_an_expert_get_all_experts($nid_array) {
    // get expert's uid who have not commented yet
    $node_expert = array ();
    foreach ( $nid_array as $key => $value ) {
        // first get expert list
        $nid = $value;
        $query_node = node_load ( $nid );
        if ($query_node->field_is_closed ['und'] [0] ['value'] == 0) {
            if (isset ( $query_node->field_expert_name ['und'] )) {
                $experts_ary = $query_node->field_expert_name ['und'];
            }
            // now check if user has commented
            foreach ( $experts_ary as $key => $value ) {
                $this_expert = $value ['target_id'];
                $this_nid = $nid;
                $result_nodes = db_query ( "SELECT count(*) as count, uid as userId FROM {comment} WHERE nid = :nodeId and uid = :userId", array (
                        ':nodeId' => $this_nid,
                        ':userId' => $this_expert 
                ) );
                foreach ( $result_nodes as $count_obj ) {
                    if ($count_obj->count == 0)
                        $node_expert [$this_nid] = $this_expert;
                }
            }
        }
    }
     
    return $node_expert;
}

/**
 * implements hook_node_access
 *
 * Purpose of using this hook is to custome identify that current logged in user have access to perform following action
 */
function custom_ask_an_expert_node_access($node, $op, $account) {
    global $user;
    switch ($op) {
        case 'view' :
            if ($node->type == 'query' && $node->status == 1) {
                if (($node->field_is_closed ['und'] [0] ['value'] == 1) && ($node->field_is_public ['und'] [0] ['value'] == 1)) {
                    return NODE_ACCESS_IGNORE;
                }
                if (isset ( $node->field_expert_name ['und'] )) {
                    foreach ( $node->field_expert_name ['und'] as $key => $value ) {
                        $userList [] = $value ['target_id'];
                    }
                    
                    $userList [] = $node->uid;
                    if (! in_array ( $user->uid, $userList )) {
                        return NODE_ACCESS_DENY;
                    }
                }
            }
            if ($node->type == 'query' && $node->status == 0) {
                
                return NODE_ACCESS_DENY;
            }
            break;
    }
    return NODE_ACCESS_IGNORE;
}

/**
 *
 * @return number
 */
function user_score() {
    $sql_users = db_select ( 'users', 'users' )->fields ( 'users', array(
            'uid',
            'name' 
    ) )->condition ( 'status', 1, '=' );
    $result_users = $sql_users->execute ()->fetchAll ();
    foreach ( $result_users as $key => $value ) {
        $uid_array [$value->uid] ['name'] = $value->name;
    }
    
    db_query ( 'truncate table user_score' );
    foreach ( $uid_array as $key => $value ) {
        $userId = $key;
        $year_of_exp = 5;
        $num_projects = 10;
        $profile_completeness_score = score_percentage ( $userId );
        $profile_completeness = ($profile_completeness_score) * .2;
        $sql_comments = db_select ( 'comment', 'cmt' )->fields( 'cmt', array(
                'cid' 
        ) )->condition ( 'uid', $userId, '=' );
        $result = $sql_comments->execute ()->fetchAll();
        $total_answers = count ( $result );
        $comments_new_array = array ();
        foreach ( $result as $value ) {
            $cid = $value->cid;
            $sql_accepted_answer = db_select ( 'field_data_field_is_accepted', 'fdfia' )->fields('fdfia', array(
                    'field_is_accepted_value' 
            ) )->condition ( 'entity_id', $cid, '=' );
            $result_if_accepted = $sql_accepted_answer->execute ()->fetchAll ();
            unset ( $comments_new_array );
            $comments_new_array = array ();
            foreach ( $result_if_accepted as $value_accepted ) {
                $is_accepted = $value_accepted->field_is_accepted_value;
                if ($is_accepted == 1) {
                    $comments_new_array [] = $cid;
                }
            }
        }
        $total_accepted_answers = count ( $comments_new_array );
        if ($total_answers > 0) {
            $acp = ($total_accepted_answers / $total_answers) * 100;
            $actual_val = $acp * .5;
        }
        if ($total_answers == 0) {
            $actual_val = 0;
        }
        $total = round( $actual_val + $year_of_exp + $num_projects + $profile_completeness );
        $uid_array_new [$userId] = $total;
        db_insert ( 'user_score' )->fields(array(
                'user_id' => $userId,
                'score' => $total 
        ) )->execute();
    }
    arsort( $uid_array_new );
    return $uid_array_new;
}

/**
 * Time Ago Function
 */
function time_elapsed_string($datetime, $full = false) {
    $now = new DateTime();
    $ago = new DateTime( $datetime );
    $diff = $now->diff( $ago );
    
    $diff->w = floor( $diff->d / 7 );
    $diff->d -= $diff->w * 7;
    
    $string = array (
            'y' => 'year',
            'm' => 'month',
            'w' => 'week',
            'd' => 'day',
            'h' => 'hour',
            'i' => 'minute',
            's' => 'second' 
    );
    foreach ( $string as $k => &$v ) {
        if ($diff->$k) {
            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
        } else {
            unset( $string [$k] );
        }
    }
    if (! $full)
        $string = array_slice ( $string, 0, 1 );
    return $string ? implode( ', ', $string ) . ' ago' : 'just now';
}
