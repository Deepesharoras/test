<?php 
// echo "this is blog page";
// display($rows);
/* var_dump($main_title); 
var_dump($title);
display($rows); */
/* print '<pre>';
var_dump(get_defined_vars());
print '</pre>'; */
 /*  $author = array();
  $author['author'] = array();
  $author['coauthor'] = array();
  $author['editor'] = array();
  // get editor information 
  $i = 0;
  foreach($rows  as $kmrow)
  {
    // $kmrow->field_field_first_name;
    $author['author'][$i]['name'] = $kmrow->field_field_first_name[0]['raw']['value'].' '.$kmrow->field_field_last_name[0]['raw']['value'];
    $author['author'][$i]['username'] = $kmrow->users_node_name;
    if(!empty($kmrow->field_field_first_name_1)){
        $author['editor'][$i]['name'] = $kmrow->field_field_first_name_1[0]['raw']['value'] .' '.$kmrow->field_field_last_name_1[0]['raw']['value'];
        $author['editor'][$i]['username'] = $kmrow->users_field_data_field_blog_name_editor_name;	
    }
    if(!empty($kmrow->field_field_first_name_2)){
        $author['coauthor'][$i]['name'] = $kmrow->field_field_first_name_2[0]['raw']['value'].' '.$kmrow->field_field_last_name_2[0]['raw']['value'];
        $author['coauthor'][$i]['username'] = $kmrow->users_field_data_field_blog_name_co_author_name;	
    }
    $i++;
  }
 // $owner = array_unique( array_column($author['author'],'username'),SORT_STRING);
 $owner = array_map("unserialize", array_unique(array_map("serialize", $author['author'])));
 // $coauthor = array_unique(array_column($author['coauthor'],'username'),SORT_STRING);
 $coauthor = array_map("unserialize", array_unique(array_map("serialize", $author['coauthor'])));
 // $editor = array_unique(array_column($author['editor'],'username'),SORT_STRING);
 $editor = array_map("unserialize", array_unique(array_map("serialize", $author['editor'])));
  */
 /* display($owner);
 display($coauthor);
 display($editor);  */
  // display($author);
?>
<div class="blog-owner">
    <label>Owner: </label> 
       <?php if(isset($owner)) :?>
                <?php print l($owner['0']['name'],'profile/'.$owner['0']['username']); ?>
        <?php endif; ?>
</div>
<div class="blog-co-owner">
    <label>Co-owner: </label>
            <?php 
                if(!empty($coauthor)) :
                    foreach($coauthor as $singleCo){
                        print l($singleCo['name'],'profile/'.$singleCo['username']);
                }
                else :
                    print 'N/A';
                endif;
            ?>
</div>
<div class="blog-editor" >
    <label>Editor: </label>
            <?php 
                if(!empty($editor)) : 
                    foreach($editor as $singleEd){
                        print l($singleEd['name'],'profile/'.$singleEd['username']) ;
                    }
                else :
                    print 'N/A';
                endif;
            ?>
</div>