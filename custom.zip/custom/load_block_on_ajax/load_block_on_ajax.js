(function ($) {

  Drupal.loadBlockOnAjax = function () {

    $('.load-block-on-ajax-wrapper h2').click(function () {
      if(!$(this).parent().hasClass("load-block-active-wrapper")){
        $(this).parent().addClass("load-block-active-wrapper");
        $(this).parent().find('.load-on-ajax-img-text-center').show();
        // $(this).parent().find("h2").addClass('load-block-on-ajax-wrapper-minus');
        var load_on_ajax_div_id = $(this).parent().find('div[id^=load-block-on-ajax-]').attr('id');
        var block_id = load_on_ajax_div_id.replace( 'load-block-on-ajax-', '' );
        block_id = block_id.replace( '-ajax-content', '' );

        $.ajax({
          url: Drupal.settings.basePath + "load-block-on-ajax/" + block_id + "?path=" + Drupal.settings.load_block_on_ajax_path,
          type: "GET",
          dataType: "json",
          cache: false,
          success: function (data) {
            var context = $('#load-block-on-ajax-'+ block_id + '-ajax-content');
            Drupal.detachBehaviors(context);
            context.html( data['content'] );
            if (data['ajaxblocks_settings']) {
              $.extend(true, Drupal.settings, data['ajaxblocks_settings']);
            }
            Drupal.attachBehaviors(context);
          }
        });
      } else {
        $(this).parent().find('.load-on-ajax-text-center').toggle();
        // $(this).parent().find("h2").toggleClass('load-block-on-ajax-wrapper-minus');
      }
    });
  }

  $(document).ready(function () {
    Drupal.loadBlockOnAjax();
  });

})(jQuery);
