(function ($) {
  Drupal.behaviors.autocomplete_tags = {
    attach: function (context, settings) { 
		var tags_ids = Drupal.settings.autocomplete_tags.return_tags;
    	var closeIcon = '<i class="fa fa-times-circle" title="Remove" aria-hidden="true"></i>';

    	// Add Item
		function addItem(item, key){
    		var inputWidth = $("#"+key).parent(".input-group").width();
    		var parentWidth = $("#"+key).parent(".input-group").parent().width();
    		var labelWidth = $("#"+key).parent(".input-group").prev().outerWidth();
    		var inputPercent = ((inputWidth) / parentWidth) * 100;
    		var labelPercent = ((labelWidth) / parentWidth) * 100;

			var value = $.trim(item.val());
			$("#"+ tags_ids[key]["append"] + " .ac-item").each(function(){
				if($(this).text().toLowerCase() == value.toLowerCase()){
					$(".alert").remove();
					$("#main-content").after('<div class="alert alert-block alert-danger messages error"><a class="close" data-dismiss="alert" href="#">×</a><h4 class="element-invisible">Error message</h4><ul><li>Tag already exists.</li></ul></div>');
					item.val("");
					$("#"+key).css({
						"border-color" : "#a94442"
					});
				}
			});
			if(typeof $("#"+key).val() !== "undefined" && $("#"+key).val() !== ''){
				$("#"+ tags_ids[key]["append"]).append('<div class="ac-item"><a href="javascript:void(0);">'+ item.val() + '</a>' + closeIcon +'</div>').css({
					"width":Math.round(inputPercent)+"%",
					// "margin-left":Math.round(labelPercent)+"%",
					"float":"right"
				});
				removeItem(key);
				item.val("");
				$("#"+key).css({
					"border-color" : "#ccc"
				});
			}
    	}

    	// Add Multiple Item
    	function addMultipleItem(items, key){
    		var inputWidth = $("#"+key).parent(".input-group").width();
    		var parentWidth = $("#"+key).parent(".input-group").parent().width();
    		var labelWidth = $("#"+key).parent(".input-group").prev().outerWidth();
    		var inputPercent = ((inputWidth) / parentWidth) * 100;
    		var labelPercent = ((labelWidth) / parentWidth) * 100;

    		var value = $.trim(items.val()).replace(/[^a-zA-Z, ]+/, '').replace(/  +/g, ' ');
    		var splitValue = value.split(",");
    		var html = "";
    		var arr_html = [];
    		for(var i = 0; i < splitValue.length; i++){
    			if($.trim(splitValue[i]).length >= 3 &&  $.trim(splitValue[i]).length < 55){
    				html += '<div class="ac-item"><a href="javascript:void(0);">'+ $.trim(splitValue[i]) + '</a>' + closeIcon +'</div>';
    			} else{
					$(".alert").remove();
	    			$("#main-content").after('<div class="alert alert-block alert-danger messages error"><a class="close" data-dismiss="alert" href="#">×</a><h4 class="element-invisible">Error message</h4><ul><li>Please enter the Tags minimum in 3 characters and maximum of 55 characters.</li></ul></div>');
					$("#"+key).css({
						"border-color" : "#a94442"
					});
    			}
    			$("#"+ tags_ids[key]["append"] + " .ac-item").each(function(){
					if($.trim(splitValue[i]).toLowerCase() !== $(this).text().toLowerCase()){
						arr_html.push( true );
						$("#"+key).css({
							"border-color" : "#ccc"
						});
					} else {
						// html += '';
						arr_html.push( false );
					}
				});
    		} 
    		if(typeof $("#"+key).val() !== "undefined" && $("#"+key).val() !== ''){
	    		if($.inArray(false, arr_html) == -1) {    			
	    			$("#"+ tags_ids[key]["append"]).append(html).css({
						"width":Math.round(inputPercent)+"%",
						// "margin-left":Math.round(labelPercent)+"%",
						"float":"right"
					});
	    			items.val("");
	    			$("#"+key).css({
						"border-color" : "#ccc"
					});
	    		} else{
	    			$(".alert").remove();
	    			$("#main-content").after('<div class="alert alert-block alert-danger messages error"><a class="close" data-dismiss="alert" href="#">×</a><h4 class="element-invisible">Error message</h4><ul><li>Tag already exists.</li></ul></div>');
					$("#"+key).css({
						"border-color" : "#a94442"
					});
	    		}
	    	}
    	}

    	// Check On Load Items ( If there is any item append it. )
    	function onLoadItems(items, key){
    		var inputWidth = $("#"+key).parent(".input-group").width();
    		var parentWidth = $("#"+key).parent(".input-group").parent().width();
    		var labelWidth = $("#"+key).parent(".input-group").prev().outerWidth();
    		var inputPercent = ((inputWidth) / parentWidth) * 100;
    		var labelPercent = ((labelWidth) / parentWidth) * 100;

    		if(typeof $("#"+key).val() !== "undefined" && $("#"+key).val() !== ''){ 		
    			var value = items.val();
    			var splitValue = value.split(",");
				var html = "";
				for (var i = 0; i < splitValue.length; i++){
					html += '<div class="ac-item"><a href="javascript:void(0);">'+ $.trim(splitValue[i]) + '</a>' + closeIcon +'</div>';
				}
				$("#"+ tags_ids[key]["append"]).append(html).css({
					"width":Math.round(inputPercent)+"%",
					// "margin-left":Math.round(labelPercent)+"%",
					"float":"right"
				});
				items.val("");
			}
    	}
    	// Remove Item
    	function removeItem(key) {
    		$("#"+ tags_ids[key]["append"] + " .ac-item .fa").on("click", function(){
				$(this).parent().remove();
			});
    	}

    	// Submit Form
    	function submitForm(key){
		    var string = '';
			$("#"+ tags_ids[key]["append"] +" .ac-item").each(function(){
				string += $(this).text() + ', ';
			});
			var result = string.substring(0, string.length-2); 
			$("#"+key).val(result).css({
				'color':'transparent'
			});
    	}


    	$.each(tags_ids, function(key) {    
			$("#"+key).on('autocompleteSelect', function(){
				var item = $(this);
				addItem(item, key);
			});

    		// Invoke OnLoadItems Function on Window Load
    		var items = $("#"+ key);
    		onLoadItems(items, key);
    		removeItem(key);

    		// Submit Form
    		$("#"+key).on("keyup blur", function(){
    			var self = $(this);	
				var value = "";
				if($(this).val().length <= 3 ){
					value = $(this).val().replace(/[^a-zA-Z ]+/, '').replace(/  +/g, ' ');
				} else{
					value = $(this).val().replace(/[^a-zA-Z, ]+/, '').replace(/  +/g, ' ').replace(/,,+/g, ',');
				}
				self.val(value);
			});

    		$("#"+ tags_ids[key]["add_more"]).on("click", function(){
	    		if($.trim(items.val()).length > 1){
	    			addMultipleItem(items, key);
					removeItem(key);
	    		} else{ 
	    			$(".alert").remove();  			
	   				$("#main-content").after('<div class="alert alert-block alert-danger messages error"><a class="close" data-dismiss="alert" href="#">×</a><h4 class="element-invisible">Error message</h4><ul><li>Please enter the Tags minimum in 3 characters </li></ul></div>');
	   				$("#"+key).css({
						"border-color" : "#a94442"
					})
	    		}
			});
	    	$('form').on('submit', function () {
	    		submitForm(key);
    		});
		});
    }
  };
}(jQuery));

