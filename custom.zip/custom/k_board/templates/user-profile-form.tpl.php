<div id="new-form">
  <?php echo $rendered['picture']; ?>
  <?php echo $rendered['account']; ?>
  <?php echo $rendered['actions']; ?>
  <input type="hidden" name="form_id" value="<?php print $form['#form_id']; ?>" />
  <input type="hidden" name="form_build_id" value="<?php print $form['#build_id']; ?>" />
  <input type="hidden" name="form_token" value="<?php print $form['form_token']['#default_value']; ?>" />
</div>
