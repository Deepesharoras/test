/*
 * setting tabindex of profile2 fields in user register form
 * */
(function ($) {
    Drupal.behaviors.register = {
        attach: function (context, settings) {
           $("input[id*='edit-profile-basic-information-field-pro-basic-info-emp-code-und-0-value']").attr('tabindex',1);
           //$("input[id*='edit-profile-basic-information-field-pro-date-of-birth-und']").attr('tabindex',5);
           $("input[id*='edit-profile-basic-information-field-pro-basic-grade-und']").attr('tabindex',8);
           $("input[id*='edit-profile-basic-information-field-pro-basic-contact-num-und-0-mobile']").attr('tabindex',10);
           $("input[id*='edit-profile-basic-information-field-pro-basic-info-report-mgr-und']").attr('tabindex',11);
           $("select[id*='edit-profile-basic-information-field-pro-basic-address-und']").attr('tabindex',12);
           $("input[id*='edit-roles-change']").attr('tabindex',13);
           $("input[id*='edit-mail']").bind('keypress keyup blur', function() {
               $("input[id*='edit-name']").val($(this).val());
           });
        }
    };
}(jQuery));