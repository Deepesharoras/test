<?php global $base_url; ?>
 <div class='modal fade' id='myfollowing' role='dialog'>
  <div class='modal-dialog modal-lg'>
    <div class='modal-content'>
  	  <div class='modal-header'>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
  		  <h4 class='modal-title'>I'm Following</h4>
  	  </div>
  	  <div class='modal-body'><?php echo $following_complete; ?></div>
  	</div>
   </div>
  </div>
  
  <div class='modal fade' id='myfollower' role='dialog'>
  <div class='modal-dialog modal-lg'>
    <div class='modal-content'>
  	  <div class='modal-header'>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
  		  <h4 class='modal-title'>My Follower</h4>
  	  </div>
  	  <div class='modal-body'><?php echo $followers_complete; ?></div>
  	</div>
   </div>
  </div>
  
  <div class='block-overall profile-overall'>
    <div class='profile-header bg-primary padding-10'>
        <a href= <?php echo $base_url; ?>/user/<?php echo $user->uid ?>/edit title='edit profile' class='editprofile'><i class='fa fa-pencil text-white'></i></a>
        <div class='pull-left'>
            <img class='img-responsive pull-left profile-pic' src= <?php echo $user_image ; ?> />
        </div>
        <div class='overflow-h'>
            <h3 class='h1 text-white'>
          <strong><?php echo $user_first_name." ".$user_middle_name." ".$user_last_name ?></strong></h3>
            <h5 class='mb0 text-white'><?php echo @$position ; ?></h5>
            <h5 class='mb0 text-white'><?php echo @$department ; ?></h5>
            <h5 class='mb0 text-white'><?php echo @$location_name ;?></h5>
        </div>
    </div>
    <div class='clearfix'></div>
    <div class='profile-body padding-10'>
        <div class='row'>
            <div class='col-xs-6'>
                <h3>Followers</h3><?php echo $followers; ?><span class='more-profile'><?php echo @$follower_more; ?></span></div>
            <div class='col-xs-6 text-right'>
                <h3>Following</h3><?php echo $following; ?><span class='more-profile'><?php echo @$following_more; ?></span>
            </div>
        </div>
        <div class='statistics'>
            <h3 class='heading-xs'>Profile Completeness <span class='pull-right'><?php echo $profile_score; ?>%</span></h3>
            <div class='progress'>
                <div style= 'width: <?php echo $profile_score; ?>%;' class='progress-bar' role='progressbar' aria-valuenow='<?php echo $profile_score; ?>' aria-valuemin='0' aria-valuemax='100'></div>
            </div>
        </div>
    </div>
</div>