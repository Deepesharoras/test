<div id="subfolder<?php print $folder_id ?>" class="subfolder listing_record">
  <div>
    <div class="folder_withhover" style="width:100%;">
      <div class="floatleft table-width-file-depo file-name">
        <span class="folder-icon-margin"><a href="javascript:void(0);"><i class="fa fa-folder-o"></i></a></span>
        <span ><?php print '';//print $folder_number; ?></span>
        <span class="folderlink"><a href="javascript:void(0);" title="<?php print $folder_name; ?>"  onClick="makeAJAXGetFolderListing(<?php print $folder_id ?>);return false;"><?php print $folder_name ?></a></span>
      </div>
      <!-- <div class="floatleft table-width-file-depo tagss">&nbsp; &nbsp;&nbsp; &nbsp; </div>
      <div class="floatleft table-width-file-depo folder-name">&nbsp; &nbsp;&nbsp; &nbsp; </div> -->
      <div class="floatleft table-width-file-depot-share  anik text-center" ><?php print $last_modified_date ?>&nbsp;</div>
      <div class="floatleft table-width-file-depot-share text-center" ><?php print $total_size;?>&nbsp;</div>
      <div class="floatleft table-width-file-depot-share text-center sdfas" ><?php print $folder_count; print ' / '. $file_count ?>&nbsp;</div>
      <?php if( $share == 'allow' ) {
      	print "<div id='sharefolder' class='floatleft table-width-file-depot-share text-center'><a href='javascript:void(0)' onclick='makeAJAXShowFolderListPerms( $folder_id );' title='Click to share.'><i class='fa fa-share-alt'></i></a></div>";
      } else {
        print "<div class='floatleft table-width-file-depot-share text-center'>$shared_by_user</div>";
      }
      ?>
    </div>
  </div>
</div>
<div id="subfolder<?php print $folder_id ?>_bottom"></div>
