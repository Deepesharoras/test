<?php
/**
  * @file
  * notifications_folder_record.tpl.php
  */
?>

<div class="listing_record">
    <div class="floatleft table-width-folder-notification text-eclips" >
     <input id="chkfolder<?php print $folderid ?>" type="checkbox" name="chkfolder" value="<?php print $recid ?>" onClick="updateCheckedItems(this,'folder')">
    <a href="#" onClick="makeAJAXGetFolderListing(<?php print $folderid ?>);return false;"><?php print $foldername ?></a></div>
    <div class="floatleft table-width-folder-notification" ><?php print $date ?></div>
    <div class="floatleft table-width-folder-notification" ><input type="checkbox" disabled=disabled <?php print $chk_filechanges ?>></div>
    <div class="floatleft table-width-folder-notification" ><input type="checkbox" disabled=disabled <?php print $chk_newfiles ?>></div>
  <div class="floatleft table-width-folder-notification" ><a href="#" onclick="doAJAXDeleteNotification('folder',<?php print $recid ?>);return false;"><?php print $LANG_delete ?></a></div>
</div>



