<?php
/**
  * @file
  * native_filelisting_record.tpl.php
  */
?>  

<div><img src="<?php print $icon ?>">&nbsp;<?php print $filelink ?></div>
