<?php

/**
 * @file
* filelisting_record.tpl.php
*/
global $base_url;
$folderclass = '';
if( $hide_folder_column == 'hide'  ) {
    $folderclass = 'fd-folder-class';
}
$folderdetails = '';
if( $hide_folder_column != 'hide'  ) {
    $folderdetails = 'fd-folder-details';
}

$filedepot = filedepot_filedepot();
$rec = $variables['rec'];

/* $variables['fid'] = $rec['fid'];
$variables['modified_date'] =  format_date( $rec['date'] , 'km_date_format' );
$variables['extension_icon'] = $filedepot->getFileFontAwesomeIcon($rec['fname']);
$variables['file_name'] = filter_xss($rec['title']);
$variables['total_size'] = filedepot_formatFileSize($rec['size']); */


?>

<?php foreach( $submit_file_record as $row) {?>


<div class="listing_record" id="folder_<?php print $row->cid ?>_rec_<?php print $row->fid ?>">
        <div class="floatleft table-width-file-depo file-name">
              <?php if( $bool_moreactions) {?>
                     <input id="chkfile<?php print $row->fid ?>" type="checkbox" name="chkfile" value="<?php print $row->fid ?>"  onClick="updateCheckedItems(this)">
               
            <?php }?>            
              <span>
                  <?php print $filedepot->getFileFontAwesomeIcon($row->fname); ?>
              </span>
              <span class="filedetailslink">
                <?php 
                        $withoutExt = preg_replace('/\\.[^.\\s]{3,4}$/', '', $row->title);
                
                        $fid =  $row->fid;
                        
                          if( $show_lock == 'none' ) {
                              echo "<a id='listingFilenameRec$fid' class='filedetailsdialog' href='' TITLE='". $row->description ."'>".   $withoutExt ."</a>";
                        } else {
                              echo "<a id='listingFilenameRec$fid' href='#' class='filelocked' TITLE='". $row->description  ."'>".$withoutExt."</a>";                                
                        }
                ?>
              </span>
        </div>
           
              
             <div class="floatleft table-width-file-depo tagss fd-folder-class "><?php print $row->tags ?></div>
             
            
            <div class="floatleft  table-width-file-depo fd-folder-class "><?php print format_date($row->date,'km_date_format'); ?></div>
            <div class="floatleft table-width-file-depo  fd-folder-class "><?php print filedepot_formatFileSize($row->size); ?>&nbsp;</div>
                      
             <div class='floatleft table-width-file-depo fd-folder-class'><a href='#' onClick='makeAJAXGetFolderListing(<?php  print $row->cid; ?>);return false;'> <?php print $row->name; ?></a></div>
                
            <div class="floatleft   fd-folder-class ">
            
            <?php 
                     
                            if(in_array($row->extension,array('jpg','png','gif')))
                            {
                                echo "<a href='$base_url/knowledge-repository-moderater-image-popup/$row->cid/$row->id' title='View' target='_blank' class='use-ajax ctools-modal-image-view-in-kr'><i class='fa fa-eye'></i></a>&nbsp;";
                            }else{
                                echo "<a href='$base_url/knowledge-repository-moderater-excel-view/$row->cid/$row->id' title='View' target='_blank'><i class='fa fa-eye'></i></a>&nbsp;";
                            }
                       
                      if(isset($action1_link)) {
                         echo $action1_link;
                      }
                    ?>
                    
                  <span><?php print $action2_link ?></span> 
       </div>
</div>

 <?php } ?>


