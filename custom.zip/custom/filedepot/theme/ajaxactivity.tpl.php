<?php
/**
  * @file
  * ajaxactivity.tpl.php
  */
?>
