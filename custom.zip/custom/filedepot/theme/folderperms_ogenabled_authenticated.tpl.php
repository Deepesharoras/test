<?php
/**
  * @file
  * folderperms_ogenabled.tpl.php
  */
?>

<form name="frmFolderPerms" method="POST">
<div id="filedepot-folder-perm-status"></div>
<input type="hidden" name="op" value="">
<div class="form-layout-default">
<!-- tabs  -->
<div class="quicktabs-wrapper">
<ul class="quicktabs-tabs">
    <li class="<?php print $perm_active_class?>"><a data-toggle="tab" href="#permissionoption">Share Options</a></li>
    <li class="<?php print $user_active_class?>"><a data-toggle="tab" href="#userassesrecord">Shared with</a></li>
    <!--  <li class="<?php // print $group_active_class?>"><a data-toggle="tab" href="#groupassesrecord">Communities</a></li>  -->
  </ul>
  <div class="tab-content">
  <!-- menu 0   -->
    <div id="permissionoption" class="tab-pane fade <?php print $perm_active_class_tab?>">
    
	<!-- 
	<div class="form-group row">
      <label for="example-text-input" class="col-md-3 col-form-label">Select Users</label>
        <select name="selusers[]" class="col-md-9 input form-control"  multiple size=5><?php // print $user_options ?></select>
    </div> -->
	
	<!--  for user section  --> 
	<div id="myAutoComplete" class="form-group row" >
	    <label class="control-label">Select User</label>
		<input id="myInputKR" type="text" class="form-control">
		<div id="myContainerKR" class="kr-autocomplete"></div>
    <div id="userConatiner" class="user-container form-group"> </div>
    <div id='hiddenSharVal'  style="display:none" > </div>
	</div>
	
  <!-- <div class="row">
	 
  </div> -->
	<!-- <input name="selusers23"  id="sharusersuid" type="hidden" class="col-md-9 input form-control" /> -->
	
	<!-- end -->
	
	<!--
     <div class="form-group row">
      <label for="example-text-input" class="col-md-3 col-form-label">Select Communities</label>
       <select name="selgroups[]" multiple size=5 class="col-md-9 input form-control"><?php // print $group_options ?></select>
    </div> -->
	<?php   // this is community share input box. hide this functinnality for now
       // chnage in future as requirement
    ?>
	<!-- 
	<div id="myAutoComplete" class="form-group row" >
	    <label class="control-label">Select Community</label>
		<input id="myInputcommuntyKR" type="text" class="form-control">
		<div id="myContainerCommuntyKR" class="kr-autocomplete"></div>
      <div id="CumminityConatiner" class="user-container form-group"> </div>
    <div id='hiddenCommunityVal' style="display:none" > </div>

	</div> -->
	
	
	
    <div class="form-group row">
        <label for="example-text-input" class="col-form-label control-label">Access Rights</label>
         <select class="input form-control" name="cb_access">
           <option value="view">View </option>
           <option value="co-owner">Upload</option>
         </select>
      </div>
       <div class="text-center">
            <input type="button" name="submit" class="form-submit btn btn-primary" value="<?php print t('Submit'); ?>" onclick="makeAJAXUpdateFolderPerms(this.form);">
            <!-- <span style="padding-left:10px;">
            <input id="folderperms_cancel" type="button" class="form-submit btn btn-default" value="<?php print t('Close'); ?> "></span> -->
            <input type="hidden" name="catid" value="<?php print $catid ?>">
            <input type="hidden" id="folderpermstoken" name="token" value="<?php print $token ?>">
      </div>
    </div>
  <!-- End menu 0 -->
  <!-- Menu 1 -->
     <div id="userassesrecord" class="tab-pane fade <?php print $user_active_class_tab?>">
       <table class="table table-hover table-striped">
          <tr>
            <td align="left"><?php print t('User'); ?></td>
            <td><?php print 'Permission' ?></td>
            <td><?php print $LANG_action ?></td>
          </tr>
          <?php print $user_perm_records ?>
        </table>
    </div>
  <!-- End menu 1 -->
  <!-- Menu 2 -->
     <div id="groupassesrecord" class="tab-pane fade <?php print $group_active_class_tab?>">
      <table class="table table-hover table-striped">
        <tr>
          <td align="left"><?php print t('Communities'); ?></td>
            <td><?php print 'Permission' ?></td>
            <td><?php print $LANG_action ?></td>
        </tr>
        <?php print $group_perm_records ?>
      </table>
    </div>
  <!-- End menu 2 -->   
  </div>
</div>
</div>
</form>

