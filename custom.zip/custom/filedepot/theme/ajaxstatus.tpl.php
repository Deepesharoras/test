<?php
/**
  * @file
  * ajaxstatus.tpl.php
  */
?>
