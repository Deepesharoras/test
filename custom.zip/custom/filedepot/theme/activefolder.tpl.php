<?php
/**
  * @file
  * activefolder.tpl.php
  */
?>
<div>
  <!-- DIV active if in a selected category view -->
  <div class="active-folder-wrapper" style="display:<?php print $show_activefolder ?>;">
    <div class="floatleft" style="display:<?php print $show_breadcrumbs ?>;"><?php print $folder_breadcrumb_links ?></div>
    <div class="clearboth"></div>
    <div id="activefolder_area">
       <?php print $active_folder_admin ?>
    </div>
    <div class="clearboth"></div>
  </div>
  <!-- DIV active if in Report Mode -->
  <div id="reportheadercontainer" style="display:<?php print $show_reportmodeheader ?>">
    <div class="pluginReportTitle floatleft">
      <div><?php print t($report_heading); ?></div>
    </div>
  </div>
</div>