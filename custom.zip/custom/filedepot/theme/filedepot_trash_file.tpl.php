<?php
/**
  * @file
  * filelisting_record.tpl.php
  */
?>

<div class="listing_record">
 
    <div class="floatleft table-width-file-depo file-name">
                <span>
                    <?php print $extension_icon ?>
                </span>
                <span class="filedetailslink">
                    <?php print $file_name ?>
                </span>
        </div>

			<div class="floatleft table-width-file-depot-share text-center" ><?php print $modified_date ?></div>
            <div class="floatleft table-width-file-depot-share text-center"><?php print $total_size;?>&nbsp;</div>
            <div class="floatleft table-width-file-depot-share">&nbsp;&nbsp;&nbsp;</div>
      <div class="floatleft table-width-file-depot-share text-center">
            <div id="trashfile<?php print $fid ?>"><a href="javascript:void(0);" onclick="trashAction( 'restore', <?php print $fid ?>, 'file' );" title="Restore"><i class="fa fa-undo"></i></a>
            <!--  <a href="#" onclick="trashAction( 'permanent-delete', <?php // print $fid ?>, 'file' );" title="Delete"><i class="fa fa-trash"></i></a> -->
            </div>

       </div>
</div>
