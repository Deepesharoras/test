<?php
/**
  * @file
  * filelistingheader.tpl.php
  */
$folderclass = '';
if( $hide_folder_column == 'hide'  ) {
   $folderclass = 'fd-folder-class';
}
$folderdetails = '';
if( $hide_folder_column != 'hide'  ) {
   $folderdetails = 'fd-folder-details';
}
?>

<input type="hidden" name="ltoken" id="flistingltoken" value="<?php print $token ?>" />
<div class="filedepotheading" style="display: <?php print $show_mainheader ?>">

  
<div class="floatleft table-width-file-depo file-name" >
  <div class="floatleft">
   <input id="headerchkall" type="checkbox" value="all" onclick="toggleCheckedItems(this);"></div> 
    <div class="floatleft"><?php print $LANG_filename ?>
      <span id="showhidedetail" style="padding-left:20px;">
        [&nbsp;<a href="#" onClick="showhideFileDetail();"><?php print $LANG_showfiledetails ?></a>&nbsp;]
      </span>
      <span id="expandcollapsefolders" style="display: <?php print $show_folderexpandlink ?>;padding-left:5px;">
        [&nbsp;<a id="expandcollapsefolderslink" href="?op=expand" onClick="expandCollapseFolders(this);return false;"><?php print $LANG_expandfolders ?></a>&nbsp;]
      </span>
  </div>
</div>
 
    <div class="floatleft table-width-file-depo tagss <?php print $folderdetails; print ' '; print $folderclass; ?>" ><?php print $LANG_tags ?></div>
    <?php if( $hide_folder_column != 'hide'  ) {
			print "<div class='floatleft table-width-file-depo folder-name $folderdetails $folderclass'>$LANG_folder</div>";
		} ?>
	<div class="floatleft table-width-file-depo text-center <?php print $folderdetails; print ' '; print $folderclass; ?>" ><?php print $LANG_date ?></div>
    <div class="floatleft table-width-file-depo text-center <?php print $folderdetails; print ' '; print $folderclass; ?>"><?php print "Size" ?></div>
    	<?php if( $hide_folder_column == 'hide'  ) {
    		print "<div class='floatleft table-width-file-depo text-center $folderclass $folderclass'>Folder/File(s)</div>";
    	}?>
    <div class="floatleft table-width-file-depo text-center <?php print $folderdetails; print ' '; print $folderclass; ?>"><?php print $LANG_action ?></div>
</div>
<div class="filedepotheading" style="display: <?php print $show_incomingheader ?>">
  <div class="floatleft"><input id="headerchkall" type="checkbox" value="all" onclick="toggleCheckedItems(this);"></div>
  <div class="floatleft" style="padding-left:35px;padding-right:10px;">
    <div class="floatleft"><?php print $LANG_filename ?></div>
  </div>

  <div class="floatright" style="padding-right:60px;">
    <div class="floatright"><?php print $LANG_action ?></div>
    <div class="floatright" style="padding-right:45px;"><?php print $LANG_submitted ?></div>
    <div class="floatright" style="padding-right:15px"><?php print $LANG_owner ?></div>
  </div>
</div>

