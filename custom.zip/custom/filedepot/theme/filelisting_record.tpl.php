<?php
/**
  * @file
  * filelisting_record.tpl.php
  */
global $base_url;
$folderclass = '';
if( $hide_folder_column == 'hide'  ) {
   $folderclass = 'fd-folder-class';
}
$folderdetails = '';
if( $hide_folder_column != 'hide'  ) {
   $folderdetails = 'fd-folder-details';
}

?> 

<div class="listing_record" id="folder_<?php print $subfolder_id ?>_rec_<?php print $fid ?>">
        <div class="floatleft table-width-file-depo file-name">
              <?php if( $bool_moreactions) {?>
                <?php  if($show_lock ==  'none'){ ?>        
                     
                     <input id="chkfile<?php print $fid ?>" type="checkbox" name="chkfile" value="<?php print $fid ?>"  onClick="updateCheckedItems(this)">
                <?php }else{ ?>
                      <input id="chkfile<?php print $fid ?>" type="checkbox" name="chkfiled" value=" " disabled /> 
                         
                <?php } ?>
            
            <?php }?>            
              <span>
                  <?php print $extension_icon ?>
              </span>
              <span class="filedetailslink">
                <?php 
                        $withoutExt = preg_replace('/\\.[^.\\s]{3,4}$/', '', $file_name);
                
                          if( $show_lock == 'none' ) {
                              echo "<a id='listingFilenameRec$fid' class='filedetailsdialog' href='$details_link_parms' TITLE='". $withoutExt ."'>".   $withoutExt ."</a>";
                        } else {
                              echo "<a id='listingFilenameRec$fid' href='#' class='filelocked' TITLE='". $withoutExt  ."'>".$withoutExt."</a>";                                
                        }
                ?>
              </span>
        </div>
          
              <div class="tags table-width-file-depo tagss <?php print $folderdetails; print ' '; print $folderclass; ?>" id="listingTagsRec<?php print $fid ?>">  <?php print $tags ?> </div>
              <?php if( $hide_folder_column != 'hide'  ) {
                          print "<div class='floatleft table-width-file-depo folder-name $folderdetails $folderclass'><a href='#' onClick='makeAJAXGetFolderListing( $subfolder_id );return false;'> $folder_name </a></div>";
                    }
              ?>
            <div class="floatleft table-width-file-depo text-center <?php print $folderdetails; print ' '; print $folderclass; ?>" ><?php print $modified_date ?></div>
            <div class="floatleft table-width-file-depo text-center <?php print $folderdetails; print ' '; print $folderclass; ?>"><?php print $total_size;?>&nbsp;</div>
            
            <?php if( $hide_folder_column == 'hide'  ) { ?>
                  <div class='floatleft table-width-file-depo  <?php echo $folderdetails .' '.$folderclass ?> '>&nbsp;&nbsp;&nbsp;</div>
            <?php  } ?>
            <div class="floatleft table-width-file-depo" style="display:<?php print $show_submitter ?>;"><?php print $submitter ?></div>

            <div class="floatleft table-width-file-depo text-center <?php print $folderdetails; print ' '; print $folderclass; ?>">
            
            <?php 
              if( $submitter == FALSE) {
                      if( $show_hide_g_docs_viewer ) {
                          
                            if(in_array($file_ext,array('jpg','png','gif')))
                            {
                                echo "<a href='$base_url/knowledge-repository-view-img-popup/$subfolder_id/$drupal_fid' title='View' target='_blank' class='use-ajax ctools-modal-image-view-in-kr'><i class='fa fa-eye'></i></a>&nbsp;";
                            }else{
                                echo "<a href='$base_url/knowledge-repository-google-docs-view/$subfolder_id/$drupal_fid' title='View' target='_blank'><i class='fa fa-eye'></i></a>&nbsp;";
                            }
                        }
                      if(isset($action1_link)) {
                         echo $action1_link;
                      }
                    ?>
                    <?php 
                       /**
                        *  if file is locked then make favorite, trash button should be disable
                        *  and user is not be able to perform other opration
                        */
                    ?>
                    <?php if ($show_favorite) { ?>
                        <?php if( $show_lock == 'none' ) { ?>
                            <a id="filedepot-favorite-<?php print $fid ?>" href="javascript:void(0);" onclick="makeAJAXToggleFavorite( <?php print $fid ?> );" title="<?php print $LANG_favorite_status ?>"><?php print $favorite_status_image ?></a>
                        <?php }else{ ?>
                            <a id="filedepot-favorite-<?php print $fid ?>" class="disabled" href="javascript:void(0);"  title="<?php print $LANG_favorite_status ?>"> <?php print $favorite_status_image ?></a>
                      <?php } } ?>
                      
                      <?php
                      if( $show_lock == 'none' ) {
                            echo "<a id='listingLockIconRec$fid' onclick='adminToggleFilelockList( $fid );' href='javascript:void(0);' title='Lock File' class='yuimenubaritemlabel $lock_delete_disabled'><i class='fa fa-unlock-alt '></i></a>";
                      } else {
                            echo "<a id='listingLockIconRec$fid' onclick='adminToggleFilelockList( $fid );' href='javascript:void(0);' title='Unlock File' class='yuimenubaritemlabel $lock_delete_disabled'><i class='fa fa-lock '></i></a>";
                      }
                    ?>
                    <?php  if($show_lock ==  'none'){ ?>
                         <a href="javascript:void(0)" class="<?php print $lock_delete_disabled; ?>" onclick="delete_list_active_file_folder( <?php print $fid ?>, 'file' );" title="Trash"><i class="fa fa-trash "></i></a>
                     <?php }else{ ?>
                         <a href="javascript:void(0)" class="<?php print $lock_delete_disabled; ?> disabled"  title="Trash"><i class="fa fa-trash "></i></a>
                     <?php } ?>
                     
                  <span><?php print $action2_link ?></span>
          <?php } 
          
          else { print $submitter; }?>
       </div>

</div>
<div id="subfolder<?php print $subfolder_id ?>_rec<?php print $fid ?>_bottom"><?php print $more_records_message ?></div>

