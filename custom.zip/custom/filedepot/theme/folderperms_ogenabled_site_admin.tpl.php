<?php
/**
  * @file
  * folderperms_ogenabled_site_admin.tpl.php
  */
// drupal_add_js(drupal_get_path('module', 'filedepot') .'/js/km_filedepot.js', 'file');
// drupal_add_js('jQuery(document).ready(function () { alert("Hello!"); });', 'inline');
?>


<div>
<form name="frmFolderPerms" method="POST">
<div id="filedepot-folder-perm-status"></div>
<input type="hidden" name="op" value="">
<div class="form-layout-default">

<!-- tabs  -->
<div class="quicktabs-wrapper">
<ul class="quicktabs-tabs">
    <li class="<?php print $perm_active_class?>"><a data-toggle="tab" href="#permissionoption">Share Options</a></li>
    <li class="<?php print $user_active_class?>"><a data-toggle="tab" href="#userassesrecord">Shared with</a></li>
    <!-- <li class="<?php // print $group_active_class?>"><a data-toggle="tab" href="#groupassesrecord">Community</a></li>  -->
  </ul>
  <div class="tab-content">
  <!-- menu 0   -->
    <div id="permissionoption" class="tab-pane fade <?php print $perm_active_class_tab?>">
    
	<!-- 
	<div class="form-group row">
      <label for="example-text-input" class="col-md-3 col-form-label">Select Users</label>
       <select name="selusers[]" class="col-md-9 input form-control"  multiple size=5 ><?php // print $user_options ?></select>
    </div>
	-->
	
	
	<!--  for user section  --> 
  <div id="myAutoComplete" class="form-group row" >
      <label class="control-label">Select User</label>
    <input id="myInputKR" type="text" class="form-control">
    <div id="myContainerKR" class="kr-autocomplete"></div>
    <div id="userConatiner" class="user-container form-group"> </div>
    <div id='hiddenSharVal'  style="display:none" > </div>
  </div>
	<!-- end -->
	
	
	<!-- 
    <div class="form-group row">
      <label for="example-text-input" class="col-md-3 col-form-label">Select Community</label>
       <select name="selgroups[]" multiple size=5 class="col-md-9 input form-control"><?php // print $group_options ?></select>
    </div> -->
	
	<?php   
       // this is community share input box. hide this functinnality for now
       // for site admin
       // chnage in future as requirement
    ?>
	<!-- 
      <div id="myAutoComplete" class="form-group row" >
          <label class="control-label">Select Community</label>
        <input id="myInputcommuntyKR" type="text" class="form-control">
        <div id="myContainerCommuntyKR" class="kr-autocomplete"></div>
          <div id="CumminityConatiner" class="user-container form-group"> </div>
        <div id='hiddenCommunityVal' style="display:none" > </div>
    
      </div> -->
	
	
	
      <div class="form-group row">
        <label for="example-text-input" class="col-form-label">Access Rights</label>
         <select class="input form-control" id="access_right_value" onchange="permSelectChange();" name="cb_access">
           <option value="view">View </option>
           <option value="uploader">Uploader</option>
           <!-- <option value="co-owner">Co-Owner</option>
           <option value="owner">Owner</option> -->
           <option value="administrator">Administrator</option>
         </select>
      </div>
      <div class="form-group row">
        <label for="example-text-input" class="col-form-label">Approver (s)</label>
        <div class="input-group form-radios">
          <div class="row">
            <div class="col-md-6">
              <div class="radio">
                <label class="disabled" id="first-app-label"><input type="radio" name="approver" value="first_level_approver"  id="feature5"> 
                <?php print t('First level approver') ?> </label>
              </div>
            </div>
            <div class="col-md-6">
              <div class="radio">
            <label class="disabled" id="sec-app-label"><input type="radio" name="approver" value="second_level_approver"  id="feature6"> 
            <?php print t('Second level approver') ?></label>
          </div>
              
            </div>
          </div>
          
          
        </div>
       <!--  <div class="col-md-9 padding0LR">
          <div class="col-md-6 padding0LR">
            <label class="disabled" id="first-app-label"><input type="radio" name="approver" value="first_level_approver"  id="feature5"> 
            <?php print t('First level approver') ?> </label>
          </div>
          <div class="col-md-6 padding0LR">
            <label class="disabled" id="sec-app-label"><input type="radio" name="approver" value="second_level_approver"  id="feature6"> 
            <?php print t('Second level approver') ?></label>
          </div>
        </div> -->
      </div>
      <div style="text-align:center;">
            <input type="button" name="submit" class="form-submit btn btn-primary" value="<?php print t('Submit'); ?>" onclick="makeAJAXUpdateFolderPerms(this.form);">
            <!-- <span style="padding-left:10px;"><input id="folderperms_cancel" type="button" class="form-submit" value="<?php print t('Close'); ?> "></span> -->
            <input type="hidden" name="catid" value="<?php print $catid ?>">
            <input type="hidden" id="folderpermstoken" name="token" value="<?php print $token ?>">
      </div>
    </div>
    <!-- end menu 0   -->
    <!-- menu 1   -->
    <div id="userassesrecord" class="tab-pane fade <?php print $user_active_class_tab?>">
      <table class="table table-hover table-striped">
        <tr>
          <td align="left"><?php print t('User'); ?></td>
          <td>Permission</td>
          <td>Approver</td>
          <td>Action</td>
        </tr>
        <?php print $user_perm_records ?>
      </table>
    </div>
    <!-- end menu 1   -->
    <!-- end menu 2   -->
    <div id="groupassesrecord" class="tab-pane fade <?php print $group_active_class_tab?>">
    <table class="table table-hover table-striped">  
      <tr>
        <td align="left"><?php print t('Community'); ?></td>
          <td>Permission</td>
          <td>Approver</td>
          <td>Action</td>
      </tr>
      <?php print $group_perm_records ?>
    </table>
    </div>
    <!-- end menu 2   -->
  </div>
</div>
<!-- end Tabs  --> 
</div>
<div class="clearboth"></div>
<!-- <?php  print drupal_render( $first_level_approver ); print drupal_render( $second_level_approver ); ?> -->
</form>
</div>
