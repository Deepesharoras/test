<?php
/**
  * @file
  * folderperm_record_site_admin.tpl.php
  */
?>  

<tr>
  <td width="20%" align="left"><?php print $name ?></td>
  <td><?php print $permission ?></td>
  <td><?php print $approver ?></td>
  <td><a class="deleteperm" href="?accid=<?php print $accid ?>&active_mode=<?php print $mode?>"><?php print $LANG_delete ?></a></td>
</tr>