<?php global $base_url;?>
<div id="subfolder<?php print $folder_id ?>" class="subfolder listing_record">
  <div>
    <div class="folder_withhover" style="width:100%;">
      <div class="floatleft table-width-file-depo file-name">
        <span class="folder-icon-margin"><a href="#"><i class="fa fa-folder-o"></i></a></span>
        <span ><?php print '';//print $folder_number; ?></span>
        <span class="folderlink" title="<?php print $folder_name; ?>" ><?php print $folder_name ?></span>
      </div>
     <!--  <div class="floatleft table-width-file-depo tagss">&nbsp; &nbsp;&nbsp; &nbsp; </div>
      <div class="floatleft table-width-file-depo folder-name">&nbsp; &nbsp;&nbsp; &nbsp; </div> -->
      <div class="floatleft table-width-file-depot-share text-center" ><?php print $last_modified_date ?>&nbsp;</div>
      <div class="floatleft table-width-file-depot-share text-center" ><?php print $total_size;?>&nbsp;</div>
      <div class="floatleft table-width-file-depot-share text-center" ><?php print $folder_count; print ' / '. $file_count ?>&nbsp;</div>
      <div id="trashfolder<?php print $folder_id ?>" class="floatleft table-width-file-depot-share text-center"><a href="javascript:void(0);" onclick="trashAction( 'restore', <?php print $folder_id ?>, 'folder' );" title="Restore"><i class="fa fa-undo"></i></a>
      <!--  <a href="#" onclick="trashAction( 'permanent-delete', <?php // print $folder_id ?>, 'folder' );" title="Delete"><i class="fa fa-trash"></i></a> -->
      </div>
    </div>
  </div>
</div>