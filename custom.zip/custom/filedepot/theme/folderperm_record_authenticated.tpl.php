<?php
/**
 * @file
 * folderperm_record.tpl.php
 * 
 *  onclick="deleteShareFolderPermission(this,event)"
 */
?>

<tr align="center" style="border-top:1px solid #CCC;">
  <td align="left"><?php print $name ?></td>
  <td><?php print $permission?></td>
  <td><a class="deleteperm"  href="?accid=<?php print $accid ?>&active_mode=<?php print $mode?>"><?php print $LANG_delete ?></a></td>
</tr>