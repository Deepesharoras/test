<?php
/**
  * @file
  * taglink_record.tpl.php
  */
?>  


<a href="#" onClick="makeAJAXSearchTags('<?php print $searchtag ?>');return false;"><?php print $label ?></a>

