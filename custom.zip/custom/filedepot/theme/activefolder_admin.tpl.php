<?php
/**
  * @file
  * activefolder_admin.tpl.php
  */
global $user;
?>
<?php if( '0' == $parent_id){ ?>
	<div id="activefolder"><span><?php print $active_folder_name ?></span></div>
<?php } else { ?>
	<div id="activefolder"><a href="#" data-toggle="modal" data-target="#edit_activefolder" title="click to edit - <?php echo $active_folder_name ;?> <?php // print $LANG_click_adminmsg ?>" > <?php print $active_folder_name ?> <i class="fa fa-pencil" aria-hidden="true"></i></a></div>
<?php }?>
<?php if( isset( $parent_id ) && ( $parent_id != '0' ) ) {?>
	<div class="back-button" title="Up one level"> <a onclick="YAHOO.filedepot.showfiles(<?php print $parent_id; ?>);return false;" ><i class="fa fa-arrow-up" aria-hidden="true"></i></a></div>
<?php } else {?>
	<!-- NO NEED TO DISPLAY BACK BUTTON -->
	<div class="back-button disabled"><a><i class="fa fa-arrow-up" aria-hidden="true"></i></a></div>	
<?php } ?>
<div id="edit_activefolder" class="modal fade" role="dialog">
   <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Folder Setting</h4>
            <!-- <div class="folder-setting-title page-header">   -->
      <!--  <button type="button" value="<?php print t('&times;'); ?>" class="form-submit close" onClick="toggleElements('edit_activefolder','activefolder');"><?php print t('&times;'); ?> </button> -->
     <!-- </div> -->
      </div>
      <div class="modal-body">
  <form name="frm_activefolder" method="post" action="<?php print $ajax_server_url ?>">
   	  <?php if( $bool_dropzone) {?>
      	<input type="hidden" name="current_folder_id" value="<?php print $active_category_id ?>">
      <?php }?>
      	<input type="hidden" name="active_left_menu" value="<?php print $active_left_menu?>">

    <input type="hidden" name="op" value="updatefolder">
    <input type="hidden" name="cid" value="<?php print $active_category_id ?>">
    <div class="folder-setting-body">
    <div id="perm-update-alert">
    </div>
      <div class="form-group">
        <label class="control-label" for="">Folder Name: <span class="form-required" title="This field is required.">*</span> <a href="#" data-toggle="tooltip" title="" data-original-title="Enter the folder name of length 3 - 55  characters and it can be alphanumeric."><i class="fa fa-question-circle" aria-hidden="true"></i></a></label>
        <input type="text" name="categoryname" class="form-control form-text" id="folder-name-error" value="<?php print $active_folder_name ?>">
      </div>
      <div class="form-group">
        <label class="control-label" for=""><?php print t('Parent Folder'); ?> <span class="form-required" title="This field is required.">*</span> <a href="#" data-toggle="tooltip" title="" data-original-title="Select the folder name from the drop down."><i class="fa fa-question-circle" aria-hidden="true"></i></a></label>
        <select id="folder_parent" name="catpid" class="form-control form-select">
              <?php print $folder_parent_options ?>
            </select>
      </div>
      <div class="form-group">
        <label for="" class="control-label"><?php print $LANG_description ?> <a href="#" data-toggle="tooltip" title="" data-original-title="Enter the description maximum in 100 characters."><i class="fa fa-question-circle" aria-hidden="true"></i></a></label>
        <textarea name="catdesc" class="form-textarea form-control" rows="3"><?php print $folder_description ?></textarea>
      </div>
      <?php if(variable_get('filedepot_override_folderorder', 0) == 0) { ?>
        <div class="form-group">
          <label for="" class="control-label"><?php print $LANG_folderorder ?>:</label>
          <input type="text" name="folderorder" class="form-text" value="<?php print $folderorder ?>" size="5"><span class="pluginTinyText" style="padding-left:10px;"><?php print $LANG_folderordermsg ?></span>
        </div>
      <?php } ?>
      <?php  // FOR KR  bellow html code will hide due to no  need to display it to user because this is default funcationaity  ?>      
      <div class="form-actions form-group">
             <input type="button" value="<?php print t('Update'); ?>" data-dismiss="modal" class="form-submit btn btn-primary" onClick="makeAJAXUpdateFolderDetails(this.form)"/>
             <span class="deletebuttonborder">
              <input type="button" value="<?php print t('Delete'); ?>" class="form-submit btn btn-default" onclick="delete_activefolder(this.form);">
            </span>
            <span>
              <input type="button" value="<?php print t('Permissions'); ?>" class="form-submit btn btn-info" onClick="makeAJAXShowFolderPerms(this.form);">
            </span>
        </div>
    </div>
    <div class="clearboth" style="padding-bottom:10px;"></div>
    <input type="hidden" name="token" value="<?php print $token ?>" />
  </form>
</div>
</div>
</div>
</div>