<?php
/**
  * @file
  * filelisting_emptyfolder.tpl.php
  */
?>  

<div id="emptyfolder_{folder_id}" class="listing_record emptyfolder parentfolder{parent_folder_id}">
        <div id="emptyfolder{folder_id}_contents" class="filedesc" style="padding-left:{folder_desc_padding_left}px;">Folder contains no files</div>
</div>