<?php
/**
  * @file
  * filelisting_subfolder.tpl.php
  * 
  * this file will use in filelisting url and only for folder 
  * 
  * 
  */
$folderclass = '';
if( $hide_folder_column == 'hide'  ) {
   $folderclass = 'fd-folder-class';
}


?>  


<div id="subfolder<?php print $folder_id ?>" class="subfolder listing_record parentfolder<?php print $parent_folder_id ?>">
    <div class="folder_withhover" style="width:100%;">
      <div class="floatleft table-width-file-depo file-name" >
      	<?php if( $bool_moreactions ) {?>
            <input id="filedepot-chk-<?php print $folder_id ?>" type="checkbox" name="chkfolder" value="<?php print $folder_id ?>" onclick="toggleCheckedItems(this,'<?php print $folder_files ?>');">
        <?php }else{ ?>
            <input  data-display="none" style="display:none" id="filedepot-chk-<?php print $folder_id ?>" type="checkbox" name="chkfolder" value="<?php print $folder_id ?>" onclick="toggleCheckedItems(this,'<?php print $folder_files ?>');">
        <?php } ?>
        
        <span id="subfolder_icon<?php print $folder_id ?>" class="icon-folderclosed" style="padding:0px 5px;" onClick="togglefolder(<?php print $folder_id ?>);">&nbsp;</span>
        <span><a href="javascript:void(0);">  <i class="fa fa-folder-o" title="Folder"></i> </a></span>
        <span><?php print '';//print $folder_number; ?></span>
        <span class="folderlink"><a href="javascript:void(0);" title="<?php print $folder_name; ?>" onClick="makeAJAXGetFolderListing(<?php print $folder_id ?>);return false;"><?php print $folder_name ?></a></span>
      </div>
      <div class="floatleft table-width-file-depo tagss <?php print $folderclass ?>">&nbsp; &nbsp;&nbsp; &nbsp; </div>
      <?php if( $hide_folder_column != 'hide'  ) {
      	print "<div class='floatleft table-width-file-depo folder-name $folderclass'>&nbsp; &nbsp;&nbsp; &nbsp; </div>";
      }?>
      <div class="floatleft table-width-file-depo text-center <?php print $folderclass ?>" ><?php print $last_modified_date ?>&nbsp;</div>
      <div class="floatleft table-width-file-depo text-center <?php print $folderclass ?>"><?php print $total_size;?>&nbsp;</div>
      <div class="floatleft table-width-file-depo text-center <?php print $folderclass ?>" ><?php print $folder_count; print ' / '. $file_count ?>&nbsp;</div>
      <div id="sharefolder<?php print $folder_id ?>" class="floatleft table-width-file-depo text-center <?php print $folderclass ?>">
        
          <a href="javascript:void(0);" onclick="download_archive( <?php print $folder_id ?> );" title="Download"><i class="fa fa-download"></i></a>
        
        <?php if( $share == 'allow' ) {
            print "<a href='javascript:void(0)' onclick='makeAJAXShowFolderListPerms( $folder_id );' title='Click to share.'><i class='fa fa-share-alt'></i></a>&nbsp;";
          } else {
            print "<a href='javascript:void(0)' class='disabled' title='Click to share. ><i class='fa fa-share-alt'></i></a>&nbsp;";
          }
          if( $delete_perm == 'allow' ) {
            print "<a href='javascript:void(0)' onclick='delete_list_active_file_folder( $folder_id, \"folder\" );' title='Trash'><i class='fa fa-trash'></i></a>";
          } else {
            print "<a href='javascript:void(0)' class='disabled' title='Trash'><i class='fa fa-trash'></i></a>";
          }
        ?> 		
      </div>
    </div>
</div>
<div class="clearfix"></div>
<div class="subfolder_container custom-subfolder-container" id="subfolder<?php print $folder_id ?>_contents" style="display:none;">
  <?php print $subfoldercontent ?>
<div id="subfolderlisting<?php print $folder_id ?>_bottom"></div>
</div> <!-- end of subfolder container -->
<div id="subfolder<?php print $folder_id ?>_bottom"></div>
