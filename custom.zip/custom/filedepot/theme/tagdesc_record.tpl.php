<?php
/**
  * @file
  * tagcloud_record.tpl.php
  */
?>  

<div class="listing_activetag"><?php print $label ?></div>
