<?php
/**
  * @file
  * tagcloud_record.tpl.php
  */
?>  

<span><a class="tagcloudword" href="#"><?php print $tag ?></a></span>
