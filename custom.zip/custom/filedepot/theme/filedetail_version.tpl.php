<?php
/**
  * @file
  * filedetail_version.tpl.php
  */
?>
<div class="clearfix"></div><br/>
<table width="100%" border="0" cellspacing="2" cellpadding="0">
    <tr class="pluginRow<?php print $cssid ?>">
        <td class="aligntop" style="padding-left:10px;padding-top:10px;">
           <!--  <img src="<?php // print $fileicon ?>">  -->
            <?php echo $fileicon; ?> &nbsp;
            <a href="<?php print url('knowledge-repository_download/' . $nid . '/' . $fid . '/' . $file_version, array('absolute' => true)); ?>" TITLE="<?php print t('Download File');?>"><strong><?php print $vname ?></strong>
            </a>&nbsp;
            <span style="font-size:9pt;"><?php print $file_versionnum ?></span>
        </td>
        <td width="15%" class="alignright" style="padding-top:10px;" nowrap>
            <span style="font-size:8pt;">
                <strong><?php print t('Date'); ?>:</strong>&nbsp;
                <?php print $ver_shortdate ?><br />
                <strong><?php print t('Size'); ?>:</strong>&nbsp;
                <?php print $ver_size ?>
            </span>
        </td>
    </tr>
    <tr class="pluginRow<?php print $cssid ?>">
        <td colspan="2" style="padding-left:10px;">
            <strong><?php print t('Version Note'); ?>:</strong>
            <span id="detaildisp<?php print $fid ?>v<?php print $file_version ?>">
                <?php print $version_note ?>
            </span>
            <div id="detailedit<?php print $fid ?>v<?php print $file_version ?>" style="display:none;">
                <form method="post" style="margin:0px;padding:0px;">
                    <input type="hidden" name="op" value="">
                    <input type="hidden" name="fid" value="<?php print $fid ?>">
                    <input type="hidden" name="version" value="<?php print $file_version ?>">
                    <textarea name="note" rows="3" cols="75"><?php print $edit_version_note ?></textarea>
                    <div style="padding-top:5px;padding-left:200px;">
                      <input class="form-submit" type="button" value="<?php print t('Update'); ?>" onclick="doAJAXEditVersionNote(this.form)"><span style="padding-left:10px;">
                      <input type="button" class="form-submit" value="<?php print t('Cancel'); ?>" onClick="toggleElements('detaildisp<?php print $fid ?>v<?php print $file_version ?>','detailedit<?php print $fid ?>v<?php print $file_version ?>');return false;"></span>
                    </div>
                </form>
            </div>
        </td>
    </tr>
    <tr class="pluginRow<?php print $cssid ?>">
        <td colspan="2">
            <span><?php print t('Author'); ?>:&nbsp;<?php print $ver_author ?>&nbsp;&nbsp;</span>
            <span class="pull-right" style="display:<?php print $show_delete_version;?>"><a href="#" class="text-decoration" onclick="doAJAXDeleteVersion(<?php print $fid ?>,<?php print $file_version ?>)"><?php print t('Delete File'); ?></a>&nbsp;&nbsp;</span>
            <span class="pull-right" style="display:<?php print $show_edit_version;?>"><a href="#" class="text-decoration" onClick="toggleElements('detaildisp<?php print $fid ?>v<?php print $file_version ?>','detailedit<?php print $fid ?>v<?php print $file_version ?>');return false;"><?php print t('Edit File'); ?></a>&nbsp;&nbsp;</span>
            <span class="pull-right"><a class="text-decoration" href="<?php print url('knowledge-repository_download/' . $nid . '/' . $fid . '/' . $file_version, array('absolute' => true)); ?>"><?php print t('Download File'); ?></a>&nbsp;&nbsp;</span>
        </td>
    </tr>
</table>
<div class="clearfix"></div><br/>