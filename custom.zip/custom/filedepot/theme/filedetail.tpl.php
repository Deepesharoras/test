<?php
/**
  * @file
  * filedetail.tpl.php
  */
global $base_url;
?>
<!-- File Details Panel content - used by the AJAX server.php function nexdocsrv_filedetails() -->
<div class="filedepot-detail-scroll">
<table class="plugin table table-bordered">
    <tr>
          <?php if ($reportmode == 'approvals') { ?>
            <td colspan='4'> <?php echo $fileicon; ?> <!-- <img src="<?php // print $fileicon; ?>"> -->  <!--  &nbsp;<strong><?php // print $filetitle ?></strong>&nbsp;<span style="font-size:8pt;"><?php  // print $current_version ?></span> -->
            <?php 
               $ext = substr($filetitle,strrpos($filetitle,'.',-1),strlen($filetitle));
               // echo $ext;
               
               
               ?>
               <?php 
                   /* if(in_array($extension,array('jpeg','jpg','png'))){
                       drupal_goto($google_doc_url);
                   }else if(in_array($extension,array('pdf','txt'))){
                       drupal_goto($google_doc_url);
                   }else{ */
               ?>
               
               &nbsp; <strong>
               <?php  
               $withoutExt = preg_replace('/\\.[^.\\s]{2,3,4}$/', '', $filetitle);
               
               if(in_array($ext,array('.jpeg','.jpg','.png'))) { ?>
                    <a href="<?php echo $base_url .'/knowledge-repository-moderater-image-popup/'.$cid.'/'.$fid ?>"  class="use-ajax" > <?php print $withoutExt ?> </a>
               <?php }else{ ?>
                    <a target="_blank" href="<?php echo $base_url .'/knowledge-repository-moderater-excel-view/'.$cid.'/'.$fid ?>"   > <?php print $withoutExt ?> </a>
               <?php }?>
               <strong> </strong>&nbsp;<span style="font-size:8pt;"><?php print $current_version ?></span>
            </td>
            
          
          <?php } else { ?>
          	<?php if( 1 != variable_get( 'filedepot_google_docs_viewer', 1 ) ) { ?>
            	<td colspan="4"><img src="<?php print $fileicon; ?>">&nbsp;<a href="<?php print url('filedepot', array('query' => array('cid' => $cid, 'fid' => $fid), 'absolute' => true)); ?>" title="<?php print t('Direct link to file'); ?>" <?php print $disable_download ?>><strong><?php print substr($filetitle,0,255) ?></strong></a>&nbsp;<span style="font-size:8pt;"><?php print $current_version ?></span></td>
           	<?php } else { 
           	    // echo "<div style='padding-bottom:10px;'> <img src='$fileicon'>&nbsp;<a href='$base_url/knowledge-repository-google-docs-view/$cid/$dfid' title='View' target='_blank' $disable_download > <strong>$filetitle</strong></a>&nbsp;&nbsp;<span style='font-size:8pt;'>$current_version </span></div>";
           	    
           	    $withoutExt = preg_replace('/\\.[^.\\s]{3,4}$/', '', $filetitle);
           	    
           	    // $file_named = substr($filetitle,0,255);
           	    echo "<td colspan='4'> $fileicon &nbsp;<a href='$base_url/knowledge-repository-google-docs-view/$cid/$dfid' title='View' target='_blank' $disable_download > <strong> $withoutExt </strong></a>&nbsp;&nbsp;<span style='font-size:8pt;'>$current_version </span></td>";
           	} ?>
          <?php } ?>
        </tr>
          <tr>
            <td><strong><?php print t('File Name'); ?>:</strong></td>
            <td><?php print $real_filename ?></td>
            <td><strong><?php print t('Date'); ?>:</strong></td>
            <td><?php // print $shortdate 
                    // $var = "20/04/2012";
                    print date("d-M-Y", strtotime($shortdate));
                ?>
                </td>
          </tr>
          <tr>
            <td><strong><?php print t('Folder'); ?>:</strong></td>
            <td><?php print $foldername ?></td>
            <td><strong><?php print t('Author'); ?>:</strong></td>
            <td> </td>
          </tr>
          <tr>
            <td><strong><?php print t('Size'); ?>:</strong></td>
            <td><?php print $size ?></td>
            <td><strong><?php print t('Version Note'); ?>:</strong></td>
            <td><?php print $current_ver_note ?></td>
           <!--  <td><strong><?php print t('Date'); ?>:</strong></td>
            <td><?php print $shortdate ?></td> -->
          </tr>
            <!-- 
            <div class="col-md-2 padding0LR" ><strong><?php print t('File Name'); ?>:</strong></div>
            <div class="col-md-10 padding0LR" ><?php print $real_filename ?></div>
            <div class="col-md-2 padding0LR" ><strong><?php print t('Folder'); ?>:</strong></div>
            <div class="col-md-4 padding0LR"><?php print $foldername ?></div>
            <div class="col-md-2 padding0LR" ><strong><?php print t('Author'); ?>:</strong></div>
            <div class="col-md-4 padding0LR"><strong><?php print t('Author'); ?>:</strong></div>
            <div class="col-md-2 padding0LR"><strong><?php print t('Tags'); ?>:</strong></div>
            <div class="col-md-4 padding0LR" style="font-size:9pt;"><?php print $tags ?></div>
            <div class="col-md-2 padding0LR"><strong><?php print t('Date'); ?>:</strong> / <strong><?php print t('Size'); ?>:</strong></div>
            <div class="col-md-4 padding0LR"><?php print $shortdate ?> / &nbsp;<?php print $size ?></div> 
            -->
            <!-- <tr>
                    <td width="15%" class="alignright" style="font-size:8pt;" nowrap>
                    <div id="lockedalertmsg" class="pluginAlert" style="display:<?php print $show_statusmsg ?>;"><?php print $statusmessage ?></div>
                    </td>
                </tr> 
            -->
     <tr>
        <td><strong><?php print t('Tags'); ?>:</strong></td>
        <td colspan="3"><?php print $tags ?></td>
    </tr>
    <tr>
        <td><strong><?php print t('Description'); ?>:</strong></td>
        <td colspan="3"><?php print $description ?></td>
    </tr>
</table>
<?php print $version_records ?>
</div>