<?php

/**
 * @file
 * lib-common.php
 * Common library of functions for the applications
 */



function firelogmsg($message) {
	global $firephp, $mytimer;
	$exectime = timer_read('filedepot_timer');
	if (function_exists('dfb')) {  // Calls the firephp fb() function to log message to the firebug console
		dfb("$message - time:$exectime");
	}
}


/**
 * Returns a formatted listbox of categories user has access
 * First checks for View access so that delegated admin can be just for sub-categories
 * @param        string|array        $perms        Single perm 'admin' or array of permissions as required by $filedepot->checkPermission()
 * @param        int                 $selected     Will make this item the selected item in the listbox
 * @param        string              $id           Parent category to start at and then recursively check
 * @param        string              $level        Used by this function as it calls itself to control the indent formatting
 * @return       string                            Return an array of folder options
 */
function filedepot_recursiveAccessArray($perms, $id = 0, $level = 1) {
	$filedepot = filedepot_filedepot();
	$options_tree = array();
	if ($filedepot->ogmode_enabled AND !empty($filedepot->allowableGroupViewFoldersSql)) {
		if ($id == 0) {
			$id = $filedepot->ogrootfolder;
		}
	}
	
	// Exclude community organization drive this is custom requirment Parent id 169
	$query = db_query("SELECT cid,pid,name FROM {filedepot_categories} WHERE pid=:pid and cid !=:cid ORDER BY cid",
			array(':pid' => $id,':cid' => 169));
	
	while ($A = $query->fetchAssoc()) {
		list($cid, $pid, $name) = array_values($A);
		$indent = ' ';
		// Check if user has access to this category
		if ($filedepot->checkPermission($cid, 'view')) {
			// Check and see if this category has any sub categories - where a category record has this cid as it's parent
			$tempcid = db_query("SELECT cid FROM {filedepot_categories} WHERE pid=:cid", array(':cid' => $cid))->fetchField();
			if ($tempcid > 0) {
				if ($level > 1) {
					for ($i = 2; $i <= $level; $i++) {
						$indent .= "--";
					}
					$indent .= ' ';
				}
				if ($filedepot->checkPermission($cid, $perms)) {
					if ($indent != '') {
						$name = " $name";
					}
					$options_tree[$cid] = $indent . $name;
					$options_tree += filedepot_recursiveAccessArray($perms, $cid, $level + 1);
				}
				else {
					// Need to check for any folders with admin even subfolders of parents that user does not have access
					$options_tree += filedepot_recursiveAccessArray($perms, $cid, $level + 1);
				}
			}
			else {
				if ($level > 1) {
					for ($i = 2; $i <= $level; $i++) {
						$indent .= "--";
					}
					$indent .= ' ';
				}
				if ($filedepot->checkPermission($cid, $perms)) {
					if ($indent != '') {
						$name = " $name";
					}
					$options_tree[$cid] = $indent . $name;
				}
			}
		}
	}
	return $options_tree;
}


/**
 * Returns a formatted listbox of categories user has access
 * First checks for View access so that delegated admin can be just for sub-categories
 *
 * @param        string|array        $perms        Single perm 'admin' or array of permissions as required by $filedepot->checkPermission()
 * @param        int                 $selected     Will make this item the selected item in the listbox
 * @param        string              $id           Parent category to start at and then recursively check
 * @param        string              $level        Used by this function as it calls itself to control the indent formatting
 * @param        boolean             $addRootOpt   Add the 'Top Level Folder' option, when appropriate.  Defaults to @c TRUE.
 * @return       string                            Return a formatted HTML Select listbox of categories
 */
function filedepot_recursiveAccessOptions($perms, $selected = '', $id = '0', $level = '1', $addRootOpt = TRUE) {
	$filedepot = filedepot_filedepot();
	$selectlist = '';
	if ($filedepot->ogmode_enabled AND !empty($filedepot->allowableGroupViewFoldersSql)) {
		if ($id == 0) {
			$id = $filedepot->ogrootfolder;
		}
		if ($addRootOpt AND $level == 1 AND user_access('administer filedepot')) {
			$selectlist = '<option value="'.$filedepot->ogrootfolder.'">' . t('Top Level Folder') . '</option>' . LB;
		}
	} else {
		if ($addRootOpt AND $level == 1 AND user_access('administer filedepot')) {
			$selectlist = '<option value="0">' . t('Top Level Folder') . '</option>' . LB;
		}
	}
	$query = db_query("SELECT cid,pid,name FROM {filedepot_categories} WHERE pid=:cid ORDER BY cid", array(':cid' => $id));
	while ($A = $query->fetchAssoc()) {
		list($cid, $pid, $name) = array_values($A);
		$name = filter_xss($name);
		$indent = ' ';
		
		// if user have not authorized to view 169 through Kknowladge Reposotory section.
		if($cid == 169){
		    continue; 
		}
		
		// Check if user has access to this category
		if ($filedepot->checkPermission($cid, 'view')) {
			// Check and see if this category has any sub categories - where a category record has this cid as it's parent
			
			
			$tempcid = db_query("SELECT cid FROM {filedepot_categories} WHERE pid=:cid", array(':cid' => $cid))->fetchField();
			if ($tempcid > 0) {
				if ($level > 1) {
					for ($i = 2; $i <= $level; $i++) {
						$indent .= "--";
					}
					$indent .= ' ';
				}
				if ($filedepot->checkPermission($cid, $perms)) {
					if ($indent != '') {
						$name = " $name";
					}
					$selectlist .= '<option value="' . $cid;
					if ($cid == $selected) {
						$selectlist .= '" selected="selected">' . $indent . $name . '</option>' . LB;
					}
					else {
						$selectlist .= '">' . $indent . $name . '</option>' . LB;
					}
					$selectlist .= filedepot_recursiveAccessOptions($perms, $selected, $cid, $level + 1, $addRootOpt);
				}
				else {
					// Need to check for any folders with admin even subfolders of parents that user does not have access
					
					
					$selectlist .= filedepot_recursiveAccessOptions($perms, $selected, $cid, $level + 1, $addRootOpt);
				}
				
			}
			else {
				if ($level > 1) {
					for ($i = 2; $i <= $level; $i++) {
						$indent .= "--";
					}
					$indent .= ' ';
				}
				
				if ($filedepot->checkPermission($cid, $perms)) {
					if ($indent != '') {
						$name = " $name";
					}
					$selectlist .= '<option value="' . $cid;
					if ($cid == $selected) {
						$selectlist .= '" selected="selected">' . $indent . $name . '</option>' . LB;
					}
					else {
						$selectlist .= '">' . $indent . $name . '</option>' . LB;
					}
				}
			}
		}
	}
	return $selectlist;
}


function filedepot_recursiveAccessOptionsSkipOrganizationalDrive($perms, $selected = '', $id = '0', $level = '1', $addRootOpt = TRUE) {
  $filedepot = filedepot_filedepot();
  $selectlist = '';
  if ($filedepot->ogmode_enabled AND !empty($filedepot->allowableGroupViewFoldersSql)) {
    if ($id == 0) {
      $id = $filedepot->ogrootfolder;
    }
    if ($addRootOpt AND $level == 1 AND user_access('administer filedepot')) {
      $selectlist = '<option value="'.$filedepot->ogrootfolder.'">' . t('Top Level Folder') . '</option>' . LB;
    }
  } else {
    if ($addRootOpt AND $level == 1 AND user_access('administer filedepot')) {
      $selectlist = '<option value="0">' . t('Top Level Folder') . '</option>' . LB;
    }
  }
  //14 - OrganizationalDrive
  if( '14' != $id ) {
    $query = db_query("SELECT cid,pid,name FROM {filedepot_categories} WHERE pid=:cid and cid !=:ncid ORDER BY cid", array(':cid' => $id,':ncid' => 169 ));
    
    while ($A = $query->fetchAssoc()) {
      list($cid, $pid, $name) = array_values($A);
      $name = filter_xss($name);
      $indent = ' ';
      // Check if user has access to this category
      
      
      if ($filedepot->checkPermission($cid, 'view')) {
        // Check and see if this category has any sub categories - where a category record has this cid as it's parent
        
        
        $tempcid = db_query("SELECT cid FROM {filedepot_categories} WHERE pid=:cid", array(':cid' => $cid))->fetchField();
        if ($tempcid > 0) {
          if ($level > 1) {
            for ($i = 2; $i <= $level; $i++) {
              $indent .= "--";
            }
            $indent .= ' ';
          }
          if ($filedepot->checkPermission($cid, $perms)) {
            if ($indent != '') {
              $name = " $name";
            }
            $selectlist .= '<option value="' . $cid;
            if ($cid == $selected) {
              $selectlist .= '" selected="selected">' . $indent . $name . '</option>' . LB;
            }
            else {
              $selectlist .= '">' . $indent . $name . '</option>' . LB;
            }
            $selectlist .= filedepot_recursiveAccessOptionsSkipOrganizationalDrive($perms, $selected, $cid, $level + 1, $addRootOpt);
          }
          else {
            // Need to check for any folders with admin even subfolders of parents that user does not have access
            
            
            $selectlist .= filedepot_recursiveAccessOptionsSkipOrganizationalDrive($perms, $selected, $cid, $level + 1, $addRootOpt);
          }
          
        }
        else {
          if ($level > 1) {
            for ($i = 2; $i <= $level; $i++) {
              $indent .= "--";
            }
            $indent .= ' ';
          }
          
          if ($filedepot->checkPermission($cid, $perms)) {
            if ($indent != '') {
              $name = " $name";
            }
            $selectlist .= '<option value="' . $cid;
            if ($cid == $selected) {
              $selectlist .= '" selected="selected">' . $indent . $name . '</option>' . LB;
            }
            else {
              $selectlist .= '">' . $indent . $name . '</option>' . LB;
            }
          }
        }
      }
    }
  }
  return $selectlist;
}

/* Recursive Function to navigate down folder structure
 * and determine most recent file data and set last_modified_date for each subfolder
 * Called after a file is added or moved to keep folder data in sync.
 */
function filedepot_updateFolderLastModified($id) {
	$last_modified_parentdate = 0;
	if (db_query("SELECT cid FROM {filedepot_categories} WHERE cid=:cid", array(':cid' => $id))->fetchField() > 0) {
		$q1 = db_query("SELECT cid FROM {filedepot_categories} WHERE pid=:cid ORDER BY folderorder ASC", array(':cid' => $id));
		while ($A = $q1->fetchAssoc()) {
			$last_modified_date = 0;
			$q2 = db_query_range("SELECT date FROM {filedepot_files} WHERE cid=:cid ORDER BY date DESC",
					0, 1, array(':cid' => $A['cid']));
			$B = $q2->fetchAssoc();
			if ($B['date'] > $last_modified_date) {
				$last_modified_date = $B['date'];
			}
			if (db_query("SELECT pid FROM {filedepot_categories} WHERE cid=:cid", array(':cid' => $A['cid']))->fetchField() > 0) {
				$latestdate = filedepot_updateFolderLastModified($A['cid']);
				if ($latestdate > $last_modified_date) {
					$last_modified_date = $latestdate;
				}
			}
			db_query("UPDATE {filedepot_categories} SET last_modified_date=:time WHERE cid=:cid",
					array(':time' => $last_modified_date, ':cid' => $A['cid']));
			if ($last_modified_date > $last_modified_parentdate) {
				$last_modified_parentdate = $last_modified_date;
			}
		}
		db_query("UPDATE {filedepot_categories} SET last_modified_date=:time WHERE cid=:cid",
				array(':time' => $last_modified_parentdate, ':cid' => $id));
	}
	$q4 = db_query("SELECT date FROM {filedepot_files} WHERE cid=:cid ORDER BY date DESC", array(':cid' => $id));
	$C = $q4->fetchAssoc();
	if ($C['date'] > $last_modified_parentdate) {
		$last_modified_parentdate = $C['date'];
	}
	db_query("UPDATE {filedepot_categories} SET last_modified_date=:time WHERE cid=:cid",
			array(':time' => $last_modified_parentdate, ':cid' => $id));
	
	return $last_modified_parentdate;
}


/* Return the toplevel parent folder id for a subfolder */
function filedepot_getTopLevelParent($cid) {
	$pid = db_query("SELECT pid FROM {filedepot_categories} WHERE cid=:cid", array(':cid' => $cid))->fetchField();
	if ($pid == 0) {
		return $cid;
	}
	else {
		$cid = filedepot_getTopLevelParent($pid);
	}
	return $cid;
}

function filedepot_checkParentFolderExistInTrash($cid, $i = 0) {
  $pid = db_query("SELECT pid FROM {filedepot_categories} WHERE cid=:cid", array(':cid' => $cid))->fetchField();
  $bool_in_trash = db_query("SELECT cid FROM {filedepot_trash} WHERE cid=:pid AND bool_in_trash = 1", array(':pid' => $pid))->fetchAssoc();
  if ($pid == 0) {
      return array( 'bool_in_trash' => FALSE );
  }
  else {
    if( $bool_in_trash == FALSE && $i > 0 ) {
        return array( 'bool_in_trash' => TRUE, 'pid' => $cid );
    }
    if( $bool_in_trash ) {
      $arr_results = filedepot_checkParentFolderExistInTrash($pid, ++$i);
    } else {
      return array( 'bool_in_trash' => FALSE );
    }
  }
  return $arr_results;
}

function filedepot_checkParentFolderPermanentDelete($cid) {
  $pid = db_query("SELECT pid FROM {filedepot_categories} WHERE cid=:cid", array(':cid' => $cid))->fetchField();
  if ($pid == 0) {
    $bool_in_trash = db_query("SELECT cid FROM {filedepot_trash} WHERE cid=:pid AND bool_in_trash = 0", array(':pid' => $pid))->fetchAssoc();
    if( $bool_in_trash ) {
      return TRUE;
    } else {
      return FALSE;
    }
  }
  else {
    filedepot_checkParentFolderPermanentDelete($pid);
  }
  $bool_in_trash = db_query("SELECT cid FROM {filedepot_trash} WHERE cid=:pid AND bool_in_trash = 0", array(':pid' => $pid))->fetchAssoc();
  if( $bool_in_trash ) {
    return TRUE;
  } else {
    return FALSE;
  }
}

// function filedepot_getchildrens($cid) {
//   $pid = db_query("SELECT pid FROM {filedepot_categories} WHERE cid=:cid", array(':cid' => $cid))->fetchField();
//   if ($pid == 0) {
//     return $cid;
//   }
//   else {
//     $cid = filedepot_getTopLevelParent($pid);
//   }
//   return $cid;
// }

function filedepot_formatfiletags($tags) {
	$retval = '';
	if (!empty($tags)) {
		$atags = explode(',', $tags);
		if (isset($_POST['tags'])) {
			$asearchtags = explode(',', stripslashes($_POST['tags']));
		}
		else {
			$asearchtags = array();
		}
		$count_search_tags = '';
		$count_tags = '';
		foreach ($atags as $key => $tag) {
		  $tag = trim($tag);
		  
		  if (!empty($tag)) {
		    if (in_array($tag, $asearchtags)) {
		      $count_search_tags++;
		    } else {
		      $count_tags++;
		    }
		  }
		}
		
		$filter_atags = array_filter($atags, function($value) { return $value != ' '; });
		$filter_asearchtags = array_filter( $asearchtags, function($value) { return $value != ' '; });
		$count_atags = count( $filter_atags );
		$count_asearchtags = count( $filter_asearchtags );
		$end_atags = end( $filter_atags );
		$end_asearchtags = end( $filter_asearchtags );
		
		
		$n_count = 0;
		//$retval .= '<p class="single-item" id="single-item">';
		
		foreach ($atags as $key => $tag) {
			$tag = trim($tag); // added to handle extra space thats added when removing a tag - thats between 2 other tags
			
			if($n_count == 2){
			   // $retval .= '</p>';
			   // $retval .= '<div class="all-items popover" id="all-itemskr">';
			}
			
			if (!empty($tag)) {
				if (in_array($tag, $asearchtags)) {
				  $count_search_tags--;
				  if( ( ( $count_search_tags != -1 ) && ( count( $atags ) != $key + 1 ) ) || ( ( $end_atags == $end_asearchtags ) && ( $count_atags != $count_asearchtags ) ) ) {
				    $tag .= ', ';
				  }
				  $retval .= theme('filedepot_taglinkoff', array('label' => check_plain($tag)));
				}
				else {
				  $count_tags--;
				  if( $count_tags != 0 ) {
				    $tag.= ', ';
				  }
				  $retval .= theme('filedepot_taglinkon', array('searchtag' => addslashes($tag), 'label' => check_plain($tag)));
				}
					
			}
			++$n_count;
		}
		
		if($n_count >= 2){
		    //$retval .= '</div>';
		}else{
		   // $retval .= '</p>';
		}			
	}
	
	if($retval != ''){
	   // $retval = '<div class="popover-wrapper">' . $retval .'</div>';
	}
	return $retval;
	
}



function filedepot_formatFileSize($size) {
	$size = intval($size);
	if ($size / 1000000 > 1) {
		$size = round($size / 1000000, 2) . " MB";
	}
	elseif ($size / 1000 > 1) {
		$size = round($size / 1000, 2) . " KB";
	}
	else {
		$size = round($size, 2) . " Bytes";
	}
	return $size;
}

function filedepot_getSubmissionCnt() {
	global $user;
	$filedepot = filedepot_filedepot();
	// Determine if this user has any submitted files that they can approve
	if( user_access( 'administer filedepot' ) ) {
		$query = db_query("SELECT cid from {filedepot_filesubmissions}");
		$submissions = 0;
		while ($A = $query->fetchAssoc()) {
			if ($filedepot->checkPermission($A['cid'], 'approval')) {
				$submissions++;
			}
		}
	} else {
		$query = db_select( 'filedepot_filesubmissions', 'ff' );
		$query->join( 'filedepot_moderate', 'fm', 'ff.cid = fm.cid' );
		$query->fields( 'ff', array( 'id', 'fid', 'approver' ) );
		$query->fields( 'fm', array( 'first_level_approver', 'second_level_approver' ) );
		$db_or = db_or();
		$db_or->condition( 'fm.first_level_approver', $user->uid );
		$db_or->condition( 'fm.second_level_approver', $user->uid );
		$query->condition( $db_or );	
 		$results = $query->execute()->fetchAll();
 		$submissions = 0;
 		foreach( $results as $result ) {
 		  if( isset( $result->first_level_approver ) && $result->first_level_approver != NULL ) {
 		    if( $result->approver == NULL ) {
 		      $submissions++;
 		    }
 		  } else if( isset( $result->second_level_approver ) && $result->second_level_approver != NULL) {
 		    if( $result->approver != NULL ) {
 		      $submissions++;
 		    }
 		  }
 		}
	}
	return $submissions;
}

/**
 *  count total number of submmited file by current user which is under review by appoval 
 */
function filedepot_getSubmissionCnt_for_submit(){
    global $user; 
    $count = db_select('filedepot_filesubmissions')
    ->condition('submitter', $user->uid)
    ->countQuery()
    ->execute()
    ->fetchField();
    return $count;
}
function filedepot_getUserOptions() {
	global $user;
	$retval = '';
// 	$query = db_query("SELECT u.uid, u.name,u.status FROM {users} u WHERE u.status = 1 AND u.uid != 1 AND u.uid != $user->uid ORDER BY name");
// 	while ($u = $query->fetchObject()) {
// 		$retval .= '<option value = "' . $u->uid . '">' . $u->name . '</option>';
// 	}
	$arr_retval = array();
	$users = entity_load('user');
	foreach( $users as $obj_user ) {
	  if( $obj_user->uid == 1 || $obj_user->uid == $user->uid || $obj_user->uid == 0 ) {
	    continue;
	  } else {
	    $first_name = '';
	    $mid_name = '';
	    $last_name = '';
	    if( isset( $obj_user->field_first_name['und'][0]['value'] ) ) {
	      $first_name = $obj_user->field_first_name['und'][0]['value'];
	    }
	    if( isset( $obj_user->field_middle_name['und'][0]['value'] ) ) {
	      $mid_name =  ' ' . $obj_user->field_middle_name['und'][0]['value'];
	    }
	    if( isset( $obj_user->field_last_name['und'][0]['value'] ) ) {
	      $last_name = ' ' . $obj_user->field_last_name['und'][0]['value'];
	    }
	    $arr_retval[$obj_user->uid] .= "$first_name$mid_name$last_name ( $obj_user->mail )";
	  }
	}
	asort( $arr_retval );
	foreach( $arr_retval as $key => $value ) {
	  $retval .= "<option value ='$key'>$value</option>";
	}

	return $retval;
}

/*
 function filedepot_select_getUserOptions( &$variables ) {
 global $user;
 $user_list[] = "--none--";
 $arr_user_list = db_query("SELECT u.uid, u.name,u.status FROM {users} u WHERE u.status = 1 AND u.uid != 1 AND u.uid != $user->uid ORDER BY name")->fetchAllKeyed( 0, 1);
 
 foreach( $arr_user_list as $uid => $name ) {
 $user_list[$uid] = $name;
 }
 
 $cid = $variables['cid'];
 $results = db_select( 'filedepot_moderate', 'fm' )
 ->fields( 'fm' )
 ->condition( 'cid', $cid )
 ->execute()
 ->fetchAssoc();
 
 $first_level_a = '';
 $second_level_a = '';
 if( $results ) {
 if( isset( $results['first_level_approver'] ) ) {
 $first_level_a = $results['first_level_approver'];
 }
 if( isset( $results['second_level_approver'] ) ) {
 $second_level_a = $results['second_level_approver'];
 }
 }
 
 $variables['first_level_approver'] = array(
 '#name' => 'first_level_approver',
 '#type' => 'select',
 '#title' => t('First level approver'),
 '#value' => $first_level_a,
 '#options' => $user_list,
 );
 $variables['second_level_approver'] = array(
 '#name' => 'second_level_approver',
 '#type' => 'select',
 '#title' => t('Second level approver'),
 '#value' => $second_level_a,
 '#options' => $user_list,
 
 );
 }
 */
function filedepot_getRoleOptions() {
	$retval = '';
	$query = db_query("SELECT r.rid, r.name FROM {role} r ");
	while ($r = $query->fetchObject()) {
		$retval .= '<option value = "' . $r->rid . '">' . $r->name . '</option>';
	}
	return $retval;
}

function filedepot_getGroupOptions() {
	global $user;
	$retval = '';
	$groups = filedepot_og_get_user_groups();
	foreach ($groups as $grpid) {
		$entity = filedepot_og_get_group_entity($grpid);
		$retval .= '<option value="' . $grpid . '">' . $entity->title . '</option>';
	}
	return $retval;
}

function update_first_second_level_approver( $cid ) {
	$first_level_approver = NULL;
	$second_level_approver = NULL;
	
	if( $cid > 0 ) {
	  $users = $_POST['selusers'];
    	if( $_POST['selusers'] != '' AND !is_array( $_POST['selusers'] ) ) {
    	  $users = array( $_POST['selusers'] );
    	}
    	if( !empty( $users) ) {
    	  foreach( $users as $uid ) {
            
      	    if( isset( $_POST['approver'] ) AND ( $_POST['approver'] == 'first_level_approver' ) ) {
      	       $first_level_approver = $uid;
          	}
          	if( isset( $_POST['approver'] ) AND ( $_POST['approver'] == 'second_level_approver' ) ) {
          	   $second_level_approver = $uid;
          	}
          	$query = db_select( 'filedepot_moderate', 'fm' )->fields( 'fm',array( 'cid','first_level_approver','second_level_approver' ) );
          	$query->condition( 'cid', $cid );
          	$db_or = db_or();
          	$db_or->condition('first_level_approver', $uid, '=');
          	$db_or->condition('second_level_approver', $uid , '=');
          	$query->condition( $db_or );
          	$result = $query->execute()->fetchAll();
          	
          	if( $result ) {
          	  $query = db_update('filedepot_moderate')
            	  ->fields(array(
            	      'first_level_approver' => $first_level_approver,
            	      'second_level_approver' => $second_level_approver,
            	  ));
            	  $query->condition('cid', $cid );
            	  $db_or = db_or();
            	  $db_or->condition('first_level_approver', $uid, '=');
            	  $db_or->condition('second_level_approver', $uid , '=');
            	  $query->condition($db_or);
            	  $query->execute();
          	} else {
          	  db_insert('filedepot_moderate')
            	  ->fields(array(
            	      'cid' => $cid,
            	      'first_level_approver' => $first_level_approver,
            	      'second_level_approver' => $second_level_approver,
            	  ))
            	  ->execute();
          	}
    	  }
    	}
	}
}

function filedepot_og_get_user_groups() {
	global $user;
	
	$retval = array();
	$groups = og_get_entity_groups('user', $user);
	if (is_array($groups) AND count($groups) > 0) {
		if (function_exists('og_get_group')) {
			$retval = $groups;
		} else {
			$retval = $groups['node'];
		}
	}
	
	return $retval;
}


function filedepot_og_get_group_entity($grpid) {
	if (function_exists('og_get_group')) {
		$entity = og_get_group('group', $grpid);
		$entity->title = $entity->label;
	} else {
		$entity = node_load($grpid);
	}
	
	return $entity;
}

function filedepot_get_group_entity_query($grpid=0) {
	$query = new EntityFieldQuery();
	if ($grpid > 0) {
		if (function_exists('og_get_group')) {
			$efq = $query->entityCondition('entity_type', 'group', '=')
			->entityCondition('bundle', 'group')
			->entityCondition('entity_id', $grpid);
		} else {
			$efq = $query->entityCondition('entity_type', 'node')
			->entityCondition('entity_id', $grpid)
			->fieldCondition(OG_GROUP_FIELD, 'value', 1, '=');
		}
	} else {
		if (function_exists('og_get_group')) {
			$efq = $query->entityCondition('entity_type', 'group', '=')
			->entityCondition('bundle', 'group');
		} else {
			$efq = $query->entityCondition('entity_type', 'node')
			->fieldCondition(OG_GROUP_FIELD, 'value', 1, '=');
		}
	}
	
	return $efq->execute();
	
}


/**
 * Send out notifications to all users that have subscribed to this file or file category
 * Will check user preferences for notification if Messenger Plugin is installed
 * @param        string      $id        Key used to retrieve details depending on message type
 * @param        string      $type      Message type ->
 *                                       (1) FILEDEPOT_NOTIFY_NEWFILE,
 *                                       (2) FILEDEPOT_NOTIFY_APPROVED,
 *                                       (3) FILEDEPOT_NOTIFY_REJECT,
 *                                       (4) FILEDEPOT_NOTIFY_ADMIN
 * @return       Boolean     Returns TRUE if atleast 1 message was sent out
 */
function filedepot_sendNotification($id, $type = 1,$reason='owner') {
	global $user,$base_url;
	
	/* If notifications have been disabled via the module admin settings - return TRUE */
	if (variable_get('filedepot_notifications_enabled', 1) == 0) {
        return TRUE;
	}
	
	if (intval($id) > 0) {
		$target_users = filedepot_build_notification_distribution($id, $type);

		
		/**
		 *  modify admin notify when a new file submit in modrate section 
		 *  custommized  for  end each user persional message
		 */
		if ($type == FILEDEPOT_NOTIFY_ADMIN) {  // only for sumit new sile for appoval
		    $get_aaprvale = filedepot_build_get_approval($id, $type);
		    $target_users =  $get_aaprvale ;
		    
		    // $values = array('fid' => $id, 'target_users' => array(),'reason' => $reason );
		    // drupal_mail('filedepot', $type, $user, language_default(), $values);
		    /**
		     * send each user(approval) with a personal message
		     */
		     foreach($target_users as $singleuser_id){
		        $userobj = user_load($singleuser_id);
		        $values = array('fid' => $id, 'target_users' => array(),'reason' => $reason, 'receiver_id' => $singleuser_id );
		        
		        
		        
		            $editor_email_id = user_email_id($singleuser_id );
		           //  $user_name = user_first_last_name( $editor['target_id'] );
		            
		            // $params['subject'] = "Blog $str_title has been created.";
		        
		            $sql = "SELECT file.fname,file.cid,file.submitter,category.name FROM {filedepot_filesubmissions} file , "
		                    . "{filedepot_categories} category WHERE file.cid=category.cid and file.id=:fid";
		            $query = db_query($sql, array(':fid' => $id));
		            list($fname, $cid, $submitter, $catname) = array_values($query->fetchAssoc());
		            $submitter_name = db_query("SELECT name FROM {users} WHERE uid=:uid", array(':uid' => $submitter))->fetchField();
		            
		            $getuser_name = get_user_first_last_name_for_notification($submitter);
		            
		            $receiver_name = get_user_first_last_name_for_notification($singleuser_id);
		            
		            $message_args = array(
		                    '@@name' => $submitter_name,
		                    '!file' => $fname,
		                    '!folder' => $catname,
		            );
		            
		            $params['subject'] = variable_get('site_name', '') . ' - ' . t('New document moderation request');
		            
		            //$message['subject'] = variable_get('site_name', '') . ' - ' . t('New File Submission requires Approval');
		            
		            $message_body = "<span style='font-size:10px'>Hi $receiver_name,</span> <br/>";
		            $message_body .= "<span style='font-size:10px'> A new file $fname has been submitted by $getuser_name in organizational drive folder $catname </span> <br/> ";
		            $message_body .= "<span style='font-size:10px'>  You can review the file at <a href='".$base_url."/knowledge-repository'>Knowledge Repository</a>  Under my Review</span> <br/>";
		            $message_body .= "<span style='font-size:10px'>  <a href='".$base_url."/knowledge-repository'>Click here </a> to visit Knowledge Repository </span> <br/> <br/> ";
		            
		            //  $message_body = t('Site member @@name has submitted a new file (!file) for folder !folder that requires approval', $message_args);
		            // $message_body .= "\n\n" . t('Thank You') . "\n";
		            
		            // $message['body'][] = $message_body;
		            $params['body'] = $message_body;
		            drupal_mail('custom_blog_post', 'blog_created_2', $editor_email_id, language_default(), $params );
		       
		        
		        // drupal_mail('filedepot', $type, $userobj, language_default(), $values);
		          
		    }
		    
		}
		else{
    		if (count($target_users) > 0) {
    			$values = array('fid' => $id, 'target_users' => $target_users,'reason' => $reason );
    			drupal_mail('filedepot', $type, $user, language_default(), $values);
    		} else {
    			watchdog('filedepot', "filedepot_sendNotification (@type) - no target users", array("@type" => $type));
    		}
	   }
	}
}

/**
 * notify all user when administrater approvad a file in organizational folder
 * 
 * @param file id $id
 * @param number $type type of notification 
 */
function km_kr_sendnotification_for_file_approval($id, $type = 1)
{
    global $user;
    $headernotification = array();
    $sql = "SELECT file.fid,file.fname,file.cid,file.submitter,category.name,category.nid FROM {filedepot_files} file, "
            . "{filedepot_categories} category WHERE file.cid=category.cid and file.fid=:fid";
    $query = db_query($sql, array(':fid' => $id));
    list($fid, $fname, $cid, $submitter, $catname,$nid) = array_values($query->fetchAssoc());
    
    $target_users = filedepot_build_notification_distribution($id, FILEDEPOT_NOTIFY_NEWFILE);
    // send all subscribe user notification about new file approved
    foreach ($target_users as $subscribe_uid) {
        $headernotification[] = array(
                'sender_id' => $user->uid,
                'receiver_id' => $subscribe_uid,
                'module_type' => 'km_repository',
                'nt_type'   => 'KR_GLOBAL_FILE_UPLOAD_NOTIFICATION',
                'entity_type' => 'node',
                'entity_id' => $nid,
                'created'  => REQUEST_TIME,
                'nt_info' => 'info',
                'other_val' => json_encode(array('file_id' => $fid )),
        );
    }
    
    if(!empty($headernotification)) {
        save_user_notification($headernotification);
    }
     
}
/**
 * get approvale lst
 * @param unknown $id
 * @param unknown $type
 * @return multitype:NULL
 */
function filedepot_build_get_approval($id, $type){
    $target_users = array();
    
    if ($type == FILEDEPOT_NOTIFY_ADMIN) {
        $sql = "SELECT file.cid,file.submitter FROM {filedepot_filesubmissions} file , "
                . "{filedepot_categories} category WHERE file.cid=category.cid and file.id=:fid";
        $query = db_query($sql, array(':fid' => $id));
        
        list($cid, $submitter) = array_values($query->fetchAssoc());
        
        // find_target_user 
        $query_a = db_query("SELECT permid FROM {filedepot_access} WHERE catid=:cid AND permtype=:permtype AND approval=:approval AND admin=:admin  ORDER BY permid DESC", array(
                ':cid' => $cid,
                ':permtype' => 'user',
                ':approval' => 1,
                ':admin' => 1,
        
        ));
        $alluser =  $query_a->fetchAll();
        foreach($alluser as $user_row) {
            
            $target_users[] = $user_row->permid;
        }
        
    }
    return $target_users;
}



/* Common function to generate an array of users that email notification
 * will be sent to. Return an empty array if none
 */
function filedepot_build_notification_distribution($id, $type = 1) {
	global $user;
	
	$filedepot = filedepot_filedepot();
	
	$target_users = array();
	if ($type == FILEDEPOT_NOTIFY_NEWFILE OR $type == FILEDEPOT_NOTIFY_APPROVED OR $type == FILEDEPOT_BROADCAST_MESSAGE) {
		$sql = "SELECT file.cid,file.submitter,category.name FROM {filedepot_files} file, "
				. "{filedepot_categories} category WHERE file.cid=category.cid and file.fid=:fid";
				$query = db_query($sql, array(':fid' => $id));
				list($cid, $submitter) = array_values($query->fetchAssoc());
						
	}
	elseif ($type == FILEDEPOT_NOTIFY_ADMIN) {
		$sql = "SELECT file.cid,file.submitter FROM {filedepot_filesubmissions} file , "
				. "{filedepot_categories} category WHERE file.cid=category.cid and file.id=:fid";
				$query = db_query($sql, array(':fid' => $id));
				list($cid, $submitter) = array_values($query->fetchAssoc());
	}
	elseif ($type == FILEDEPOT_NOTIFY_REJECT) {
		$submitter = db_query("SELECT submitter FROM {filedepot_filesubmissions} WHERE id=:fid", array(':fid' => $id))->fetchField();
	}
	
	// Generate the distribution
	if ($type == FILEDEPOT_NOTIFY_NEWFILE ) {
		if (variable_get('filedepot_default_notify_newfile', 0) == 1) { // Site default to notify all users on new files
			$query_users = db_query("SELECT uid FROM {users} WHERE uid > 0 AND status = 1");
			while ( $A = $query_users->fetchObject()) {
			    if ($filedepot->checkPermission($cid, 'view', $A->uid)) {
			        $personal_exception = FALSE;
					if (db_query("SELECT uid FROM {filedepot_usersettings} WHERE uid=:uid AND notify_newfile=0", array(':uid' => $A->uid))->fetchField() == $A->uid) {
						$personal_setting = FALSE; // User preference record exists and set to not be notified
					}
					else {
						$personal_setting = TRUE; // Either record does not exist or user preference is to be notified
					}
					// Check if user has any notification exceptions set for this folder
					if (db_query("SELECT count(*) FROM {filedepot_notifications} WHERE cid=:cid AND uid=:uid AND cid_newfiles=0", array(':cid' => $cid, ':uid' => $A->uid))->fetchField() > 0) {
						$personal_exception = TRUE;
					}
					// Only want to notify users that don't have setting disabled or exception record
					if ($personal_setting == TRUE AND $personal_exception == FALSE AND $A->uid != $submitter) {
						$target_users[] = $A->uid;
					}
				}
			}
		}
		else {
			$sql = "SELECT a.uid FROM {filedepot_usersettings} a LEFT JOIN {users} b on b.uid=a.uid WHERE a.notify_newfile = 1 and b.status=1";
			$query_users = db_query($sql);
			while ( $A = $query_users->fetchObject()) {
				if ($filedepot->checkPermission($cid, 'view', $A->uid)) {
					$personal_exception = FALSE;
					if (db_query("SELECT ignore_filechanges FROM {filedepot_notifications} WHERE fid=:fid and uid=:uid", array(':fid' => $id, ':uid' => $A->uid))->fetchField() == 1) {
						$personal_exception = TRUE;
					}
					// Only want to notify users that have notifications enabled but don't have an exception record
					if ($personal_exception === FALSE) {
						$target_users[] = $A->uid;
					}
				}
			}
			// Check the folder specific notification options as well
			$sql = "SELECT a.uid FROM {filedepot_notifications} a LEFT JOIN {users} b on b.uid=a.uid WHERE a.cid=:cid AND a.cid_newfiles = 1 and b.status=1";
			$query_users = db_query($sql, array(':cid' => $cid));
			while ( $A = $query_users->fetchObject()) {
				if (!in_array($A->uid, $target_users) AND $filedepot->checkPermission($cid, 'view', $A->uid)) {
					$target_users[] = $A->uid;
				}
			}
			
		}
	}
	elseif ($type == FILEDEPOT_NOTIFY_APPROVED) { // File submission being approved by admin where $id = file id. Send only to user
		$target_users[] = $submitter;
	}
	elseif ($type == FILEDEPOT_NOTIFY_REJECT) { // File submission being approved by admin where $id = file id. Send only to user
		$target_users[] = $submitter;
	}
	elseif ($type == FILEDEPOT_NOTIFY_ADMIN) {
		$query_users = db_query("SELECT uid FROM {users} WHERE uid > 0 AND status = 1");
		while ( $A = $query_users->fetchObject()) {
		    if ($filedepot->checkPermission($cid, 'approval', $A->uid)) {
		        $personal_exception = FALSE;
				if (db_query("SELECT uid FROM {filedepot_usersettings} WHERE uid=:uid AND notify_newfile=0", array(':uid' => $A->uid))->fetchField() == $A->uid) {
					$personal_setting = FALSE; // User preference record exists and set to not be notified
				}
				else {
					$personal_setting = TRUE; // Either record does not exist or user preference is to be notified
				}
				// Check if user has any notification exceptions set for this folder
				if (db_query("SELECT count(*) FROM {filedepot_notifications} WHERE cid=:cid AND uid=:uid AND cid_newfiles=0", array(':cid' => $cid, ':uid' => $A->uid))->fetchField() > 0) {
					$personal_exception = TRUE;
				}
				
				// Only want to notify users that don't have setting disabled or exception record
				if ($personal_setting == TRUE AND $personal_exception == FALSE AND $A->uid != $submitter) {
					$target_users[] = $A->uid;
				}
			}
		}
	}
	elseif ($type == FILEDEPOT_BROADCAST_MESSAGE) {
		// Nov 2014: Added check that user also has view access to the folder from where broadcast was issued from
		if (variable_get('filedepot_default_allow_broadcasts', 1) == 1) { // Site default set to allow broadcast enabled
			$uquery = db_query("SELECT uid FROM {users} WHERE uid > 0 AND status = 1");
			while ( $A = $uquery->fetchObject()) {
				if ($A->uid != $user->uid && $filedepot->checkPermission($cid, 'view', $A->uid)) {
					if (db_query("SELECT allow_broadcasts FROM {filedepot_usersettings} WHERE uid=:uid",
							array(':uid' => $A->uid))->fetchField() == 0) {
								$personal_setting = FALSE; // Found user setting to not be notified
							}
							else {
								$personal_setting = TRUE;
							}
							// Only want to notify users that don't have setting disabled or exception record and folder view access
							if ($personal_setting == TRUE AND $filedepot->checkPermission($cid, 'view', $A->uid)) {
								$target_users[] = $A->uid;
							}
				}
			}
		}
		else {
			$sql = "SELECT a.uid FROM {filedepot_usersettings} a LEFT JOIN {users} b on b.uid=a.uid "
					. "WHERE a.allow_broadcasts=1 and b.status=1";
					$uquery = db_query($sql);
					while ($B  = $uquery->fetchObject()) {
						if ($user->uid != $B->uid && $filedepot->checkPermission($cid, 'view', $B->uid)) {
							$target_users[] = $B->uid;
						}
					}
		}
	}
	
	if (count($target_users) > 0) {
		// Sort the array so that we can check for duplicate user notification records
		sort($target_users);
		reset($target_users);
	}
	
	return $target_users;
	
}



function filedepot_delTree($dir) {
	$files = glob( $dir . '*', GLOB_MARK );
	foreach ( $files as $file ) {
		if ( drupal_substr( $file, -1 ) == '/' ) {
			filedepot_delTree( $file );
		}
		else {
			@unlink( $file );
		}
	}
	if (is_dir($dir)) {
		@rmdir( $dir );
	}
}

function filedepot_dropzone_file_uri_to_object($uri) {
    global $user;
    $uri = file_stream_wrapper_uri_normalize($uri);
    $wrapper = file_stream_wrapper_get_instance_by_uri($uri);
    $file = new StdClass();
    $file->uid = $user->uid;
    $file->filename = drupal_basename($uri);
    $file->uri = $uri;
    $file->filemime = file_get_mimetype($uri);
    // This is gagged because some uris will not support it.
    $file->filesize = @filesize($uri);
    $file->timestamp = REQUEST_TIME;
    $file->status = FILE_STATUS_PERMANENT;
    return $file;
}

