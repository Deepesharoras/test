var file_tags = jQuery( '#editfile_tags' ).val();
var version_tags = jQuery( 'input[id^=edit-filedepot-version-filetags]' ).val();
(function ($) {
        Drupal.behaviors.filedepot_tags = {
          attach: function (context, settings) {
                /*var tags = $( 'input[id^=edit-filedepot-filetags]' ).val();
                $( ".dropdown > .dropdown-menu > li" ).click(function(){
                      tags = $('input[id^=edit-filedepot-filetags]').val();
                });
                  $( 'input[id^=edit-filedepot-filetags]' ).on('autocompleteSelect', function(event, node) {
                        if( '' != tags ) {
                              tags = tags + ', ' + $(this).val();
                        } else {
                              tags = $(this).val();
                        }
                        $('input[id^=edit-filedepot-filetags]').val( tags );
                  });
                  
                var multiple_tags = $( 'input[id^=edit-filedepot-tags-multiupload]' ).val();
                $( ".dropdown > .dropdown-menu > li" ).click(function(){
                      multiple_tags = $('input[id^=edit-filedepot-tags-multiupload]').val();
                });
                  $( 'input[id^=edit-filedepot-tags-multiupload]' ).on('autocompleteSelect', function(event, node) {
                        if( '' != multiple_tags ) {
                              multiple_tags = multiple_tags + ', ' + $(this).val();
                        } else {
                              multiple_tags = $(this).val();
                        }
                        $('input[id^=edit-filedepot-tags-multiupload]').val( multiple_tags );
                  });
                  

                $( ".dropdown > .dropdown-menu > li" ).click(function(){
                      file_tags = $('#editfile_tags').val();
                });
                  $( '#editfile_tags' ).on('autocompleteSelect', function(event, node) {
                        if( '' != file_tags ) {
                              file_tags = file_tags + ', ' + $(this).val();
                        } else {
                              file_tags = $(this).val();
                        }
                        $('#editfile_tags').val( file_tags );
                  });*/
                  
                  
                  /*$('input[id^=edit-filedepot-version-filetags]').on('autocompleteSelect', function(event, node) {
                        
                         console.log(mytag);
                        
                        var all_tag = $('#edit-filedepot-version-filetags').val();
                         var terms = split(all_tag);  
                         console.log(terms);
                         // remove the current input
                     terms.pop();
                      // add the selected item
                      terms.push( $(this).val() );
                      // add placeholder to get the comma-and-space at the end
                      terms.push( "" );
                      this.value = terms.join( ", " );
                      console.log(this.value);
                      return false;

                  });*/
          }
        };
}(jQuery));


function split(val){
    return val.split(/,\s*/ );
}
function extractLast(term){
    return split( term ).pop();
}



function tag_value_update() {
      file_tags = jQuery( '#editfile_tags' ).val();
}

function tag_value_update_version() {
      version_tags = jQuery( 'input[id^=edit-filedepot-version-filetags]' ).val();
}

function filedepot_reset_tags() {
      file_tags = '';
      version_tags = '';
}

function new_version_from_submit() {

   if( jQuery( "input[type='file'][id='edit-filedepot-file-upload']" ).val() === "" ) {
        jQuery('#edit-filedepot-file-upload').addClass('error');
        jQuery('#add-verson-alert').addClass('alert alert-block alert-danger').html(' <a class="close" data-dismiss="alert" href="#">×</a> Choose a file field is required.')
        return false;
    } else if( jQuery( "#edit-filedepot-version-filetags" ).val() == "" ){
          jQuery('#edit-filedepot-version-filetags').addClass('error');
          jQuery('#add-verson-alert').addClass('alert alert-block alert-danger').html(' <a class="close" data-dismiss="alert" href="#">×</a> Tags field is required.')
          return false;
    } else {
          return true;
    }
}


function en_dis_chk_box() {
//      if( jQuery( 'input[id^=chkfile]' ).length == 0 ) {
//            jQuery( '#headerchkall').hide();
//            jQuery( '#multiaction' ).hide();
//            jQuery( '.back-button' ).css( 'right', '5px' );
//      } else {
//            jQuery( '#headerchkall').show();
//            jQuery( '#multiaction' ).show();
//            jQuery( '.back-button' ).css( 'right', '229px' );
//      }
      
	  var is_show_ck = true;
      if( jQuery( 'input[id^=filedepot-chk]' ).length != 0 || jQuery( 'input[id^=chkfile]' ).length != 0 ) {
           
    	 jQuery( 'input[id^=filedepot-chk]' ).each(function(){
    		   var dataLayer = jQuery(this).data('display');
    		   if(dataLayer == 'none')
    			{
    			   is_show_ck = false;
    			}
    	      
    	    });
    	    console.log(is_show_ck);
    	    if(is_show_ck == true){
	    	    jQuery( '#headerchkall').show();
	            jQuery( '#multiaction' ).show();
	            jQuery( '.back-button' ).css( 'right', '229px' );
            }else{
            	jQuery( '#headerchkall').hide();
                jQuery( '#multiaction' ).hide();
                jQuery( '.back-button' ).css( 'right', '15px' );
            }
      } else {
            jQuery( '#headerchkall').hide();
            jQuery( '#multiaction' ).hide();
            jQuery( '.back-button' ).css( 'right', '15px' );
      }
}
