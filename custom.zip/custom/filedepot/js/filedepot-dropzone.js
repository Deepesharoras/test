jQuery(function () {
	Dropzone.autoDiscover = false;
	var myDropzone = jQuery("#dropzoneform-filedepot").dropzone({
		url: Drupal.settings.basePath + "knowledge-repository-dropzone/",
	    parallelUploads: 1,
	    paramName: 'file',
	    previewsContainer: null,
	    clickable: true,
	    enqueueForUpload: false,
	    maxFilesize: 10,
	    acceptedFiles: '.jpeg,.jpg,.png,.doc,.docx,.xls,.xlsx,.pdf,.ppt,.pptx,.txt,.gif',
	    dictInvalidFileType: "The Uploaded file does not match the allowed extensions",
	    dictDefaultMessage: "Drop files here to upload (or click here)",
	    accept: function(file, done)
	    {
	    	done();
	    },
	    init: function() {
	        this.on("processing", function(file) {
	        	var cid = jQuery("input[name=current_folder_id]").val();
	        	if( typeof cid == 'undefined' ) {
	        		cid = display_folder_id;
	        	}
	        	this.options.url = Drupal.settings.basePath + "knowledge-repository-dropzone/" + cid;
	        	processing = true;
	        });
		    this.on("complete", function (file) {
	        	var cid = jQuery("input[name=current_folder_id]").val();
	        	if( typeof cid == 'undefined' ) {
	        		jQuery('.dropzone .dz-preview').hide();
	        	} else {
	        		console.log(file);
			    	/*setTimeout(
					function() 
					{
						window.location.replace(Drupal.settings.basePath + "knowledge-repository/folder/" + cid );
					}, 5000);*/
	        	}
		    });
		    this.on("error", function(file, message) { 
		    	bootbox.alert(file.name + ' , ' +message);
                this.removeFile(file);
                processing = false;
		    });
		    
		    this.on("maxfilesexceeded", function(file, message) { 
		    	bootbox.alert(message);
		    	// alert(message);
                this.removeFile(file); 
		    });
		    
		    this.on("queuecomplete", function(file, message) { 
		    	
		    	console.log(file);
		    	
		    	var cid = jQuery("input[name=current_folder_id]").val();
		    	if( typeof cid == 'undefined' ) {
	        		cid = display_folder_id;
	        	}
		    	console.log('aafile are uploade');
		    	document.frmtoolbar.reportmode.value = '';
		    	this.removeAllFiles();
		    	// init_filedepot();
		    	// success message
		    	// showAlert("File(s) has been uploaded successfully.");
		    	 if(true == processing)
		    	 {
		    		 jQuery('.filedepot-alerts').prepend( '<div class="alert alert-block alert-success messages status"><a class="close" data-dismiss="alert" href="#">×</a><h4 class="element-invisible">Status message</h4>File(s) has been uploaded successfully.</div>' );
		    		 YAHOO.filedepot.showfiles(cid);
		    	 }
		    	// window.location.replace( Drupal.settings.basePath + "knowledge-repository/folder/" + cid );
		    });
		      
		}
	});
});


function dropzone_en_dis() {
	var cid = jQuery("input[name=current_folder_id]").val();
	console.log(folder_upload_prms);
	if( typeof cid != 'undefined' || folder_upload_prms == true) {
		jQuery("#dropzoneform-filedepot").addClass("dropzone");
		jQuery('.dz-default').show();
	} else {
		jQuery("#dropzoneform-filedepot").removeClass("dropzone");
		jQuery('.dz-default').hide();
	}
	
	/*if( typeof cid == 'undefined' ) {
		jQuery("#dropzoneform-filedepot").removeClass("dropzone");
		jQuery('.dz-default').hide();
	} else {
		jQuery("#dropzoneform-filedepot").addClass("dropzone");
		jQuery('.dz-default').show();
	}*/
}

// function dropzone_mesg() {
// 	var dem = jQuery("input[name=current_folder_id]").val();
	
// 	if( typeof dem == 'undefined' ) {
// 		jQuery('.dropzone-message').hide();
// 	} else {
// 		jQuery('.dropzone-message').show();
// 	}
// }

//jQuery(document).ready(function(){
//   //dropzone_mesg();
//
//});


