/**
 * Callbacks for plupload.
 */

(function($) { 
  Drupal.filedepot_multiupload = Drupal.filedepot_multiupload || {};
  Drupal.filedepot_multiupload.stateChangedCallback = function(up, files) {
    if (up.state === 2) {
      var folder = jQuery("#edit-filedepot-folder").val();
      if (folder <= 0) {
        up.stop();
        $("#edit-filedepot-folder").parent().addClass("has-error");
         alert(Drupal.t("You must select a valid folder"));
      } else{
        $("#edit-filedepot-folder").parent().removeClass("has-error");
      }
      var tags = $("#edit-filedepot-tags-multiupload").val();
      if( tags == "" ) {
        up.stop();
        $("input[id^='edit-filedepot-tags-multiupload']").parent().addClass("has-error");
        $('#multiupload-alert').addClass('alert alert-block alert-danger messages error').html("Tags field is required."); 
      } else {
    	  var arr_tags = tags.split(',');
          var bool_limit = false;
          for( i = 0; i < arr_tags.length; i++ ) {
        	if( arr_tags[i].length < 3 || arr_tags[i].length > 50 ) {
        		bool_limit = true;
        	}
          }
          if( bool_limit ) {
        	up.stop();
            $("input[id^='edit-filedepot-tags-multiupload']").parent().addClass("has-error");
            $('#multiupload-alert').addClass('alert alert-block alert-danger messages error').html("Tags should be between 3-50 characters.");
          } else {
        	$("input[id^='edit-filedepot-tags-multiupload']").parent().removeClass("has-error");
          }
      }
    }
  };
})(jQuery);
