<?php
    global $base_url;
    /**
     * Theme file for the main page.
     *
     * This template overrides the default from filedepot.
     */
    
    // Initialize variable id unknown to solve any PHP Notice level error messages.
    if (!isset($search_query)):
      $search_query = 0;
    endif;
    ?>
<!-- On-Demand loading the Module Javascript using YUI Loader -->
<script type="text/javascript">
    var useYuiLoader = true;         // Set to false if you have manually loaded all the needed YUI libraries else they will dynamically be loaded
    var pagewidth = 0;               // Integer value: Use 0 for 100% width with auto-resizing of layout, or a fixed width in pixels
                                     // Height of main display is set by the height of #filedepot div - default set in CSS
    var numGetFileThreads = 5;       // Max number of concurrent AJAX threads to spawn in the background to retrieve & render record details for subfolders
    var useModalDialogs = true;      // Default of true is preferred but there is an IE7 bug that makes them un-useable so in this case set to false
    
    // Do not modify any variables below
    var filedepotfolders = '';
    var filedepotdetail = '';
    var folderstack = new Array;  // will contain list of folders being processed by AJAX YAHOO.filedepot.getmorefiledata function
    var fileID;
    var initialfid = <?php print $initialfid ?>;
    var initialcid = <?php print $initialcid ?>;
    var initialop = '<?php print $initialop ?>';
    var initialparm = '<?php print $initialparm ?>';
    var siteurl = '<?php print $site_url ?>';
    var ajax_post_handler_url = '<?php print $ajax_server_url ?>';
    var actionurl_dir = '<?php print $actionurl_dir ?>';
    var imgset = '<?php print $layout_url ?>/css/images';
    var ajaxactive = false;
    var clear_ajaxactivity = false;
    var blockui = false;
    var timerArray = new Array();
    var lastfiledata = new Array();
    var expandedfolders = new Array();
    var searchprompt = '<?php print t(''); ?>';
    var show_upload = <?php print $show_upload ?>;
    var show_newfolder = <?php print $show_newfolder ?>;
</script>
<script type="text/javascript">
    var YUIBaseURL  = "<?php print $yui_base_url ?>";
</script>
<script>
    jQuery(window).on("drop", function(e) {
      e.preventDefault();
    });
    jQuery(window).on("dragover", function(e) {
      e.preventDefault();
    });
</script>
<script type="text/javascript">
    jQuery.blockUI();
    if (useYuiLoader == true) {
     // Instantiate and configure Loader:
     var loader = new YAHOO.util.YUILoader({
    
       base: YUIBaseURL,
       // Identify the components you want to load.  Loader will automatically identify
       // any additional dependencies required for the specified components.
       require: ["container","layout","resize","connection","dragdrop","menu","button","tabview","autocomplete","treeview","element","cookie","logger","animation","yahoo-dom-event","datasource"],
    
       // Configure loader to pull in optional dependencies.  For example, animation
       // is an optional dependency for slider.
       loadOptional: true,
    
       // The function to call when all script/css resources have been loaded
       onSuccess: function() {
         blockui=true;
         //jQuery.blockUI();
         timeDiff.setStartTime();
         Dom = YAHOO.util.Dom;
         Event = YAHOO.util.Event;
         Event.onDOMReady(function() {
           setTimeout('init_filedepot()',1000);
         });
       },
       onFailure: function(o) {
         alert("The required javascript libraries could not be loaded.  Please refresh your page and try again.");
       },
    
       allowRollup: true,
    
       // Configure the Get utility to timeout after 10 seconds for any given node insert
       timeout: 10000,
    
       // Combine YUI files into a single request (per file type) by using the Yahoo! CDN combo service.
       combine: false
     });
    
     // Load the files using the insert() method. The insert method takes an optional
     // configuration object, and in this case we have configured everything in
     // the constructor, so we don't need to pass anything to insert().
     loader.insert();
    
    } else {
     blockui=true;
     jQuery.blockUI();
     timeDiff.setStartTime();
     Dom = YAHOO.util.Dom;
     Event = YAHOO.util.Event;
     Event.onDOMReady(function() {
       setTimeout('init_filedepot()',1000);
     });
    }
    
</script>
<!-- filedepot module wrapper div -->
<div id="filedepotmodule" class="filedepot-wrap">
<div id="filedepot">
    <div class="row">
        <div id="filedepottoolbar" class="filedepottoolbar header-strip clearfix">
            <div class="pull-left">
                <h4><i class="fa fa-book"></i> Knowledge Repository</h4>
            </div>
            <!-- <?php if( 'list' == $list_grid_view_opt ):?>
                <a href="#" onclick="makeAJAXgrid_list_views('grid');return false;";"><i class="fa fa-th"></i></a>
                <?php else:?> 
                <a href="#" onclick="makeAJAXgrid_list_views('list');return false;";"><i class="fa fa-list"></i></a>
                <?php endif; ?> -->
            <div class="pull-right">
                <!-- <div class="tagsearchboxcontainer"></div> -->
                <div class="filedepottoolbar_searchbox clearfix">
                    <div class="filedepottoolbar_searchform text-right">
                        <form name="fsearch" onSubmit="makeAJAXSearch();return false;">
                            <input type="hidden" name="tags" value="">
                            <input type="text" name="query" id="searchquery" class="form-control" value="<?php // print $search_query ?>" placeholder="Enter Keyword">
                            <input type="button" id="searchbutton" value="<?php print t('Search') ?>">
                        </form>
                        <!-- <a id="showsearchtags" class="btn btn-primary" href="#"><?php echo t('Tags'); ?></a> -->
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
    <!--  <div class="tagsearchboxcontainer">
        <div id="tagspanel" style="display:none;">
            <div class="hd"><?php // print t('Search Tags'); ?></div>
            <div id="tagcloud" class="bd tagcloud">
                <?php // print $tagcloud ?>
            </div>
        </div>
    </div> -->
     
     
     <?php 
            /* $block = module_invoke('block', 'block_view', 37);
            print render($block['content']);  */
            
            $block = block_load('block', '37');
            $output =_block_get_renderable_array(_block_render_blocks(array($block)));
            $output = drupal_render($output);
            print $output;
         ?>

    <div id="filedepot_sidecol">
        <div class="dropdown pull-left">
            <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="true">New <span class="caret"></span></button>
            <ul class="dropdown-menu">
                <li>
                    <?php if ($show_newfolder == 'true'): ?>
                    <span id="newfolderlink">
                    <span class="first-child">
                    <a class="ctools-use-modal ctools-modal-filedepot-newfolder-dialog-style" href="<?php print url('knowledge-repository/nojs/newfolder'); ?>"><i class="fa fa-folder-o" aria-hidden="true"></i><?php echo t('Folder'); ?></a>
                    </span>
                    </span>
                    <?php endif; ?>
                </li>
                <li>
                    <?php if ($show_upload == 'true' && variable_get('filedepot_multiupload_shownewfilebutton', TRUE)): ?>
                    <span id="newfilelink">
                    <span class="first-child">
                    <a class="ctools-use-modal ctools-modal-filedepot-newfile-dialog-style" href="<?php print url('knowledge-repository/nojs/newfile'); ?>"><i class="fa fa-file-o" aria-hidden="true"></i> <?php echo t('File'); ?></a>
                    </span>
                    </span>
                    <?php endif; ?>
                </li>
                <!-- 
                <li>
                    <?php if ($show_upload == 'true'): ?>
                    <span id="multiuploadlink" class="yui-button yui-link-button">
                    <span class="first-child">
                    <a class="ctools-use-modal ctools-modal-filedepot-newfile-dialog-style" href="<?php print url('knowledge-repository/nojs/multiupload'); ?>"><i class="fa fa-files-o" aria-hidden="true"></i><?php if (variable_get('filedepot_multiupload_multibuttonname') !== 'Multiple Upload'):print check_plain(variable_get('filedepot_multiupload_multibuttonname'));else:print t('Multiple Upload');endif; ?>
                    </a>
                    </span>
                    </span> 
                    <?php endif; ?>
                </li>  -->
                
            </ul>
        </div>
        <div class="filedeport-sidebar">
            <!-- Leftside Folder Navigation generated onload by page javascript1 -->
            <div id="filedepotNavTreeDiv"></div>
            <div class="clearboth"></div>
        </div>
        <a href="javascript:void(0);" class="slider-arrow showdiv">&raquo;</a>
    </div>
    <!--  end filedepot side col  -->
    <div class="clearboth"></div>
    <!-- file depot sidebar in mobile  -->
    <div class="filedepot-sidebar-open">
        <div class="overlay"></div>
        <span class="pull-right">Filter Search </span>
        <div class="clearboth"></div>
    </div>
    <!-- file depot sidebar in mobile end -->
    <!-- Filedepot content -->
    <div id="filedepot_centercol">
      <div id="ajax-filedepot-success">
      </div>
      <div class="filedepot-alerts" id="">
          <?php print $messages; ?>
          <div id="filedepot_alert" class="filedepot_alert alert alert-block alert-danger" style="display: <?php print $show_alert ?>;">
              <div id="filedepot_alert_content" class="floatleft"><?php print $alert_message ?></div>
              <a class="close" data-dismiss="alert" href="#">×</a>
              <div class="clearboth"></div>
          </div>
      </div>
        <div class="filedepot_centercol_content">
            
            <div id="activefolder_container"></div>
            <div class="action-select"><?php print $toolbarform ?></div>
            <div class="clearboth"></div>
            <div class="active-folder-content">
                
                <div class="clearboth" id="showactivetags" style="display:none;">
                    <div id="tagsearchbox">Search Tags:&nbsp;<span id="activesearchtags"></span></div>
                </div>
                <div class="table-content">
                    <div id="filelistingheader"></div>
                    <div class="filedepot-data-scroll">
                        <form name="frmfilelisting" action="<?php print $actionurl_dir; ?>" id="dropzoneform-filedepot" class="dropzone myclasszone"  method="post" style="margin:0px;">
                            <div id="filelisting_container" ></div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- end of filedepot_centercol div -->
            <div class="clearboth"></div>
        </div>
    </div>
    <!-- end of filedepot div -->
    <div class="clearboth"></div>
    <!-- Supporting Panels - initially hidden -->
    <div id="filedetails" style="display:none;">
        <div id="filedetails_titlebar" class="hd"><?php print t('File Details'); ?></div>
        <div class="col-xs-12">
        <div id="filedetailsmenubar" class="yuimenubar" style="border:0px;">
            <div class="bd" style="margin:0px;padding:0;border:0px;font-size:11pt;">
                <ul class="first-of-type">
                    <li id="displaymenubaritem" class="yuimenubaritem first-of-type">
                        <a id="menubar_downloadlink" href="" TITLE="<?php print t('Download file'); ?>"><?php print t('Download'); ?></a>
                    </li>
                    <li id="editmenubaritem" class="yuimenubaritem first-of-type">
                        <a id="editfiledetailslink" href="#" TITLE="<?php print t('Edit File'); ?>"> <?php print t('Edit'); ?> </a>
                    </li>
                    <li id="addmenubaritem" class="yuimenubaritem first-of-type">
                        <a id="newversionlink" href="#" TITLE="<?php print t('Upload new version'); ?>"><?php print t('New Version'); ?></a>
                    </li>
                    <li id="approvemenubaritem" class="yuimenubaritem first-of-type">
                        <a id="approvefiledetailslink" href="#" TITLE="<?php print t('Approve File'); ?>"><?php print t('Approve'); ?></a>
                    </li>
                    <li id="deletemenubaritem" class="yuimenubaritem first-of-type ">
                        <a id="deletefiledetailslink" href="#" TITLE="<?php print t('Reject File'); ?>"><?php print t('Reject'); ?></a>
                    </li>
                     <li id="notifymenubaritem" class="yuimenubaritem first-of-type">
                        <a id="notifyfiledetailslink" href="#" TITLE="<?php print t('Enable email notification for any updates'); ?>"><?php print t('Subscribe'); ?></a>
                    </li>
                    
                    <li id="lockmenubaritem" class="yuimenubaritem first-of-type hidden ">
                        <a id="lockfiledetailslink" href="#" TITLE="<?php print t('Lock File'); ?>"><?php print t('Lock'); ?></a>
                    </li>
                   
                    <li id="broadcastmenubaritem" class="yuimenubaritem first-of-type hidden">
                        <a id="broadcastnotificationlink" href="#" TITLE="<?php print t('Send out a broadcast email notification'); ?>"><?php print t('Broadcast Notification'); ?></a>
                    </li> 
                </ul>

            </div>
          </div>
          <div id="filedetails_statusmsg" class="pluginInfo alignleft" style="display:none;"></div>
          

          </div>
          
          <div class="deletemssga"  id="deleteapprvemsg" style="display:none">
            <form name="filerejectionform" id="filerejectionform" onsubmit="deledefilewithrejection(this); return false;">
              <div class="form-group">
                <label class="control-label">Reason for rejection</label>
                <textarea name="rejectionmsg" id="rejectionmsg" class="form-control"> </textarea>
              </div>  
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </form>
          </div>

          
          
        <div id="displayfiledetails" class="alignleft" style="display:block;">
        </div>
          <div id="editfiledetails" class="alignleft" style="display:none;">
            <form id="frmFileDetails" name="frmFileDetails" method="POST">
                <div id="frmfile-edit-alert"></div>
                <input type="hidden" name="cid" value="">
                <input type="hidden" name="id" value="">
                <input type="hidden" name="version" value="">
                <input type="hidden" name="tagstore" value="">
                <input type="hidden" name="approved" value="">
                <input type="hidden" name="ftoken" id="frmFileDetails_ftoken" value="" />
                <div class="form-group">
                    <label class="control-label"><?php print t('File Name'); ?>
                    <span class="form-required" title="This field is required.">*</span>
                    <a href="#" data-toggle="tooltip" title="Enter the name of maximum in 255 characters" ><i class="fa fa-question-circle" aria-hidden="true"></i></a>
                    </label>
                    <input type="text" class="form-text form-control" id="filedetail-file-name" name="filetitle" value="" maxlength="255" />
                </div>
                <div class="form-group">
                    <label class="control-label"><?php print t('Folder'); ?>
                    <span class="form-required" title="This field is required.">*</span>
                    <a href="#" data-toggle="tooltip" title="Select the folder name in which you want to upload." ><i class="fa fa-question-circle" aria-hidden="true"></i></a> 
                    </label>
                    <div class="input-group">
                        <span id="folderoptions"></span>
                    </div>
                </div>
                <div class="form-group form-autocomplete">
                    <label class="control-label tag-alert"><?php print t('Tags'); ?>
                    <span class="form-required" title="This field is required.">*</span>
                    <a href="#" data-toggle="tooltip" title="Tag is a keyword assigned to content to make it easier to find. Tags must be separated by commas. Tag length should be between 3-50 characters." ><i class="fa fa-question-circle" aria-hidden="true"></i></a>
                    </label>
                    <div class="input-group" id="tagsfield">
                        <input id="editfile_tags" class="form-control form-text form-autocomplete text" name="tags" type="text" autocomplete="OFF" aria-autocomplete="list"/>
                        <input class="autocomplete" type="hidden" id="editfile_tags-autocomplete" value="<?php print $base_url;?>/knowledge-repository/autocomplete-tags" disabled="disabled" />
                        <span class="input-group-addon"><span class="icon glyphicon glyphicon-refresh" aria-hidden="true"></span></span>
                    </div>
                    <div id="editfile_autocomplete"></div>
                    <div id="tagswarning" class="pluginAlert" style="display:none;"><?php print t('Folder Perms not set'); ?></div>
                </div>
                <div class="form-group">
                    <label class="control-label"><?php print t('Description'); ?>
                    <a href="#" data-toggle="tooltip" title="Enter the description maximum in 1000 characters." ><i class="fa fa-question-circle" aria-hidden="true"></i></a>
                    </label>
                    <textarea rows="6" name="description" class="form-control" maxlength="1000"></textarea>
                </div>
                <div class="form-group">
                    <label for="" class="control-label"><?php print t('Author'); ?></label>
                    <div class="input-group"><span id="disp_owner" class="form-control"></span></div>
                </div>
                <div class="form-group">
                    <label for="" class="control-label"><?php print t('Date'); ?> / <?php print t('Size'); ?></label>
                    <div class="input-group">
                        <span class="form-control"><span id="disp_date"></span> / <span id="disp_size"></span></span>
                    </div>
                </div>
                <div class="form-group">
                    <label for="" class="control-label"><?php print t('Version Notes'); ?>
                    <a href="#" data-toggle="tooltip" title="Enter the version notes maximum in 100 characters." ><i class="fa fa-question-circle" aria-hidden="true"></i></a>
                    </label>
                    <input type="text" class="form-text form-control" name="version_note" value="" />
                </div>
                <div class="form-actions">
                    <input type="button" value="<?php print t('Submit'); ?>" class="form-submit btn btn-primary" onClick="makeAJAXUpdateFileDetails(this.form)"/>
                    <span style="padding-left:10px;"><input id="filedetails_cancel" class="form-submit btn btn-default" type="button" value="<?php print t('Cancel'); ?>"></span>
                </div>
            </form>
        </div>
        
    </div>
    <div id="folderperms"  class="modal-dialog modal-lg" style="display:none;">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Folder Permissions</h4>
            </div>
            <div id="folderperms_content" class="bd alignleft"></div>
        </div>
    </div>
    <div id="newfolderdialog" style="display:none;">
        <div class="hd"><?php print t('Add a new folder'); ?></div>
        <div id="newfolderdialog_form" class="bd" style="text-align:left;">
        </div>
    </div>
    <div id="moveIncomingFileDialog" style="display:none;">
        <div class="hd"><?php print t('Move Selected Files'); ?></div>
        <div class="pluginInfo alignleft" style="color:#000;font-size:90%">
            <?php print t('Select the destination folder'); ?>
        </div>
        <div id="movebatchfiledialog_form" class="bd" style="text-align:left;">
        </div>
    </div>
    <div id="movebatchfilesdialog" style="display:none;">
        <div class="hd"><?php print t('Move Selected File'); ?></div>
        <div class="pluginInfo alignleft" style="color:#000;font-size:90%"><?php print t('Only selected files where you are the owner will be moved to the target folder. Please select the target folder to continue.'); ?></div>
        <div id="movebatchfilesdialog_form" class="bd" style="text-align:left;">
        </div>
    </div>
    <div id="newfiledialog" class="kr-dialog" style="display:none;">
        <div id="newfiledialog_heading" class="hd"></div>
        <div id="add-verson-alert" style="margin:10px;"></div>
        <div class="bd" style="text-align:left;">
            <?php
                $form = drupal_get_form('filedepot_newversion_form');
                print drupal_render($form);
                ?>
        </div>
    </div>
    <div id="broadcastDialog" style="display:none;">
        <div class="hd"><?php print t('Send out a Broadcast Notification'); ?></div>
        <div class="pluginInfo alignleft" style="color:#000;font-size:90%"><?php print t('Broadcast email will be sent to all site members that have view access to this folder alerting them. A link to this file will be included'); ?></div>
        <div class="bd" style="text-align:left;">
            <form id="frmBroadcast" name="frmBroadcast" method="post">
                <input type="hidden" name="fid" value="">
                <input type="hidden" name="cid" value="">
                <div class="form-group">
                    <label for="parent" class="control-label"><?php print t('Message'); ?></label>
                    <textarea name="message" rows="4" class="form-textarea form-control"></textarea>
                </div>
                <div class="form-actions">
                    <input id="btnBroadcastSubmit" type="button" class="form-submit btn btn-primary" value="<?php print t('Send'); ?>">
                    <input id="btnBroadcastCancel" type="button" class="form-submit btn btn-default" value="<?php print t('Cancel'); ?>">
                </div>
            </form>
        </div>
    </div>
</div>
<!-- end of filedepotmodule wrapper div -->
<div class="clearboth"></div>