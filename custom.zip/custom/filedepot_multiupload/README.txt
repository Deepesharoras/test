- Introduction
This module extends the filedepot module with multiple upload support. 
Files can be uploaded with the plupload module which supports drag and drop.

- Installation
Just install the module by copying the module to site/all/modules
directory or install with drush.

If you get some errors about files missing and plupload is not loading,
you are probably missing the plupload library. Find the README file of
the plupload module and follow the instructions.
