<?php
   $html = "<ul class='notification-list'>";
   $count = 0;
   foreach ($ntf_result as $value) {

   	$userId = $value->userId;
    $module_id = $value->module_id;
      switch ($module_id) {
        case 'lesson_learned':
          if(isset($value->nid)) {

				$nid =  $value->nid; 
				$node_Info = node_load( $nid );
				$comment_Info = comment_load($nid);
				if(((isset($nid)) && (isset($node_Info->uid))) || ((isset($nid)) && (isset($comment_Info->uid)))){
					$alias = drupal_get_path_alias('node/'.$nid); 
					$event_time =  $value->event_time;
                    //Cut
                    if(isset($comment_Info->uid))
                    {
                      $entity_type = 'comment';
                      $uid = $comment_Info->uid;
                    }
                    if(isset($node_Info->uid))
                    {
                      $entity_type = 'node';
                      $uid = $node_Info->uid;
                    }

                    $user_personal_info = get_user_information($uid, $entity_type);
                    $userInfo = user_load($uid);
                    if(isset($userInfo->field_user_image['und'][0]['uri']))
                    {
                       $uri = $userInfo->field_user_image['und'][0]['uri'];
                    } else {
                     $uri = "public://default_images/default-img.png";   
                     } 
                     $style = 'simplecrop'; 
                     $style_url = image_style_url($style, $uri);
                     if (isset($style_url)) { 
                       $style_url = $style_url;
                     }else{
                       $uri = "public://default_images/default-img.png";   
                       $style = 'simplecrop'; 
                       $style_url = image_style_url($style, $uri);
                    }
                    //cut

                    if($value->event == 'created_published')
                    {
                       
                       if($count <= 10){
                       	$event_time = time_elapsed_string($event_time);
					              $html .= "<li class='notification'>
                          <div class='figure'><img typeof='foaf:Image' class='img-circle' src='".$style_url."' alt=''></div>
					                <div class='info'><a href='".$alias."'>New lesson posted by <strong>". $user_personal_info[$uid]['fname'] ." ". $user_personal_info[$uid]['lname'] ."</strong></a><small>".$event_time."</small></div></li>";
					          }
					    
                    }
                    if($value->event == 'draft')
                    {                       
                    	 if($count <= 10){
                    	 	$event_time = time_elapsed_string($event_time);
                        $html .= "<li class='notification'>
                        <div class='figure'><img typeof='foaf:Image' class='img-circle' src='".$style_url."' alt=''></div>
                        <div class='info'><a href='".$alias."'>New lesson has been saved as draft by <strong>". $user_personal_info[$uid]['fname'] ." ". $user_personal_info[$uid]['lname'] ."</strong></a><small>". $event_time."</small></div></li>";
					               }                        
                    }
                    if($value->event == 'updated_published')
                    {
               
                       if($count <= 10){
                         $event_time = time_elapsed_string($event_time);
                         $html .= "<li class='notification'>
                         <div class='figure'><img typeof='foaf:Image' class='img-circle' src='".$style_url."' alt=''></div>
                         <div class='info'><a href='".$alias."'>Lesson Updated and published by <strong>". $user_personal_info[$uid]['fname'] ." ". $user_personal_info[$uid]['lname'] ."</strong></a><small>". $event_time."</small></div></li>";
                        }
					 
                    }
                    if($value->event == 'comment_published')
                    { 
                     
                      //fetch nid first then recreate aliases
					  $query_get_comment = db_select('comment', 'cmt')
					  ->fields('cmt', array('pid','nid','uid','changed'))
	                  ->condition('cid', $nid,'=');
					  $result_comment = $query_get_comment->execute()->fetchAll(); 

					  foreach ($result_comment as $value_comment) {
      					   	$cnid = $value_comment->nid;
      					  	$uid_comment = $value_comment->uid;
      					  	$pid = $value_comment->pid;
      					  	$changed = $value_comment->changed;
                              $node_Info_c = node_load( $cnid );
                              $alias_node = drupal_get_path_alias('node/'.$cnid);                       
                             $userInfo = user_load($userInfo->uid);                     
       							if(isset($userInfo->field_first_name['und'][0]['value'])){
      							  $fname_comment = $userInfo->field_first_name['und'][0]['value'];

      							  if($user->uid == $value->userId) {
      					  	        $fname_comment = "You";
      					          }
      							}
      							if(isset($userInfo->field_last_name['und'][0]['value'])){
      							  $lname_comment = $userInfo->field_last_name['und'][0]['value'];
      							   if($user->uid == $value->userId) {
      					  	       $lname_comment = " ";
      					        }
      						}
					  }
                   if(isset($userInfo->field_user_image['und'][0]['uri']))
                    {
                       $uri = $userInfo->field_user_image['und'][0]['uri'];
                    } else {
                     $uri = "public://default_images/default-img.png";   
                     } 
                     $style = 'simplecrop'; 
                     $style_url = image_style_url($style, $uri);
                     if (isset($style_url)) { 
                       $style_url = $style_url;
                     }else{
                       $uri = "public://default_images/default-img.png";   
                       $style = 'simplecrop'; 
                       $style_url = image_style_url($style, $uri);
                    }




                                  if($count <= 10){
                                  	$event_time = time_elapsed_string($event_time);
            					    $html .= "<li class='notification'>
            					    <div class='figure'><img typeof='foaf:Image' class='img-circle' src='".$style_url."' alt=''></div>
            					    <div class='info'><a href='".$alias_node."'>A New Comment posted by <strong>". $fname_comment ." ". $lname_comment ."</strong></a><small> ". $event_time."</small></div></li>";
            					  }
                    }
                    if($value->event == 'rating')
                    {
                      //working fine
                        $nid = $value->nid;
                        $node_Info_c = node_load( $nid );
                        $alias_node = drupal_get_path_alias('node/'.$nid); 
                        $userId = $value->userId;                      
                        $userInfo = user_load($userId);
                           
           							if(isset($userInfo->field_first_name['und'][0]['value'])){
          							  $fname_rate = $userInfo->field_first_name['und'][0]['value'];

          							  if($user->uid == $userId) {
          					  	        $fname_rate = "You";
          					          }
          							}
          							if(isset($userInfo->field_last_name['und'][0]['value'])){
          							  $lname_rate = $userInfo->field_last_name['und'][0]['value'];
          							   if($user->uid == $userId) {
          					  	       $lname_rate = " ";
          					        }
          						}

                  if(isset($userInfo->field_user_image['und'][0]['uri']))
                    {
                       $uri = $userInfo->field_user_image['und'][0]['uri'];
                    } else {
                     $uri = "public://default_images/default-img.png";   
                     } 
                     $style = 'simplecrop'; 
                     $style_url = image_style_url($style, $uri);
                     if (isset($style_url)) { 
                       $style_url = $style_url;
                     }else{
                       $uri = "public://default_images/default-img.png";   
                       $style = 'simplecrop'; 
                       $style_url = image_style_url($style, $uri);
                    }


                      if($count <= 10){
                         $event_time = time_elapsed_string($event_time);
                         $html .= "<li class='notification'>
                         <div class='figure'><img typeof='foaf:Image' class='img-circle' src='".$style_url."' alt=''></div>
                         <div class='info'><a href='".$alias."'><strong>". $fname_rate ." ". $lname_rate ."</strong> Liked your lesson </a><small> ". $event_time."</small></div></li>";
					           }
                    }
                    if($value->event == 'comment_rating')
                    {
                      //get nid first
                      //fetch nid first then recreate aliases
                  	$cnid = $nid;
                    $node_Info_c = node_load( $cnid );
                    $alias_node = drupal_get_path_alias('node/'.$cnid); 
          				 	$userInfo = user_load( $value->userId );
                              $userInfo = user_load($userId);
                      		if(isset($userInfo->field_first_name['und'][0]['value'])){
          					  $fname_comment = $userInfo->field_first_name['und'][0]['value'];

          					  if($user->uid == $value->userId) {
          			  	        $fname_comment = "You";
          			  	        $var = " have";
          			          } else {
          			          	 $var = " ";
          			          }
          					}
          					if(isset($userInfo->field_last_name['und'][0]['value'])){
          					  $lname_comment = $userInfo->field_last_name['und'][0]['value'];
          					   if($user->uid == $value->userId) {
          			  	       $lname_comment = " ";
          			         }
          			     	}

                   if(isset($userInfo->field_user_image['und'][0]['uri']))
                    {
                       $uri = $userInfo->field_user_image['und'][0]['uri'];
                    } else {
                     $uri = "public://default_images/default-img.png";   
                     } 
                     $style = 'simplecrop'; 
                     $style_url = image_style_url($style, $uri);
                     if (isset($style_url)) { 
                       $style_url = $style_url;
                     }else{
                       $uri = "public://default_images/default-img.png";   
                       $style = 'simplecrop'; 
                       $style_url = image_style_url($style, $uri);
                    }			     	
                    if($count <= 10){
                    	$event_time = time_elapsed_string($event_time);
    		                $html .= "<li class='notification'>
    		                <div class='figure'><img typeof='foaf:Image' class='img-circle' src='".$style_url."' alt=''></div>
    		                <div class='info'><a href='".$alias_node."'><strong>". $fname_comment ." ". $lname_comment ."</strong>". $var ."  liked your comments </a><small>". $event_time."</small></div></li>";
    		           }
                    }
				}
          }
        break;
        case 'blog':
	      // $terms =  $value->term_id; 
          if(isset($value->nid)) {          	
				$nid =  $value->nid; 
				$node_Info = node_load( $nid );
				$comment_Info = comment_load($nid);
				if(((isset($nid)) && (isset($node_Info->uid))) || ((isset($nid)) && (isset($comment_Info->uid)))) {
					$alias = drupal_get_path_alias('node/'.$nid); 
					$event_time =  $value->event_time;	 

                    if(isset($node_Info->uid))
					 {
					  $userInfo = user_load($node_Info->uid);
	                 }
	                if(isset($comment_Info->uid))
					 {
					  $userInfo = user_load($comment_Info->uid);
	                 }
				    if(isset($userInfo->field_first_name['und'][0]['value'])){
					  $fname = $userInfo->field_first_name['und'][0]['value'];
					  if($user->uid == $userInfo->uid) {
					  	$fname = "You";
					  }
					}
				   if(isset($userInfo->field_last_name['und'][0]['value'])){
					  $lname = $userInfo->field_last_name['und'][0]['value'];
					  if($user->uid == $userInfo->uid) {
					  	$lname = " ";
					  }
					}
                   if(isset($userInfo->field_user_image['und'][0]['uri']))
                    {
                       $uri = $userInfo->field_user_image['und'][0]['uri'];
                    } else {
                     $uri = "public://default_images/default-img.png";   
                     } 
                     $style = 'simplecrop'; 
                     $style_url = image_style_url($style, $uri);
                     if (isset($style_url)) { 
                       $style_url = $style_url;
                     }else{
                       $uri = "public://default_images/default-img.png";   
                       $style = 'simplecrop'; 
                       $style_url = image_style_url($style, $uri);
                    }

                    if($value->event == 'created_published')
                    {
                     

                       if($count <= 10){
                       	$event_time = time_elapsed_string($event_time);
					      $html .= "<li class='notification'>
					      <div class='figure'><img typeof='foaf:Image' class='img-circle' src='".$style_url."' alt=''></div>
					      <div class='info'><a href='".$alias."'>New blog posted by <strong>". $fname ." ". $lname ."<strong></a><small>". $event_time."</small></div></li>";
					    }
					 

                    }
                    if($value->event == 'draft')
                    {

                     

                    	 if($count <= 10){
                    	 	$event_time = time_elapsed_string($event_time);
					    $html .= "<li class='notification'>
					    <div class='figure'><img typeof='foaf:Image' class='img-circle' src='".$style_url."' alt=''></div>
					    <div class='info'><a href='".$alias."'>New blog has been Saved as draft by <strong>". $fname ." ". $lname ."</strong></a><small>". $event_time."</small></div></li>";
					    }
                      


                    }
                    if($value->event == 'updated_published')
                    {
                     

                      if($count <= 10){
                      	$event_time = time_elapsed_string($event_time);
					    $html .= "<li class='notification'>
					    <div class='figure'><img typeof='foaf:Image' class='img-circle' src='".$style_url."' alt=''></div>
					    <div class='info'><a href='".$alias."'>Blog Updated by <strong>". $fname ." ". $lname ."</strong> </a><small>".$event_time."</small></div></li>";
					   }
					

                    }
                    if($value->event == 'comment_published')
                    { 
                     
                      //fetch nid first then recreate aliases
					  $query_get_comment = db_select('comment', 'cmt')
					  ->fields('cmt', array('pid','nid','uid','changed'))
	                  ->condition('cid', $nid,'=');
					  $result_comment = $query_get_comment->execute()->fetchAll(); 

					  foreach ($result_comment as $value_comment) {
					   	$cnid = $value_comment->nid;
					  	$uid_comment = $value_comment->uid;
					  	$pid = $value_comment->pid;
					  	$changed = $value_comment->changed;
                        $node_Info_c = node_load( $cnid );
                        $alias_node = drupal_get_path_alias('node/'.$cnid);                      
                        $userInfo = user_load($userInfo->uid);
                          
 							if(isset($userInfo->field_first_name['und'][0]['value'])){
							  $fname_comment = $userInfo->field_first_name['und'][0]['value'];

							  if($user->uid == $value->userId) {
					  	        $fname_comment = "You";
					          }
							}
							if(isset($userInfo->field_last_name['und'][0]['value'])){
							  $lname_comment = $userInfo->field_last_name['und'][0]['value'];
							   if($user->uid == $value->userId) {
					  	       $lname_comment = " ";
					        }
						}
					  }
if(isset($userInfo->field_user_image['und'][0]['uri']))
                    {
                       $uri = $userInfo->field_user_image['und'][0]['uri'];
                    } else {
                     $uri = "public://default_images/default-img.png";   
                     } 
                     $style = 'simplecrop'; 
                     $style_url = image_style_url($style, $uri);
                     if (isset($style_url)) { 
                       $style_url = $style_url;
                     }else{
                       $uri = "public://default_images/default-img.png";   
                       $style = 'simplecrop'; 
                       $style_url = image_style_url($style, $uri);
                    }					  
                      if($count <= 10){
                      	$event_time = time_elapsed_string($event_time);
					    $html .= "<li class='notification'> 
					    <div class='figure'><img typeof='foaf:Image' class='img-circle' src='".$style_url."' alt=''></div>
					    <div class='info'><a href='".$alias_node."'>A New Comment posted by <strong>". $fname_comment ." ". $lname_comment ."</strong></a> <small>". $event_time."</small></div></li>";
					  }
                    }
                    if($value->event == 'rating')
                    {
                      //working fine
                        $nid = $value->nid;
                        $node_Info_c = node_load( $nid );
                        $alias_node = drupal_get_path_alias('node/'.$nid); 
                        $userId = $value->userId;                      
                        $userInfo = user_load($userId);
                           
 							if(isset($userInfo->field_first_name['und'][0]['value'])){
							  $fname_rate = $userInfo->field_first_name['und'][0]['value'];

							  if($user->uid == $userId) {
					  	        $fname_rate = "You";
					          }
							}
							if(isset($userInfo->field_last_name['und'][0]['value'])){
							  $lname_rate = $userInfo->field_last_name['und'][0]['value'];
							   if($user->uid == $userId) {
					  	       $lname_rate = " ";
					        }
						} 


                      if($count <= 10){
                        
                      	$event_time = time_elapsed_string($event_time);
					     $html .= "<li class='notification'> 
					     <div class='figure'><img typeof='foaf:Image' class='img-circle' src='".$style_url."' alt=''></div>
					     <div class='info'><a href='".$alias."'><strong>". $fname_rate ." ". $lname_rate ."</strong> Liked your blog</a><small>". $event_time."</small></div></li>";
					     
					  }
                    }
                    if($value->event == 'comment_rating')
                    {
                      //get nid first
                      //fetch nid first then recreate aliases
 
 
                 	  $cnid = $nid;	 
                    $node_Info_c = node_load( $cnid );
                    $alias_node = drupal_get_path_alias('node/'.$cnid); 
				 	          $userInfo = user_load( $value->userId );

                    $userInfo = user_load($userId);
                    if(isset($userInfo->field_first_name['und'][0]['value'])){
        					    $fname_comment = $userInfo->field_first_name['und'][0]['value'];

        					    if($user->uid == $value->userId) {
        			  	          $fname_comment = "You";
        			  	          $var = " have";
        			            } else {
        			            	 $var = " ";
        			            }
        					  }
                    
        					if(isset($userInfo->field_last_name['und'][0]['value'])){
        					  $lname_comment = $userInfo->field_last_name['und'][0]['value'];
        					   if($user->uid == $value->userId) {
        			  	       $lname_comment = " ";
        			         }
        			     	}
                    if($count <= 10){
                    	$event_time = time_elapsed_string($event_time);
    		                $html .= "<li class='notification'> 
    		                <div class='figure'><img typeof='foaf:Image' class='img-circle' src='".$style_url."' alt=''></div>
    		                <div class='info'><a href='".$alias_node."'><strong>". $fname_comment ." ". $lname_comment ."</strong>". $var ."  liked your comments</a><small>".$event_time."</small></div></li>";
    		           }
                }
				}
          }
        break;        
        case 'ask_an_expert':
           if(isset($value->nid)) {

    				$nid =  $value->nid; 
    				$node_Info = node_load( $nid );
    				$comment_Info = comment_load($nid);

				  if(((isset($nid)) && (isset($node_Info->uid))) || ((isset($nid)) && (isset($comment_Info->uid)))){
  					$alias = drupal_get_path_alias('node/'.$nid); 
  					$event_time =  $value->event_time;	 
          
            if(isset($node_Info->uid))
					 {
					  $userInfo = user_load($node_Info->uid);
	         }
	          if(isset($comment_Info->uid))
					 {
					  $userInfo = user_load($comment_Info->uid);
	         }

					if(isset($userInfo->field_first_name['und'][0]['value'])){
					  $fname = $userInfo->field_first_name['und'][0]['value'];
					  if($user->uid == $userInfo->uid) {
					  	$fname = "You";
					  }
					}
					if(isset($userInfo->field_last_name['und'][0]['value'])){
					  $lname = $userInfo->field_last_name['und'][0]['value'];
					  if($user->uid == $userInfo->uid) {
					  	$lname = " ";
					  }
					}

                    if(isset($userInfo->field_user_image['und'][0]['uri']))
                    {
                       $uri = $userInfo->field_user_image['und'][0]['uri'];
                    } else {
                     $uri = "public://default_images/default-img.png";   
                     } 
                     $style = 'simplecrop'; 
                     $style_url = image_style_url($style, $uri);
                     if (isset($style_url)) { 
                       $style_url = $style_url;
                     }else{
                       $uri = "public://default_images/default-img.png";   
                       $style = 'simplecrop'; 
                       $style_url = image_style_url($style, $uri);
                    }

                    if($value->event == 'created_published')
                    {
                     

                       if($count <= 10){
                       	$event_time = time_elapsed_string($event_time);
					      $html .= "<li class='notification'>
                          <div class='figure'><img typeof='foaf:Image' class='img-circle' src='".$style_url."' alt=''></div>
					      <div class='info'><a href='".$alias."'>New Query posted by <strong>". $fname ." ". $lname ."</strong></a><small>". $event_time."</small></div></li>";
					    }
					

                    }
                    if($value->event == 'draft')
                    {

                       //not useful
                    	 if($count <= 10){
                    	 	$event_time = time_elapsed_string($event_time);
					    $html .= "<li class='notification'>
					    <div class='figure'><img typeof='foaf:Image' class='img-circle' src='".$style_url."' alt=''></div>
					    <div class='info'><a href='".$alias."'>New Query has been saved as draft by ". $fname ." ". $lname ."</a><small>".$event_time."</small></div></li>";
					    }
                      

                    }
                    if($value->event == 'updated_published')
                    {
                     
                      if($count <= 10){
                      	$event_time = time_elapsed_string($event_time);
					    $html .= "<li class='notification'>
					    <div class='figure'><img typeof='foaf:Image' class='img-circle' src='".$style_url."' alt=''></div>
					    <div class='info'><a href='".$alias."'>Query updated by <strong>". $fname ." ". $lname ."</strong></a><small>".$event_time."</small></div></li>";
					   }
			
                    }
                    if($value->event == 'comment_published')
                    { 
                     
                      //fetch nid first then recreate aliases
					  $query_get_comment = db_select('comment', 'cmt')
					  ->fields('cmt', array('pid','nid','uid','changed'))
	                  ->condition('cid', $nid,'=');
					  $result_comment = $query_get_comment->execute()->fetchAll(); 

					  foreach ($result_comment as $value_comment) {
					   	$cnid = $value_comment->nid;
					  	$uid_comment = $value_comment->uid;
					  	$pid = $value_comment->pid;
					  	$changed = $value_comment->changed;
                        $node_Info_c = node_load( $cnid );
                        $alias_node = drupal_get_path_alias('node/'.$cnid); 

                      
              $userInfo = user_load($value->userId);

              if(isset($userInfo->field_user_image['und'][0]['uri']))
                    {
                       $uri = $userInfo->field_user_image['und'][0]['uri'];
                    } else {
                     $uri = "public://default_images/default-img.png";   
                     } 
                     $style = 'simplecrop'; 
                     $style_url = image_style_url($style, $uri);
                     if (isset($style_url)) { 
                       $style_url = $style_url;
                     }else{
                       $uri = "public://default_images/default-img.png";   
                       $style = 'simplecrop'; 
                       $style_url = image_style_url($style, $uri);
                      }  

 							if(isset($userInfo->field_first_name['und'][0]['value'])){
							  $fname_comment = $userInfo->field_first_name['und'][0]['value'];

							  if($user->uid == $userInfo->uid) {
					  	        $fname_comment = "You";
					          }
							}
							if(isset($userInfo->field_last_name['und'][0]['value'])){
							  $lname_comment = $userInfo->field_last_name['und'][0]['value'];
							   if($user->uid == $userInfo->uid) {
					  	       $lname_comment = " ";
					        }
						}
					  }
                      if($count <= 10){
                      	$event_time = time_elapsed_string($event_time);
					    $html .= "<li class='notification'>
					    <div class='figure'><img typeof='foaf:Image' class='img-circle' src='".$style_url."' alt=''></div>
					    <div class='info'><a href='".$alias_node."'>A New Comment posted by <strong>". $fname_comment ." ". $lname_comment ."</strong>  </a><small>".$event_time."</small></div></li>";
					  }
                    }
                    if($value->event == 'rating')
                    {
                      //working fine
                        $nid = $value->nid;
                        $node_Info_c = node_load( $nid );
                        $alias_node = drupal_get_path_alias('node/'.$nid); 
                        $userId = $value->userId;

                      
                        $userInfo = user_load($userId);
                           
 							if(isset($userInfo->field_first_name['und'][0]['value'])){
							  $fname_rate = $userInfo->field_first_name['und'][0]['value'];

							  if($user->uid == $userId) {
					  	        $fname_rate = "You";
					          }
							}
							if(isset($userInfo->field_last_name['und'][0]['value'])){
							  $lname_rate = $userInfo->field_last_name['und'][0]['value'];
							   if($user->uid == $userId) {
					  	       $lname_rate = " ";
					        }
						}
						 


                      if($count <= 10){
                      	 
                      	 $event_time = time_elapsed_string($event_time);
					     $html .= "<li class='notification'>
					     <div class='figure'><img typeof='foaf:Image' class='img-circle' src='".$style_url."' alt=''></div>
					     <div class='info'><a href='".$alias."'> <strong>". $fname_rate ." ". $lname_rate ."</strong> Liked your Query .</a><small>".$event_time."</small></div></li>";
					    
					  }
                    }
                    if($value->event == 'comment_rating')
                    {
                      //get nid first
                      //fetch nid first then recreate aliases
 
 
                 	$cnid = $nid;
	 
                    $node_Info_c = node_load( $cnid );
                    $alias_node = drupal_get_path_alias('node/'.$cnid); 
				 	$userInfo = user_load( $value->userId );

                    $userInfo = user_load($userId);
            		if(isset($userInfo->field_first_name['und'][0]['value'])){
					  $fname_comment = $userInfo->field_first_name['und'][0]['value'];

					  if($user->uid == $value->userId) {
			  	        $fname_comment = "You";
			  	        $var = " have";
			          } else {
			          	 $var = " ";
			          }
					}
					if(isset($userInfo->field_last_name['und'][0]['value'])){
					  $lname_comment = $userInfo->field_last_name['und'][0]['value'];
					   if($user->uid == $value->userId) {
			  	       $lname_comment = " ";
			         }
			     	}
                    if($count <= 10){
                    	    $event_time = time_elapsed_string($event_time);

    		                $html .= "<li class='notification'>
    		                <div class='figure'><img typeof='foaf:Image' class='img-circle' src='".$style_url."' alt=''></div>
    		                <div class='info'><a href='".$alias_node."'><strong>". $fname_comment ." ". $lname_comment ."</strong>". $var ." liked your comments  </a><small>".$event_time."</small></div></li>";
    		           }
                    }
				}
          }
        break;
        case 'forum':
	      // $terms =  $value->term_id; 
          if(isset($value->nid)) {

				$nid =  $value->nid; 
				$node_Info = node_load( $nid );
				$comment_Info = comment_load($nid);
				if(((isset($nid)) && (isset($node_Info->uid))) || ((isset($nid)) && (isset($comment_Info->uid)))){

					$alias = drupal_get_path_alias('node/'.$nid); 
					$event_time =  $value->event_time;	 

                    
                    if(isset($node_Info->uid))
					 {
					  $userInfo = user_load($node_Info->uid);
	                 }
	                if(isset($comment_Info->uid))
					 {
					  $userInfo = user_load($comment_Info->uid);
	                 }
					if(isset($userInfo->field_first_name['und'][0]['value'])){
					  $fname = $userInfo->field_first_name['und'][0]['value'];
					  if($user->uid == $userInfo->uid) {
					  	$fname = "You";
					  }
					}
					if(isset($userInfo->field_last_name['und'][0]['value'])){
					  $lname = $userInfo->field_last_name['und'][0]['value'];
					  if($user->uid == $userInfo->uid) {
					  	$lname = " ";
					  }
					}
                   

                   /* fetch user picture */
                   if(isset($userInfo->field_user_image['und'][0]['uri']))
                    {
                       $uri = $userInfo->field_user_image['und'][0]['uri'];
                    } else {
                     $uri = "public://default_images/default-img.png";   
                     } 
                     $style = 'simplecrop'; 
                     $style_url = image_style_url($style, $uri);
                     if (isset($style_url)) { 
                       $style_url = $style_url;
                     }else{
                       $uri = "public://default_images/default-img.png";   
                       $style = 'simplecrop'; 
                       $style_url = image_style_url($style, $uri);
                    }



                    if($value->event == 'created_published')
                    {
                       
                       if($count <= 10){
                       	$event_time = time_elapsed_string($event_time);
					      $html .= "<li class='notification'> 
					      <div class='figure'><img typeof='foaf:Image' class='img-circle' src='".$style_url."' alt=''></div>
					      
					      <div class='info'><a href='".$alias."'>New Forum posted by <strong>". $fname ." ". $lname ."</strong></a><small>".$event_time."</small></div></li>";
					    }
				 
                    }
                    if($value->event == 'draft')
                    {

                       
                    	 if($count <= 10){
                    	 	$event_time = time_elapsed_string($event_time);
					    $html .= "<li class='notification'><div class='figure'><img typeof='foaf:Image' class='img-circle' src='".$style_url."' alt=''></div><div class='info'><a href='".$alias."'>New Forum has been Saved as draft by <strong>". $fname ." ". $lname ."</strong></a><small>".$event_time."</small></div></li>";
					    }
                        

                    }
                    if($value->event == 'updated_published')
                    {
                                          	
                      if($count <= 10){
                      	$event_time = time_elapsed_string($event_time);
					    $html .= "<li class='notification'><div class='figure'><img typeof='foaf:Image' class='img-circle' src='".$style_url."' alt=''></div><div class='info'><a href='".$alias."'>Forum Updated by <strong>". $fname ." ". $lname ."</strong></a><small>".$event_time."</small></div></li>";
					   }
				 
                    }
                    if($value->event == 'comment_published')
                    { 
                     
                      //fetch nid first then recreate aliases
					  $query_get_comment = db_select('comment', 'cmt')
					  ->fields('cmt', array('pid','nid','uid','changed'))
	                  ->condition('cid', $nid,'=');
					  $result_comment = $query_get_comment->execute()->fetchAll(); 

					  foreach ($result_comment as $value_comment) {
					   	$cnid = $value_comment->nid;
					  	$uid_comment = $value_comment->uid;
					  	$pid = $value_comment->pid;
					  	$changed = $value_comment->changed;
                        $node_Info_c = node_load( $cnid );
                        $alias_node = drupal_get_path_alias('node/'.$cnid); 

                      
                       $userInfo = user_load($userInfo->uid);
                              if(isset($userInfo->field_user_image['und'][0]['uri']))
                    {
                       $uri = $userInfo->field_user_image['und'][0]['uri'];
                    } else {
                     $uri = "public://default_images/default-img.png";   
                     } 
                     $style = 'simplecrop'; 
                     $style_url = image_style_url($style, $uri);
                     if (isset($style_url)) { 
                       $style_url = $style_url;
                     }else{
                       $uri = "public://default_images/default-img.png";   
                       $style = 'simplecrop'; 
                       $style_url = image_style_url($style, $uri);
                      }  
                          
 							if(isset($userInfo->field_first_name['und'][0]['value'])){
							  $fname_comment = $userInfo->field_first_name['und'][0]['value'];

							  if($user->uid == $value->userId) {
					  	        $fname_comment = "You";
					          }
							}
							if(isset($userInfo->field_last_name['und'][0]['value'])){
							  $lname_comment = $userInfo->field_last_name['und'][0]['value'];
							   if($user->uid == $value->userId) {
					  	       $lname_comment = " ";
					        }
						}
					  }
                      if($count <= 10){
                      	$event_time = time_elapsed_string($event_time);
					    $html .= "<li class='notification'><div class='figure'><img typeof='foaf:Image' class='img-circle' src='".$style_url."' alt=''></div><div class='info'><a href='".$alias_node."'>A New Comment posted by <strong>". $fname_comment ." ". $lname_comment ."</strong></a><small>".$event_time."</small></div></li>";
					  }
                    }
                    if($value->event == 'rating')
                    {
                      //working fine
                        $nid = $value->nid;
                        $node_Info_c = node_load( $nid );
                        $alias_node = drupal_get_path_alias('node/'.$nid); 
                        $userId = $value->userId;                      
                        $userInfo = user_load($userId);                           
 							if(isset($userInfo->field_first_name['und'][0]['value'])){
							  $fname_rate = $userInfo->field_first_name['und'][0]['value'];

							  if($user->uid == $userId) {
					  	        $fname_rate = "You";
					          }
							}
							if(isset($userInfo->field_last_name['und'][0]['value'])){
							  $lname_rate = $userInfo->field_last_name['und'][0]['value'];
							   if($user->uid == $userId) {
					  	       $lname_rate = " ";
					        }
						} 


                      if($count <= 10){
                      	

                      	$event_time = time_elapsed_string($event_time);
					     $html .= "<li class='notification'><div class='figure'><img typeof='foaf:Image' class='img-circle' src='".$style_url."' alt=''></div><div class='info'><a href='".$alias."'><strong>". $fname_rate ." ". $lname_rate ."</strong> Liked your Forum</a><small>".$event_time."</small></div></li>";
					    	

					  }
                    }
                    if($value->event == 'comment_rating')
                    {
                      //get nid first
                      //fetch nid first then recreate aliases 
                 	  $cnid = $nid;	 
                    $node_Info_c = node_load( $cnid );
                    $alias_node = drupal_get_path_alias('node/'.$cnid); 
				 	          $userInfo = user_load( $value->userId );

                    $userInfo = user_load($userId);
                   if(isset($userInfo->field_first_name['und'][0]['value'])){
                    $fname_comment = $userInfo->field_first_name['und'][0]['value'];

                    if($user->uid == $value->userId) {
                      $fname_comment = "You";
                      $var = " have";
                    } else {
                    	 $var = " ";
                    }
					         }
        					if(isset($userInfo->field_last_name['und'][0]['value'])){
        					  $lname_comment = $userInfo->field_last_name['und'][0]['value'];
        					   if($user->uid == $value->userId) {
        			  	       $lname_comment = " ";
        			         }
        			     	}


                  if(isset($userInfo->field_user_image['und'][0]['uri']))
                    {
                       $uri = $userInfo->field_user_image['und'][0]['uri'];
                    } else {
                     $uri = "public://default_images/default-img.png";   
                     } 
                     $style = 'simplecrop'; 
                     $style_url = image_style_url($style, $uri);
                     if (isset($style_url)) { 
                       $style_url = $style_url;
                     }else{
                       $uri = "public://default_images/default-img.png";   
                       $style = 'simplecrop'; 
                       $style_url = image_style_url($style, $uri);
                    }

                    if($count <= 10){
                    	$event_time = time_elapsed_string($event_time);
    		            $html .= "<li class='notification'><div class='figure'><img typeof='foaf:Image' class='img-circle' src='".$style_url."' alt=''></div><div class='info'><a href='".$alias_node."'><strong>". $fname_comment ." ". $lname_comment ."</strong>". $var ."  liked your comments </a><small>".$event_time."</small></div></li>";
    		           }
                  }
				  }
        }
        break;
        default:
        $html .= "";

      	}

      	$count++;
  } 

  $html .= "</ul>";

  print $html;