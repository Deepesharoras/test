<?php
   // echo "dhfkjsd hksdh fkhsdkhf khsdkahf ksdkf h";
   // display($nt_object);
?>
<ul class="notification-list">
<?php 
global $user;
foreach($nt_object  as $row) : 
    $sender_name = $row->field_first_name_value ." ".$row->field_last_name_value; 
    $sender_nick_name_link =  ($user->uid ==  $row->sender_id) ?  'You' : $sender_name ;
    
    if($sender_nick_name_link == 'You'){
    	$sender_nick_name = l('You','my-profile');
    } else {
    	$sender_nick_name = l($sender_name,'profile/'.$row->name);
    }
   // display($row);
    /* if($row->uri !=''){
       $img_uri = $row->uri;
    }else{
        $img_uri = "public://default_images/d_p.png";
    }
    // echo profile_icon 
    if(!file_exists($img_uri))
    {
        $img_uri = "public://default_images/d_p.png";
    }
    $style_url = image_style_url('profile_icon', $img_uri); */
    
    $style_url = get_profile_img($row->uri) ;
    $img_tag = "<img typeof='foaf:Image' class='img-circle' src='" . $style_url . "' alt=''>";
    
     if( $user->name == $row->name ){
    	$uname_url = 'my-profile';
    } else {
    	$uname_url = 'profile/'.$row->name;
    }
    
    
    switch($row->nt_type){
        case 'FREIND_REQUEST':
    ?>
         <li class="notification"> 
            <div class="figure">
                 <!--  <img typeof='foaf:Image' class='img-circle' src="<?php // echo $style_url ?>" alt="">   --> 
                <?php print l($img_tag, $uname_url, array('attributes' => array('target'=>'_blank'), 'html' => TRUE )); ?>
            </div> 
            <div class="info">
                 <h5><?php //echo t('@name has sent contact request',array('@name' => $sender_nick_name )); ?> 
                     <?php echo $sender_nick_name.' has sent contact request'; ?>   
                     <?php print  l('My Networks','mynetwork',array('query' => array('qt-all_contacts'=> 3),'attributes' => array('title' => 'friend request','class' => array('')))); ?></h5>
                <small><?php echo time_elapsed_string(format_date($row->created)); ?></small>
            </div>
        </li>
        
        <?php 
           break;
            case 'FREIND_APPROVE':
        ?>
         <li class="notification"> 
            <div class="figure">           
                
                <?php print l($img_tag, $uname_url, array('attributes' => array('target'=>'_blank'), 'html' => TRUE )); ?>
            
            </div> 
            <div class="info">
                 <h5><?php echo t('@name has accepted your contact request',array('@name' => $sender_nick_name )); ?>   <?php      print  l('My Networks','mynetwork',array('query' => array('qt-all_contacts'=> 3),'attributes' => array('title' => 'friend request','class' => array('')))); ?></h5>
                <small><?php echo time_elapsed_string(format_date($row->created)); ?></small>
            </div>
        </li>
      <?php 
        break; 
        case 'TOPIC_CREATE':
    ?>
    
        <li class="notification"> 
            <div class="figure">
                <?php print l($img_tag, $uname_url, array('attributes' => array('target'=>'_blank'), 'html' => TRUE )); ?>
            </div> 
            <div class="info">
               <h5> <?php echo $sender_nick_name.' have created a new topic'; ?> 
                    <?php print l($row->title,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'topic','class' => array()))); ?></h5> 
                <small><?php echo time_elapsed_string(format_date($row->created)); ?></small>
            </div>
             
        </li>
    
    <?php 
        break; 
        case 'LIKE_ON_TOPIC':
    ?>
    
        <li class="notification"> 
            <div class="figure">
                <?php print l($img_tag, $uname_url, array('attributes' => array('target'=>'_blank'), 'html' => TRUE )); ?>
            </div> 
            <div class="info">
                <h5> <?php echo $sender_nick_name.'likes topic'; ?>  
                     <?php print l($row->title,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'topic','class' => array()))); ?> </h5> 
                <small><?php echo time_elapsed_string(format_date($row->created)); ?></small>
            </div>
             
        </li>

    <?php 
        break; 
        case 'FOLLOW_TOPIC':
    ?>
    
        <li class="notification"> 
            <div class="figure">
             <?php print l($img_tag, $uname_url, array('attributes' => array('target'=>'_blank'), 'html' => TRUE )); ?> 
            </div>
            <div class="info"> 
              <h5> <?php echo $sender_nick_name; ?> followed topic <?php print l($row->title,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'followed topic','class' => array()))); ?></h5> 
                <small><?php echo time_elapsed_string(format_date($row->created)); ?></small>
            </div>
             
        </li>
    
    <?php 
        break; 
        case 'FOLLOW_FORUM':
    ?>
         <li class="notification"> 
            <div class="figure">
             <?php print l($img_tag, $uname_url, array('attributes' => array('target'=>'_blank'), 'html' => TRUE )); ?>
            </div>
            <div class="info"> 
                <h5> <?php echo $sender_nick_name; ?> followed forum <?php print l($row->title,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'followed forum','class' => array('')))); ?> </h5> 
                <small><?php echo time_elapsed_string(format_date($row->created)); ?></small>
            </div>
             
         </li>
     
     <?php 
        break; 
        case 'TOPIC_NEW_COMMENT':
    ?>
        <li class="notification"> 
            <div class="figure"> 
                <?php print l($img_tag, $uname_url, array('attributes' => array('target'=>'_blank'), 'html' => TRUE )); ?>
            </div>
             <div class="info"> 
             <h5>  <?php echo $sender_nick_name; ?> commented on topic <?php print l($row->title,'node/'.$row->entity_id,array('attributes' => array('title' => 'new comment on topic','class' => array('')))); ?></h5> 
             <small> <?php  echo time_elapsed_string(format_date($row->created)); ?></small>
             </div>
             
         </li>
     
    <?php 
        break; 
        case 'BLOG_CREATE':
    ?>
        <li class="notification"> 
            <div class="figure">
                <?php print l($img_tag, $uname_url, array('attributes' => array('target'=>'_blank'), 'html' => TRUE )); ?>
            </div>
             <div class="info"> 
                <h5>  <?php echo $sender_nick_name; ?> created a blog <?php print l($row->title,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'New blog','class' => array('')))); ?></h5> 
                <small><?php  echo time_elapsed_string(format_date($row->created)); ?></small>
             </div>
             
         </li>
     
     <?php 
        break; 
        case 'LIKE_ON_BLOG':
     ?>
            <li class="notification">  
                <div class="figure">
                    <?php print l($img_tag, $uname_url, array('attributes' => array('target'=>'_blank'), 'html' => TRUE )); ?>
                </div>
                <div class="info">
                <h5>  <?php echo $sender_nick_name; ?> have liked blog' <?php print  l($row->title,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'Blog like','class' => array('')))); ?> </h5> 
                <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
            </li>
     <?php 
        break; 
        case 'POST_CREATE':
    ?>
            <li class="notification"> 
                <div class="figure">
                    <?php print l($img_tag, $uname_url, array('attributes' => array('target'=>'_blank'), 'html' => TRUE )); ?>
                 </div>
                 <div class="info">
                 <h5> <?php echo $sender_nick_name; ?> created a new post <?php print l($row->title,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'New post','class' => array('')))); ?></h5> 
                 <small><?php  echo time_elapsed_string(format_date($row->created)); ?></small>
                 </div>
            </li>
    <?php 
        break; 
        case 'POST_NEW_COMMENT':
    ?>
            <li class="notification"> 
                <div class="figure">
                    <?php print l($img_tag, $uname_url, array('attributes' => array('target'=>'_blank'), 'html' => TRUE )); ?>
                 </div>
                 <div class="info">
                    <h5><?php echo $sender_nick_name; ?> wrote a comment on post <?php print  l($row->title,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'Comment on post','class' => array('')))); ?></h5>
                    <small><?php  echo time_elapsed_string(format_date($row->created)); ?></small>
                 </div> 
                
            </li> 
    
    <?php 
        break; 
        case 'FOLLOW_POST':
    ?>
            <li class="notification"> 
                <div class="figure">
                    <?php print l($img_tag, $uname_url, array('attributes' => array('target'=>'_blank'), 'html' => TRUE )); ?>
                 </div>
                <div class="info"> 
                    <h5><?php echo $sender_nick_name; ?> followed  post <?php print  l($row->title,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'followed  post','class' => array('')))); ?></h5>
                    <small><?php echo time_elapsed_string(format_date($row->created)); ?></small>
                </div>
                
            </li>
    
    <?php 
        break; 
        case 'LIKE_ON_POST':
    ?>
        <li class="notification"> 
            <div class="figure">
                <?php print l($img_tag, $uname_url, array('attributes' => array('target'=>'_blank'), 'html' => TRUE )); ?>
            </div>
           <div class="info">
            <h5><?php echo $sender_nick_name; ?>  likes post <?php print  l($row->title,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'followed  post','class' => array('')))); ?></h5>
            <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
        </li>
    
     
    <?php 
        break; 
        case 'LESSON_CREATE':
    ?>
         <li class="notification"> 
            <div class="figure">
              <?php print l($img_tag, $uname_url, array('attributes' => array('target'=>'_blank'), 'html' => TRUE )); ?>
             </div>
             <div class="info">
                <h5><?php echo $sender_nick_name; ?> created a lesson <?php print l($row->title,'node/'.$row->entity_id,array( 'attributes' => array('title' => ' new lesson ','class' => array('')))); ?></h5>
                <small><?php echo time_elapsed_string(format_date($row->created)); ?></small>
             </div>
             
        </li>
    <?php 
        break; 
        case 'LESSON_UPDATED':
    ?>
        <li class="notification"> 
            <div class="figure">
                <?php print l($img_tag, $uname_url, array('attributes' => array('target'=>'_blank'), 'html' => TRUE )); ?>    
            </div>
            <div class="info"> 
                <h5><?php echo $sender_nick_name; ?> updated lesson <?php print l($row->title,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'updated lesson','class' => array('')))); ?></h5>
                <small><?php echo time_elapsed_string(format_date($row->created)); ?></small>
            </div>
             
        </li>
    <?php 
        break; 
        case 'LESSON_COMMENT':
    ?>
            <li class="notification"> 
                <div class="figure">
                    <?php print l($img_tag, $uname_url, array('attributes' => array('target'=>'_blank'), 'html' => TRUE )); ?>
                </div>
                <div class="info">
                <h5><?php echo $sender_nick_name ?> post a comment on lesson <?php print l($row->title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'updated lesson','class' => array('')))); ?></h5>
                 <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
            </li>
    <?php 
        break; 
        case 'QUERY_CREATE':
    ?>
        <li class="notification"> 
            <div class="figure">
                <?php print l($img_tag, $uname_url, array('attributes' => array('target'=>'_blank'), 'html' => TRUE )); ?>
             </div>
             <div class="info">
             <h5><?php echo $sender_nick_name; ?> created a new query <?php print l($row->title,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'new query','class' => array('') ))); ?></h5>
                <small><?php echo time_elapsed_string(format_date($row->created)); ?></small>
             </div>        
        </li>
    <?php 
        break;
        case 'QUERY_COMMENT':
            ?>
        <li class="notification" > 
            <div class="figure">
                   <?php print l($img_tag, $uname_url, array('attributes' => array('target'=>'_blank'), 'html' => TRUE )); ?>
             </div>
             <div class="info">
             <h5><?php echo $sender_nick_name .' replied on query '; ?> <?php  print l($row->title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'new reply on query','class' => array('') ))); ?></h5>
             <small><?php echo time_elapsed_string(format_date($row->created)); ?></small>
             </div>
        </li>
        
         <?php 
        break; 
        case 'TASK_CREATE':
    ?>
        <li class="notification"> 
            <div class="figure">
                <?php print l($img_tag, $uname_url, array('attributes' => array('target'=>'_blank'), 'html' => TRUE )); ?>
             </div>
             <div class="info">
                <h5> <?php echo $sender_nick_name; ?> created a task <?php print l($row->title,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'new task','class' => array('') ))); ?></h5>
                <small><?php echo time_elapsed_string(format_date($row->created)); ?></small>
             </div>        
        </li>
        <?php 
        break;
        case 'PROJECT_CREATE':
            ?>
        <li class="notification" > 
            <div class="figure">
                   <?php print l($img_tag, $uname_url, array('attributes' => array('target'=>'_blank'), 'html' => TRUE )); ?>
             </div>
             <div class="info">
             <h5><?php echo $sender_nick_name .' create new project '; ?> <?php  print l($row->title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'new reply on query','class' => array('') ))); ?></h5>
             <small><?php echo time_elapsed_string(format_date($row->created)); ?></small>
             </div>
        </li>
        
        <?php 
        break;
        case 'TEAM_CREATE':
            ?>
        <li class="notification" > 
            <div class="figure">
                   <?php print l($img_tag, $uname_url, array('attributes' => array('target'=>'_blank'), 'html' => TRUE )); ?>
             </div>
             <div class="info">
             <h5><?php echo $sender_nick_name .' added you as Team member in '; ?> <?php  print l($row->title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'new reply on query','class' => array('') ))); ?></h5>
             <small><?php echo time_elapsed_string(format_date($row->created)); ?></small>
             </div>
        </li>
        <?php 
        break; 
        case 'WIKI_CREATE':
        ?>
        <li class="notification"> 
            <div class="figure">
                <?php print l($img_tag, $uname_url, array('attributes' => array('target'=>'_blank'), 'html' => TRUE )); ?>
             </div>
             <div class="info">
             <h5> <?php echo $sender_nick_name; ?> created a wiki <?php print l($row->title,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'new task','class' => array('') ))); ?></h5>
                <small><?php echo time_elapsed_string(format_date($row->created)); ?></small>
             </div>        
        </li>
        <?php 
        break;
        case 'WIKI_UPDATED':
        ?>
        <li class="notification" > 
            <div class="figure">
                   <?php print l($img_tag, $uname_url, array('attributes' => array('target'=>'_blank'), 'html' => TRUE )); ?>
             </div>
             <div class="info">
             <h5><?php echo $sender_nick_name .' updated wiki '; ?> <?php  print l($row->title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'new reply on query','class' => array('') ))); ?></h5>
             <small><?php echo time_elapsed_string(format_date($row->created)); ?></small>
             </div>
        </li> 
        
        <?php 
        break;
        case 'KM_FOLDER_CREATE':
        ?>
        <li class="notification" > 
            <div class="figure">
                   <?php print l($img_tag, $uname_url, array('attributes' => array('target'=>'_blank'), 'html' => TRUE )); ?>
                   <?php 
                     // get cid of folder or reach  that location thorugh link
                     $folder_array = get_filedepot_folder_from_nid($row->entity_id);                 
                   ?>
             </div>
             <div class="info">
             <h5><?php echo $sender_nick_name .' created a folder '; ?> <?php  print l($row->title ,'knowledge-repository/folder/'.$folder_array['cid'],array( 'attributes' => array('title' => 'New Folder','class' => array('') ))); ?></h5>
             <small><?php echo time_elapsed_string(format_date($row->created)); ?></small>
             </div>
        </li> 
        <?php 
        break;
        case 'KM_FOLDER_UPDATE':
        ?>
        <li class="notification" > 
            <div class="figure">
                   <?php print l($img_tag, $uname_url, array('attributes' => array('target'=>'_blank'), 'html' => TRUE )); ?>
                   
                   <?php 
                     // get cid of folder or reach  that location thorugh link
                     $folder_array = get_filedepot_folder_from_nid($row->entity_id);                 
                   ?>
             </div>
             <div class="info">
             <h5><?php echo $sender_nick_name .' updated a folder '; ?> <?php  print l($row->title ,'knowledge-repository/folder/'.$folder_array['cid'],array( 'attributes' => array('title' => 'new reply on query','class' => array('') ))); ?></h5>
             <small><?php echo time_elapsed_string(format_date($row->created)); ?></small>
             </div>
        </li>
        <?php 
        break;
        case 'KM_FOLDER_SHARE':
        ?>
        <li class="notification" > 
            <div class="figure">
                   <?php print l($img_tag, $uname_url, array('attributes' => array('target'=>'_blank'), 'html' => TRUE )); ?>
                   <?php 
                         $file_array = get_filedepot_folder_from_cid($row->entity_id); // here $row->entity_id is Folder cid
                   ?>                  
             </div>
             <div class="info">
             <h5> <?php echo $sender_nick_name .' share a folder '; ?> <?php  print l($file_array['name'] ,'knowledge-repository/folder/'.$row->entity_id,array( 'attributes' => array('title' => 'new reply on query','class' => array('') ))); ?></h5>
             <small><?php echo time_elapsed_string(format_date($row->created)); ?></small>
             </div>
        </li>
        
        
        <?php 
        break;
        case 'KM_FILE_UPLOAD':
        ?>
        <li class="notification" > 
            <div class="figure">
                   <?php print l($img_tag, $uname_url, array('attributes' => array('target'=>'_blank'), 'html' => TRUE )); ?>
                   <?php 
                     // get cid of folder or reach  that location thorugh link
                     $folder_array = get_filedepot_folder_from_nid($row->entity_id);                 
                   ?>
             </div>
             <div class="info">
             <h5> <?php echo $sender_nick_name .' uploaded a new file in'; ?> <?php  print l($row->title ,'knowledge-repository/folder/'.$folder_array['cid'],array( 'attributes' => array('title' => 'new reply on query','class' => array('') ))); ?></h5>
             <small><?php echo time_elapsed_string(format_date($row->created)); ?></small>
             </div>
        </li>
        
        <?php 
        break;
        case 'KM_FILE_UPDATED':
        ?>
        <li class="notification" > 
            <div class="figure">
                   <?php print l($img_tag, $uname_url, array('attributes' => array('target'=>'_blank'), 'html' => TRUE )); ?>
             </div>
             <div class="info">
             <h5><?php echo $sender_nick_name .' updeted file'; ?> <?php  print l($row->title ,'knowledge-repository/folder/'.$row->entity_id,array( 'attributes' => array('title' => 'new reply on query','class' => array('') ))); ?></h5>
             <small><?php echo time_elapsed_string(format_date($row->created)); ?></small>
             </div>
        </li>
        
        <?php 
        break;
        case 'KM_FOLDER_UPLOAD':
        ?>
        <li class="notification" > 
            <div class="figure">
                   <?php print l($img_tag, $uname_url, array('attributes' => array('target'=>'_blank'), 'html' => TRUE )); ?>
             </div>
             <div class="info">
             <h5> <?php echo $sender_nick_name .' uploaded a folder'; ?> <?php  print l($row->title ,'knowledge-repository/folder/'.$row->entity_id,array( 'attributes' => array('title' => 'new reply on query','class' => array('') ))); ?></h5>
             <small><?php echo time_elapsed_string(format_date($row->created)); ?></small>
             </div>
        </li>
        
        <?php 
        break;
        case 'KM_UPLOAD_RIGHT':
            $file_array = get_filedepot_folder_from_cid($row->entity_id);
        ?>
        <li class="notification" > 
            <div class="figure">
                   <?php print l($img_tag, $uname_url, array('attributes' => array('target'=>'_blank'), 'html' => TRUE )); ?>
             </div>
             <div class="info">
             <h5> <?php echo $sender_nick_name .' provide right to upload folder'; ?> <?php  print l($file_array['name'] ,'knowledge-repository/folder/'.$row->entity_id,array( 'attributes' => array('title' => 'new reply on query','class' => array('') ))); ?></h5>
             <small><?php echo time_elapsed_string(format_date($row->created)); ?></small>
             </div>
        </li>
        
        <?php 
        break;
        case 'KM_FIRST_APPROVER':
        ?>
        <li class="notification" > 
            <div class="figure">
                   <?php print l($img_tag, $uname_url, array('attributes' => array('target'=>'_blank'), 'html' => TRUE )); ?>
             </div>
             <div class="info">
             <h5> <?php echo $sender_nick_name .'  Made you 1st level approval of knowladge repository'; ?> </h5>
             <small><?php echo time_elapsed_string(format_date($row->created)); ?></small>
             </div>
        </li>
        
        <?php 
        break;
        case 'KM_SECOND_APPROVER':
        ?>
        <li class="notification" > 
            <div class="figure">
                   <?php print l($img_tag, $uname_url, array('attributes' => array('target'=>'_blank'), 'html' => TRUE )); ?>
             </div>
             <div class="info">
             <h5><?php echo $sender_nick_name .' made you 2nd level approval of knowladge repository'; ?> </h5>
             <small><?php echo time_elapsed_string(format_date($row->created)); ?></small>
             </div>
        </li>
                          
        <?php 
        break;
        ?>
<?php  }
 endforeach;
?>
</ul>