(function ($) {
Drupal.behaviors.autocomplete_entity_ref_km_community = {
attach: function (context, settings) {
	community_user = $(".add-community-user #edit-name").val();
    var closeIcon = '<i class="fa fa-times-circle" title="Remove" aria-hidden="true"></i>';

    // Initialize the function
    $(".add-community-user #edit-name").on('autocompleteSelect', function(){
        var key = "edit-name";
        var item = $(this).val();
        if(item != "") {
          addItem_new(item, key);
        }
    });
    
 // Append Items On Window load
    var key = "edit-name";
    var items = $("#"+ key);
    onLoadItems_new(items, key);
    removeItem_new(key);
    
 // Submit Form
    $('form').on('submit', function () {
        var key = "edit-name";
        submitForm_new(key);
    });
    
    
    // Add Item
    function addItem_new(item, key){
          
        var inputWidth = $("#"+key).parent(".input-group").width();
        var parentWidth = $("#"+key).parent(".input-group").parent().width();
        var labelWidth = $("#"+key).parent(".input-group").prev().outerWidth();
        var inputPercent = ((inputWidth) / parentWidth) * 100;
        var labelPercent = ((labelWidth) / parentWidth) * 100;

        var fullString = item;
		//console.log(key);
        var userFullName = item.replace(/ *\([^)]*\) */g, "");
       
        var splitString = item.split('(');
        var userName = splitString[2].slice(0, -2);
        var userEmail = splitString[1].slice(0, -2);
        var userId = splitString[3].slice(0,-1);
        console.log(splitString[3]);
        $("#a_e_r_p_og_user").append('<div class="ac-item"><a href="'+ Drupal.settings.basePath +"profile/" + userName +'" target="_blank" title="'+ $.trim(userEmail) +'">'+ "<span class=\"name\">" + userFullName + "</span><span class=\"hidden\">"+ fullString +'</span></a>' + closeIcon +'</div>').css({
            "width":Math.round(inputPercent)+"%",
            "float":"right"
        });
        removeItem_new(key);
        $(".add-community-user #edit-name").val("");
    }   

    // On Load item
    function onLoadItems_new(items, key){
        var inputWidth = $("#"+key).parent(".input-group").width();
        var parentWidth = $("#"+key).parent(".input-group").parent().width();
        var labelWidth = $("#"+key).parent(".input-group").prev().outerWidth();
        var inputPercent = ((inputWidth) / parentWidth) * 100;
        var labelPercent = ((labelWidth) / parentWidth) * 100;
        
        if(typeof $("#"+key).val() !== "undefined" && $("#"+key).val() != ''){
            var splitValue = members_field_new.split(",");
          

            var html = "";
            for (var i = 0; i < splitValue.length; i++){
                var fullString = splitValue[i];
                var userFullName = splitValue[i].replace(/ *\([^)]*\) */g, "");
                var splitString = splitValue[i].split('(');
                var userName = splitString[2].slice(0, -2);
                var userEmail = splitString[1].slice(0, -2);
                html += '<div class="ac-item"><a href="'+ Drupal.settings.basePath +"profile/" + userName +'" target="_blank" title="'+ $.trim(userEmail) +'">'+ "<span class=\"name\">" + userFullName + "</span><span class=\"hidden\">"+ fullString +'</span></a>' + closeIcon +'</div>';
            }
            $("#a_e_r_p_og_user").append(html).css({
                "width":Math.round(inputPercent)+"%",
                "float":"right"
            });
             $(".add-community-user #edit-name").val("");
            //items.val("");
        }
    }

    // Remove Item
    function removeItem_new(key) {
        $("#a_e_r_p_og_user .ac-item .fa").on("click", function(){
            $(this).parent().remove();
        });
    }

    //Submit Form function
    function submitForm_new(key){
        var string = '';
        $("#a_e_r_p_og_user .ac-item").each(function(){
            string += $(this).find(".hidden").text() + ', ';
        });
        var result = string.substring(0, string.length-2); 
        $("#"+key).val(result).css({
            //'color':'transparent'
        });
    }

    // Initialize the function
  /*  $(".add-community-user #edit-name").on('autocompleteSelect', function(){
        var key = "edit-name";
        var item = $(this).val();


     if(item != "") {
          addItem_new(item, key);
     }
    

    });*/
    // Append Items On Window load
   /* var key = "edit-name";
    var items = $("#"+ key);
    onLoadItems_new(items, key);
    removeItem_new(key); */

    // Submit Form
   /* $('form').on('submit', function () {
        var key = "edit-name";
        submitForm_new(key);
    }); */
        
}
};
}(jQuery));
