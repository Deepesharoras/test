<?php
/**
 * @file
 * Template for render complaints on comment.
 */
?>
<!---div class="comment-wrapper">
<h2><?php print t('Comment'); ?></h2>
<fieldset class="form-wrapper" id="edit-options">
  <div class="fieldset-wrapper">
    <?php // print $comment;  ?>
  </div>
</fieldset>
</div-->

<!-- <h2></h2> -->

<div class="table-data">
<div class="view-content">
<!--div class="table-heading"><?php print t('Complaints'); ?></div-->
<div class="table-wrapper">
<?php print $complaints; ?>
</div>
</div>
</div>

<style>
    .comment-by-node-author img {
        border-radius :10px;
        width: 45px;
        height:45px;
    }
</style>