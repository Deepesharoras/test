<?php

/**
 * @file
 * Template for complaint on comment popup.
 */
?>

<?php print $form; ?>
