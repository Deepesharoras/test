

(function($){
  setInterval(function() {
    if ($('#modal-content').html() != null) {
      $('#report-abuse, #modal-content').css('height', 'auto')
    }
    $('#modalBackdrop').on('click', function() {
      Drupal.CTools.Modal.dismiss();
    });
  }, 1000);
})(jQuery)

/**
 * Provide the HTML to create the modal dialog.
 */
Drupal.theme.prototype.CommentAbuse = function () {
  var html = '';

  html += '<div id="report-abuse" class="modal fade" role="dialog">';
  html += '  <div class="modal-dialog">';
  html += '    <div class="modal-content">';
  html += '          <div class="popups-container">';
  html += '            <div class="modal-header popups-title">';
  html += '              <button type="button" class="close" data-dismiss="modal" aria-label="Close">';
  html += '                 <span aria-hidden="true">×</span>';
  html += '              </button>';
  html += '              <h4 id="modal-title" class="modal-title"></h4>';
  html += '              <div class="clear-block"></div>';
  html += '            </div>';
  html += '            <div class="modal-scroll"><div id="modal-content" class="modal-body"></div></div>';
  html += '          </div>';
  html += '    </div>';
  html += '  </div>';
  html += '</div>';

  return html;

}
