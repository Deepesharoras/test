<?php
/**
* @file this page  is for task action block tpl file.
*/


// display($node_obj->pm_status[LANGUAGE_NONE][0]['value']);


$query = array(
  'tok' => drupal_get_token('delete_log_item' . $node_obj->nid),
) + drupal_get_destination();

/// print l(t('Start '), 'pm/task/action/'. $flid, array('query' => $query));

$project_status = $node_obj->pmtask_parent[LANGUAGE_NONE][0]['entity']->pm_projectstatus[LANGUAGE_NONE][0]['value'];

if($project_status != 'completed'){
?>

<div id="task_action_section_block">


 <?php 
    $staus_value  = $node_obj->pm_status[LANGUAGE_NONE][0]['value'];
    if($staus_value == 'completed') {
        print l(t('Reopen'), 'pm/task/action/nojs/' . $node_obj->nid, array('attributes' => array('class' => 'use-ajax btn btn-default'), 'query' => $query + array('status' => 'new')));
    }
    
    if($staus_value ==  'new'
     || $staus_value == 'on hold'
    ){
        print l(t('Start'), 'pm/task/action/nojs/' . $node_obj->nid, array('attributes' => array('class' => 'use-ajax btn btn-primary'), 'query' => $query + array('status' => 'in_progress')));
    }
    
    if(!in_array($staus_value, array('on hold','completed'))) {
        print l(t('Hold'), 'pm/task/action/nojs/' . $node_obj->nid, array('attributes' => array('class' => 'use-ajax btn btn-warning'), 'query' => $query + array('status' => 'on_hold')));
    }
    
    if($staus_value ==  'in progress'){
        print l(t('Completed'), 'pm/task/action/nojs/' . $node_obj->nid, array('attributes' => array('class' => 'use-ajax btn btn-success'), 'query' => $query + array('status' => 'completed')));
    }
?>
</div>

<?php 
// display($team_member);
?>

<div id="magical-modal-link"> <?php print  l('Assign to', 'km-pm-task-change-assign/nojs/'.$node_obj->nid, array('attributes' => array('class' => 'use-ajax ctools-modal-assign-modal-style btn btn-info'))) ?></div>


<!--
<div class="dropdown">
  <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Assign to
  <span class="caret"></span></button>
  <ul class="dropdown-menu">
  <?php //  foreach($team_member as $id => $name){ ?>
    <li><a href="#"><?php // print $name ?></a></li>
  <?php // } ?>
     <li><a href="#">CSS</a></li>
    <li><a href="#">JavaScript</a></li> 
  </ul>
</div>-->

<?php } ?>

