<?php

 
 // display($node_obj);

// print drupal_render(node_view($node_obj));

if($node_obj->type=='pmproject') {

 $nodeView = node_view($node_obj, 'teaser');

  // display($nodeView['pm_manager']);
  // die();
$textttodisplay = '';
/**
 *  Project manager 
 */
if(isset($nodeView['pm_manager']['#object']->pm_manager) && !empty($nodeView['pm_manager']['#object']->pm_manager) )
{
    foreach ($nodeView['pm_manager']['#object']->pm_manager[LANGUAGE_NONE]  as $user_obj)
    {
        $name_user = $user_obj['entity']->field_first_name[LANGUAGE_NONE][0]['value'].' '.$user_obj['entity']->field_last_name[LANGUAGE_NONE][0]['value'];
        
          $textttodisplay =  l($name_user,'profile/'.$user_obj['entity']->name,array('attributes' => array('target' => '_blank'))) ;
        
         
    }
}

$nodeView['pm_manager'][0] = array( '#markup' => $textttodisplay );

?>


<div class="padding-bottom-5"> <?php print drupal_render($nodeView['pm_manager']); ?></div>



<div class="padding-bottom-5"> <?php print drupal_render($nodeView['pm_date']); ?></div>


<?php 

    // display($nodeView['field_pm_projectcategory']);
    // die();

?>

<?php if(isset($nodeView['field_pm_projectcategory'])) { ?>
    <div class="padding-bottom-5"> <?php print drupal_render($nodeView['field_pm_projectcategory']); ?></div>
<?php }else { ?>
    <div class="padding-bottom-5"> 
        <div class="field field-name-field-pm-projects-category field-type-entityreference field-label-above">
            <div class="field-label">Category: &nbsp;</div>
            <div class="field-items">
                <div class="field-item even"> NA </div>
            </div>
        </div>
   </div>   
<?php } ?>


<div class="padding-bottom-5"> <?php print drupal_render($nodeView['field_pm_projects_team']); ?></div>


<div class="padding-bottom-5"> <?php print drupal_render($nodeView['pm_projectstatus']); ?></div>

<div class="padding-bottom-5"> <?php print drupal_render($nodeView['pm_projectpriority']); ?></div>


<?php if(isset($nodeView['field_actual_completion_date'])) { ?>
    <div class="padding-bottom-5"> <?php print drupal_render($nodeView['field_actual_completion_date']); ?></div>
<?php }else { ?>
    <div class="padding-bottom-5"> 
        <div class="field field-name-field-pm-projects-category field-type-entityreference field-label-above">
            <div class="field-label">Category: &nbsp;</div>
            <div class="field-items">
                <div class="field-item even"> NA </div>
            </div>
        </div>
   </div>   
<?php } ?>








<div class="padding-bottom-5">
    <div class="field field-name-field-pm-projects-category field-type-entityreference field-label-above">
        <div class="field-label">Description: &nbsp;</div><div class="field-items">
            <div class="field-items">
            <div class='bodyreadmore'>
                <?php     
                    print  strip_tags($nodeView['body']['#object']->body[LANGUAGE_NONE][0]['safe_value']);
                  // print drupal_render($nodeView['body']); 
                  ?>
            </div>
            </div>
          </div>
        </div>
</div>
 
 
 
 
 
 
 
 
 

<?php
//print drupal_render($nodeView['field_pm_projectcategory']);

//print drupal_render($nodeView['field_pm_projectcategory']);

}

?>