<?php
/**
* @file this blog is for Task action start and end File.
*/

// display($node_obj->pm_status[LANGUAGE_NONE][0]['value']);

$query = array(
  'tok' => drupal_get_token('delete_log_item' . $node_obj->nid),
) + drupal_get_destination();

/// print l(t('Start '), 'pm/task/action/'. $flid, array('query' => $query));

?>

<div id="task_action_section_block">

<?php $staus_value = $node_obj->pm_status[LANGUAGE_NONE][0]['value'] ;?>
<?php
    if($staus_value == 'completed') {
        print l(t('Reopen'), 'pm/task/action/nojs/' . $node_obj->nid, array('attributes' => array('class' => 'use-ajax btn btn-default'), 'query' => $query + array('status' => 'new')));
    }
    if($staus_value ==  'new'|| $staus_value == 'on hold'){
        print l(t('Start'), 'pm/task/action/nojs/' . $node_obj->nid, array('attributes' => array('class' => 'use-ajax btn btn-primary'), 'query' => $query + array('status' => 'in_progress')));
    }
    
    if(!in_array($staus_value, array('on hold','completed'))) {
        print l(t('Hold'), 'pm/task/action/nojs/' . $node_obj->nid, array('attributes' => array('class' => 'use-ajax btn btn-warning'), 'query' => $query + array('status' => 'on_hold')));
    }

    if($staus_value ==  'in progress'){
        print l(t('Completed'), 'pm/task/action/nojs/' . $node_obj->nid, array('attributes' => array('class' => 'use-ajax btn btn-success'), 'query' => $query + array('status' => 'completed')));
    
    }
?>

</div>




