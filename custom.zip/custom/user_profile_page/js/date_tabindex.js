/*
 * setting tabindex of profile2 field collection date fields in user register form
 * */
(function ($) {
    Drupal.behaviors.user_profile_field_coll_date = {
        attach: function (context, settings) {
           //$("#edit-profile-experience-field-experience-info-und-0-field-exp-info-duration-und-0-value-datepicker-popup-0").attr('tabindex',3);
           //$("#edit-profile-experience-field-experience-info-und-0-field-exp-info-duration-und-0-value2-datepicker-popup-0").attr('tabindex',5);

           //$("input[id*='edit-profile-basic-information-field-pro-basic-contact-num-und-0-mobile']").attr('tabindex',7);
           //$("input[id*='edit-profile-basic-information-field-pro-basic-info-report-mgr-und']").attr('tabindex',8);
           //$("select[id*='edit-profile-basic-information-field-pro-basic-address-und']").attr('tabindex',9);
        }
    };
}(jQuery));