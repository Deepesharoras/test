/*
 * removing zero from contact number field in basic information profile
 * */
(function ($) {
    Drupal.behaviors.remove_zero = {
        attach: function (context, settings) {
            if($('body').hasClass("logged-in")){
                var contact =  $("input[id*='edit-profile-basic-information-field-pro-basic-contact-num-und-0-mobile']").val();
            	var zero_char = contact.charAt(0);
            	if(zero_char == '0'){
            	  var trim_contact = contact.slice(1);
            	  $("input[id*='edit-profile-basic-information-field-pro-basic-contact-num-und-0-mobile']").val(trim_contact);
                }
            }
        }
    };
}(jQuery));
