/*
 * setting tabindex of profile2 field collection date fields in user register form
 * */
(function ($) {
    Drupal.behaviors.user_basic_info_tab = {
        attach: function (context, settings) {
            $("input[id*='edit-profile-basic-information-field-pro-basic-contact-num-und-0-mobile']").attr('tabindex',4);
        }
    };
}(jQuery));