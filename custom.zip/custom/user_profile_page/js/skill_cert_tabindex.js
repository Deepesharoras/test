/*
 * setting tabindex of skill and level of expertise profile2 field collection fields
 * */
(function ($) {
    Drupal.behaviors.skill_cert_tabindex = {
        attach: function (context, settings) {
          for(i = 0; i < $( "input[id$='-field-pro-skill-exp-skill-und']").length; i++) { 
        	    var j = i*2+1;
        		$("input[id$='"+i+"-field-pro-skill-exp-skill-und']").attr('tabindex',j);
          }
        }
    };
}(jQuery));

(function ($) {
    Drupal.behaviors.level_cert_tabindex = {
        attach: function (context, settings) {
          for(i = 0; i < $( "select[id$='-field-pro-skill-exp-lvl-of-exp-und']").length; i++) { 
        	    var j = (i+1)*2;
        		$("select[id$='"+i+"-field-pro-skill-exp-lvl-of-exp-und']").attr('tabindex',j);
          }
        }
    };
}(jQuery));
        	