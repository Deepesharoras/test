/*
 * setting tabindex of profile2 fields in user register form
 * */
(function ($) {
    Drupal.behaviors.user_account_page = {
        attach: function (context, settings) {
             CKEDITOR.config.tabIndex = 1; 

        }
    };
}(jQuery));