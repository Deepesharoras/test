/*
 * setting tabindex of mobile number field in user register form
 * */
(function ($) {
    Drupal.behaviors.user_bi_admin = {
        attach: function (context, settings) {
            $("input[id*='edit-profile-basic-information-field-pro-basic-contact-num-und-0-mobile']").attr('tabindex',7);
        }
    };
}(jQuery));