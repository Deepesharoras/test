/*
 * setting tabindex of profile2 fields in user register form
 * */
(function ($) {
    Drupal.behaviors.user_profile_page = {
        attach: function (context, settings) {
             CKEDITOR.config.tabIndex = 9; 

        }
    };
}(jQuery));