<?php
/**
 * @file
 * Template file for pm-list-default.
 */
?>
<div class="pm-list-default-wrapper pm-list-field-name-<?php echo $field_name ?>">
  <?php echo pm_helper_get_fa_icon($key); ?>&nbsp;<span class="value"><?php echo $value; ?></span>
</div>
