 <?php
     global $user, $base_url;
     $user_first_name = $user_info->field_first_name[LANGUAGE_NONE][0]['value'];
     if(isset($user_info->field_middle_name[LANGUAGE_NONE][0]['value'])){
         $user_middle_name =$user_info->field_middle_name[LANGUAGE_NONE][0]['value'];
     }
     $user_last_name = $user_info->field_last_name[LANGUAGE_NONE][0]['value'];
     
     $job_title = $user_info->field_job[LANGUAGE_NONE][0]['value'];
     $creation_date = $user_info->created;
     $img_data = field_view_field('user', $user_info, 'field_user_image');
     if(isset($user_info->field_user_image[LANGUAGE_NONE][0]['uri'])){
         $img_url = $user_info->field_user_image[LANGUAGE_NONE][0]['uri'];
     }else{
         $img_url = $img_data[0]['#item']['uri'];;
     }




 ?>
 <ul class='topbar'>
 <li class='dropdown notifications-menu'>
    <a href='javascript:void(0)' class='dropdown-toggle alertread' data-toggle='dropdown' title='Alert'><i class='fa fa-exclamation-triangle' aria-hidden='true'></i>
    <?php if($num_of_alert_count) : ?>
        <span class='label label-danger lbl-al-km' id='alertread' ><?php echo $num_of_alert_count; ?></span>
     <?php endif;?>
    </a>
    
    <ul class="dropdown-menu">
        <!-- <li class="header refresh-nt-km">You have <span class="nt_count_rp"><?php // echo $num_of_count; ?></span> new notifications</li>  -->
       
        <!--  start notification html file -->
            <li>  
            <ul class='menu'>
                
                <?php 
                
                // var_dump($tp_alert_data);
                
                if(!empty($tp_alert_data)) {
                
                foreach($tp_alert_data  as $row) : 
                    $sender_name = $row->field_first_name_value ." ".$row->field_last_name_value;
                    $sender_nick_name =  ($user->uid ==  $row->sender_id) ?  ' You ' : $sender_name ;
                    
                    if($sender_nick_name == 'You'){
                        $sender_nick_name = l('You','my-profile',array('attributes' => array('target' => '_blank')));
                    } else {
                        $sender_nick_name = l($sender_nick_name,'profile/'.$row->name,array('attributes' => array('target' => '_blank')));
                    }
                    
                    
                    /* if($row->uri !=''){
                       $img_uri = $row->uri;
                    }else{
                        $img_uri = "public://default_images/default_user_img.png";
                    }
                    $style_url = image_style_url('simplecrop', $img_uri); */
                    
                    $style_url = get_profile_img($row->uri);
                    
                    // motify title upto 20 charactor
                    $md_title =  substr($row->title , 0, 20) . '...';
                    
                    switch($row->nt_type){
                        case 'FREIND_REQUEST':
                    ?>
                            <li> 
                                <div class="pull-left">
                                    <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name; ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name ?>'> </a>                                   
                                </div> 
                                <div class="overflow-h">
                                    <h4><?php  echo  $sender_nick_name;?> <?php print l(' sent you a contact request ' ,'mynetwork',array('query' => array('qt-all_contacts'=> 3),'attributes' => array('title' => 'friend request','class' => array('')))); ?></h4>
                                    <small><?php echo time_elapsed_string(format_date($row->created)); ?></small>
                                </div>
                            </li>
                     <?php 
                       break;
                       case 'LESSON_SAVE_DRAFT_REMIND':
                    ?>
                            <li> 
                                <div class="pull-left">
                                    <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name; ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name ?>'> </a>                                   
                                </div> 
                                <div class="overflow-h">
                                    <h4>
                                        <?php echo 'Your lesson titled '; ?> <?php  print l($md_title ,'node/'.$row->entity_id ,array( 'attributes' => array('title' => '','class' => array('') )));  echo " has been saved as draft for 7 days. Click here to publish the lesson."; ?>
                                     </h4>
                                    <small><?php echo time_elapsed_string(format_date($row->created)); ?></small>
                                </div>
                            </li>
                     <?php 
                       break;
                       case 'COMMUNITY_REQUEST':
                                 ?>
                             <li> 
                                 <div class="pull-left">
                                    <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" ><img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt=''>
                                 </div> 
                                 <div class="overflow-h"><h4><?php echo $sender_nick_name .' has requested you to join community titled'; ?> <?php  print l($md_title ,'node/'.$row->entity_id ,array( 'attributes' => array('title' => 'community request','class' => array('') ))); ?></h4>
                                 <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                             </li>       
                             <?php 
                       break;
                       case 'KM_FILE_UPLOAD_FOR_APPOVAL':
                            // $folder_array = get_filedepot_folder_from_nid($row->entity_id);
                           ?>
                          <li> 
                              <div class="pull-left">
                                     <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                               </div>
                               <div class="overflow-h"><h4><?php echo $sender_nick_name .' sent you new file for approval '; ?> <?php  print l( 'click here' ,'knowledge-repository/',array( 'attributes' => array('title' => 'Repository','class' => array('') ))); ?></h4>
                               <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                          </li>
                          <?php 
                           break;
                                          
                       case 'QUERY_CREATE':
                          $string = strip_tags($sender_nick_name);
                          $string_trimmed = str_replace(' ', '', $string);
                            if($string_trimmed == 'You') {
                        ?>
                         <li> 
                                <div class="pull-left">
                                    <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                                </div>
                                <?php
                                        //You have been marked as an expert by <<QueryRaiser name>> for the query titled<<query title>>
                                ?>
                                 <div class="overflow-h"><h4>Your query titled <?php  print l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'new query','class' => array('') ))); ?> has been posted.</h4>
                                 <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                          </li>

                         <?php

                            } else {
                                ?>
                                <li> 
                        <div class="pull-left">
                            <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                        </div>
                        <?php
                                //You have been marked as an expert by <<QueryRaiser name>> for the query titled<<query title>>
                        ?>
                         <div class="overflow-h"><h4>You have been marked as an expert by  <?php echo $sender_nick_name .' for the query titled '; ?> <?php  print l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'new query','class' => array('') ))); ?></h4>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                          </li>
                        <?php

                            }
                        ?> 
                    <?php 
                        break;
                       case 'LESSON_SAVE_DRAFT':
                    ?>
                    <li> 
                        <div class="pull-left">
                            <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                        </div>
                         <div class="overflow-h"><h4> <?php echo 'You have saved your lesson titled '; ?> <?php print l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => ' new lesson ','class' => array('')))); ?> in draft.
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                    <?php 
                        break;
                        case 'POST_APPROVAL_REQUIRED'   
                    ?>
                            <?php 
                                // find blog title
                               $blog_object = get_blog_title_from_post_nid($row->entity_id);    
                                // display($blog_object); die();
                               $node_path = drupal_get_path_alias('node/' . $blog_object->nid);
                               $path_arg =  explode('/', $node_path); 
                            ?>
                        <li> 
                            <div class="pull-left">
                                <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                            </div>
                            <div class="overflow-h"> <h4> <?php echo $sender_nick_name .' created a post title '; ?>  <?php print l($md_title,'node/'.$row->entity_id.'/edit',array( 'attributes' => array('title' => 'new post','class' => array('')))); ?>  
                                over blog title <?php print l($blog_object->title,'post-require-approval/'.$path_arg[1],array( 'attributes' => array('title' => 'new post','class' => array('')))); ?>  and need your approval.
                                </h4>
                             <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                        </li>             
                  <?php
                    break;
                 
                   }
                 endforeach;
                }else{
                    echo '<li> You have no new Alerts .</li>';
                }
                ?>
                </ul>
                </li>
        <!--  end notification html  -->
    <li>
   </li> 
   </ul> 
   </li>

   
   <?php 
       /** End Alter here display alert html is above this point.
        * 
        * Start notification section here to display notification
        * 
        */
    ?>  
<!--two start-->
<li class='dropdown notifications-menu'>
    <a href='javascript:void(0)' class='dropdown-toggle ntread' data-toggle='dropdown' title='Notification'><i class='fa fa-bell-o' aria-hidden='true'></i>
    <?php if($num_of_count) : ?>
        <span class='label label-danger lbl-nt-km' id='ntread' ><?php echo $num_of_count; ?></span>
     <?php endif;?>
    </a> 
    <ul class="dropdown-menu">
        <!-- <li class="header refresh-nt-km">You have <span class="nt_count_rp"><?php // echo $num_of_count; ?></span> new notifications</li>  -->
        <!--  start notification html file -->
            <li>  
            <ul class='menu'>
                
                <?php 
                // var_dump($tp_notificaion_data);
                if(!empty($tp_notificaion_data)) {
                
                foreach($tp_notificaion_data  as $row) : 
                    $sender_name = $row->field_first_name_value ." ".$row->field_last_name_value;
                    $sender_nick_name =  ($user->uid ==  $row->sender_id) ?  ' You ' : $sender_name ;
                    
                    if($sender_nick_name == 'You'){
                        $sender_nick_name = l('You','my-profile',array('attributes' => array('target' => '_blank')));
                    } else {
                        $sender_nick_name = l($sender_nick_name,'profile/'.$row->name,array('attributes' => array('target' => '_blank')));
                    }
                    
                    
                    /* if($row->uri !=''){
                       $img_uri = $row->uri;
                    }else{
                        $img_uri = "public://default_images/default_user_img.png";
                    }
                    $style_url = image_style_url('simplecrop', $img_uri); */
                    
                    $style_url = get_profile_img($row->uri);
                    // motify title upto 20 charactor
                    $md_title =  substr($row->title , 0, 20) . '...';
                    
                    switch($row->nt_type){
                        case 'QUERY_UPDATED':
                    ?>
                    <?php 
                       $string = strip_tags($sender_nick_name);
                       $string_trimmed = str_replace(' ', '', $string);
                       if($string_trimmed == 'You') {
                     ?>
                            <li> 
                                <div class="pull-left">
                                    <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                                </div>
                                 <div class="overflow-h"><h4><?php echo 'Your query titled '; ?> <?php  print l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'new query','class' => array('') ))); ?> has been updated </h4>
                                 <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                             </li>
                        <?php }  ?> 
                    <?php 
                        break;
                        case 'QUERY_CREATE_NEW':
                          $string = strip_tags($sender_nick_name);
                          $string_trimmed = str_replace(' ', '', $string);
                            if($string_trimmed == 'You') {
                        ?>
                         <li> 
                                <div class="pull-left">
                                    <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                                </div>
                                <?php
                                        //You have been marked as an expert by <<QueryRaiser name>> for the query titled<<query title>>
                                ?>
                                 <div class="overflow-h"><h4>Your query titled <?php  print l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'new query','class' => array('') ))); ?> has been posted.</h4>
                                 <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                          </li>

                         <?php

                            } else {
                                ?>
                                <li> 
                        <div class="pull-left">
                            <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                        </div>
                        <?php
                                //You have been marked as an expert by <<QueryRaiser name>> for the query titled<<query title>>
                        ?>
                         <div class="overflow-h"><h4>You have been marked as an expert by  <?php echo $sender_nick_name .' for the query titled '; ?> <?php  print l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'new query','class' => array('') ))); ?></h4>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                          </li>
                        <?php

                            }
                        ?> 
                    <?php 
                        break;                        
                        case 'FREIND_APPROVE':
                    ?>
                            <li> 
                                <div class="pull-left">
                                    <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name ?>'> </a>
                                    
                                    
                                </div> 
                                <div class="overflow-h">
                                    <h4><?php  echo  $sender_nick_name; ?>  <?php print l(' accepted your contact request ' ,'mynetwork',array('query' => array('qt-all_contacts'=> 0),'attributes' => array('title' => 'friend request','class' => array('')))); ?></h4>
                                    <small><?php echo time_elapsed_string(format_date($row->created)); ?></small>
                                </div>
                            </li>       
                     <?php 
                        break; 
                        case 'BIRTHDAY_WISHES':

                        $nid = $row->entity_id;
                        $nodeInfo = node_load($nid);
                        if(isset($nodeInfo->body['und'][0]['value'])) {
                        $bodytext = $nodeInfo->body['und'][0]['value'];
                    } else {
                        $bodytext = "";
                    }


                          $otheraray =  !empty($row->other_val) ? json_decode($row->other_val) : NULL;
                         
                           if(isset($otheraray->birthday_message)) {
                            $b_message = $otheraray->birthday_message;
                           }else {
                             $b_message = "";
                           }

                           
                    ?>
                            <li> 
                                <div class="pull-left">
                                    <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name ?>'> </a>
                                    
                                    
                                </div> 
                                <div class="overflow-h">
                                    <h4><?php  echo  $sender_nick_name; ?>  <?php print ' has sent you birthday wishes '.$b_message; ?></h4>
                                    <small><?php echo time_elapsed_string(format_date($row->created)); ?></small>
                                </div>
                            </li>       
                     <?php 
                        break; 
                        case 'TOPIC_CREATE':
                    ?>
                    
                    <li> 
                        <div class="pull-left">
                           <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo  $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name ?>'> </a>
                        </div> 
                        <div class="overflow-h">
                            <h4>  <?php echo $sender_nick_name;  ?> created a new topic <?php print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'topic','class' => array('')))); ?></h4>
                            <small><?php echo time_elapsed_string(format_date($row->created)); ?></small>
                        </div>
                    </li>
                    
                    <?php 
                        break; 
                        case 'LIKE_ON_TOPIC':
                    ?>
                    <li> 
                        <div class="pull-left">
                           <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name ?>'> </a>
                        
                        </div>
                       <div class="overflow-h"> <h4> <?php echo $sender_nick_name .' likes topic '; ?><?php print  l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'followed  post','class' => array('')))); ?></h4>
                        <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                    
                    <?php 
                        break; 
                        case 'FOLLOW_TOPIC':
                    ?>
                    
                    <li> 
                        <div class="pull-left">
                           <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                        </div>
                        <div class="overflow-h">
                        <h4> <?php echo $sender_nick_name .' followed topic '; ?> <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'followed topic','class' => array('')))); ?></h4>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div> 
                    </li>
                    
                    <?php 
                        break;
                        case 'TOPIC_COMMENT_AUTHOR_ABUSE_NOTIFY':
                         $img_uri1 = "public://default_images/default_user_img.png";
                                            
                         $style_url_default = image_style_url('simplecrop', $img_uri1); 
                        ?>
                            <li> 
                            <div class="pull-left">
                                 <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url_default ?>' alt=''> 
                            </div>
                            <!-- no nee of user image -->
                            <div class="overflow-h">
                            <h4> Your reply over the topic titled <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'Report abuse','class' => array('')))); ?> has been marked report as abuse  </h4>
                             <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div> 
                        </li>
                    
                    <?php 
                        break;
                        case 'TOPIC_COMMENT_ABUSE_NOTIFY':
                         $img_uri1 = "public://default_images/default_user_img.png";
                                            
                         $style_url_default = image_style_url('simplecrop', $img_uri1); 
                        ?>
                            <li> 
                            <div class="pull-left">
                                 <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url_default ?>' alt=''> 
                            </div>
                            <!-- no nee of user image -->
                            <div class="overflow-h">
                            <h4>A Reply over the topic titled <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'Report abuse','class' => array('')))); ?> has been marked report as abuse  </h4>
                             <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div> 
                        </li>
                            
                    <?php 
                        break;
                        case 'TOPIC_COMMENT_AUTHOR_REFUSE_ABUSE_NOTIFY':
                         $img_uri1 = "public://default_images/default_user_img.png";
                                            
                         $style_url_default = image_style_url('simplecrop', $img_uri1); 
                        ?>
                            <li> 
                            <div class="pull-left">
                                 <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url_default ?>' alt=''> 
                            </div>
                                <!-- no nee of user image -->
                                <div class="overflow-h">
                                <h4>Your 
                                <?php  print l('comment','node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?> which was reported abuse on topic titled <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?> is resumed by customer admin </h4>
                                 <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div> 
                            </li>
                        
                    <?php 
                        break;
                        case 'TOPIC_COMMENT_REFUSE_ABUSE_NOTIFY':
                         $img_uri1 = "public://default_images/default_user_img.png";
                                            
                         $style_url_default = image_style_url('simplecrop', $img_uri1); 
                        ?>
                            <li> 
                            <div class="pull-left">
                                 <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url_default ?>' alt=''> 
                            </div>
                                <!-- no nee of user image -->
                                <div class="overflow-h">
                                <h4>A reported abuse 
                                <?php  print l('comment','node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?> on your  topic titled <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?> is resumed by customer admin </h4>
                                 <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div> 
                            </li>
                        
                    <?php 
                        break;
                        case 'TOPIC_REPORTER_REFUSE_ABUSE_NOTIFY':
                         $img_uri1 = "public://default_images/default_user_img.png";
                                            
                         $style_url_default = image_style_url('simplecrop', $img_uri1); 
                        ?>
                            <li> 
                            <div class="pull-left">
                                 <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url_default ?>' alt=''> 
                            </div>
                                <!-- no nee of user image -->
                                <div class="overflow-h">
                                <h4>A reported abuse request by you on a
                                <?php  print l('comment','node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?> on <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?> is declined by customer admin. </h4>
                                 <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div> 
                            </li>
                    <?php 
                        break;
                        break;case 'TOPIC_COMMENT_ACCEPT_ABUSE_NOTIFY':
                         $img_uri1 = "public://default_images/default_user_img.png";
                                            
                         $style_url_default = image_style_url('simplecrop', $img_uri1); 
                        ?>
                            <li> 
                            <div class="pull-left">
                                 <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url_default ?>' alt=''> 
                            </div>
                                <!-- no nee of user image -->
                                <div class="overflow-h">
                                <h4>A reported abuse comment on your topic titled
                                 <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?>  is deleted by customer admin. </h4>
                                 <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div> 
                            </li>
                    <?php 
                        break;
                        case 'TOPIC_COMMENT_AUTHOR_ACCEPT_ABUSE_NOTIFY':
                         $img_uri1 = "public://default_images/default_user_img.png";
                                            
                         $style_url_default = image_style_url('simplecrop', $img_uri1); 
                        ?>
                            <li> 
                            <div class="pull-left">
                                 <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url_default ?>' alt=''> 
                            </div>
                                <!-- no nee of user image -->
                                <div class="overflow-h">
                                <h4>Your comment which was reported abuse on topic titled
                                 <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?>  is deleted by customer admin. </h4>
                                 <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div> 
                            </li>
                    <?php 
                        break;
                        case 'TOPIC_REPORTER_ACCEPT_ABUSE_NOTIFY':
                         $img_uri1 = "public://default_images/default_user_img.png";
                                            
                         $style_url_default = image_style_url('simplecrop', $img_uri1); 
                        ?>
                            <li> 
                            <div class="pull-left">
                                 <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url_default ?>' alt=''> 
                            </div> 
                                <!-- no nee of user image -->
                                <div class="overflow-h">
                                <h4>A comment reported abuse by you on topic titled
                                 <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?>   is deleted by customer admin. </h4>
                                 <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div> 
                            </li>
                    <?php 
                        break;
                        case 'TOPIC_ABUSE_MARK_REPORTER_NOTIFY':
                         $img_uri1 = "public://default_images/default_user_img.png";
                                            
                         $style_url_default = image_style_url('simplecrop', $img_uri1); 
                        ?>
                            <li> 
                            <div class="pull-left">
                                 <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url_default ?>' alt=''> 
                            </div>
                                <!-- no nee of user image -->
                                <div class="overflow-h">
                                <h4>A comment is reported abuse by you on topic titled 
                                 <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?> . </h4>
                                 <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div> 
                            </li>
                    <?php 
                        break;
                        case 'FORUM_CREATE':
                    ?>
                    <li>  
                        <div class="pull-left">
                           <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                        </div> 
                        <div class="overflow-h">
                            <h4>  <?php echo $sender_nick_name ;  ?> created a new forum <?php print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'topic','class' => array('')))); ?></h4>
                            <small><?php echo time_elapsed_string(format_date($row->created)); ?></small>
                        </div>
                    </li> 
                    
                     <?php 
                        break; 
                        case 'LIKE_ON_FORUM':
                    ?>
                    <li> 
                        <div class="pull-left">
                            <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                        </div>
                       <div class="overflow-h"> <h4> <?php echo $sender_nick_name .' likes forum '; ?><?php print  l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'followed  post','class' => array('')))); ?></h4>
                        <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                                       
                    
                    <?php 
                        break; 
                        case 'FOLLOW_FORUM':
                    ?>
                     <li> 
                        <div class="pull-left">
                        
                            <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                        </div>
                         <div class="overflow-h"><h4> <?php echo $sender_nick_name.'  followed forum '; ?><?php print l($row->title,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'followed forum','class' => array('')))); ?></h4>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                     </li>
                     
                     <?php 
                        break; 
                        case 'TOPIC_NEW_COMMENT':
                    ?>
                    <li> 
                         <div class="pull-left">
                            <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                         </div>
                            <div class="overflow-h"> <h4> <?php echo $sender_nick_name.' commented on topic ' ; ?> <?php  print l($md_title ,'node/'.$row->entity_id,array('attributes' => array('title' => 'new comment on topic','class' => array('')))); ?></h4>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                     </li>
                     
                      <?php 
                        break; 
                        case 'BLOG_CREATE':
                    ?>
                    <li> 
                        <div class="pull-left">
                            <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                        </div>
                         <div class="overflow-h"><h4> <?php echo $sender_nick_name .' created a new blog '; ?> <?php  print l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'new blog','class' => array('')))); ?></h4>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                     </li>
                     
                     <?php 
                        break;
                        case 'BLOG_ADD_CO_OWNER':
                            ?>
                        <li> 
                            <div class="pull-left">
                                <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                            </div>
                             <div class="overflow-h"><h4> You have added <?php echo $sender_nick_name .' as an co-owner for the Blog Titled '; ?> <?php  print l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'new blog','class' => array('')))); ?></h4>
                             <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                         </li>
                         
                         <?php 
                            break;
                            case 'BLOG_ADD_EDITOR':
                                ?>
                                <li> 
                                    <div class="pull-left">
                                        <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                                    </div>
                                     <div class="overflow-h"><h4> You have added <?php echo $sender_nick_name .' as an editor for the blog titled'; ?> <?php  print l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'new blog','class' => array('')))); ?></h4>
                                     <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                                 </li>
                                 
                         <?php 
                            break;
                            case 'BLOG_BECOME_CO_OWNER':
                          ?>
                            <li> 
                                <div class="pull-left">
                                    <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                                </div>
                                 <div class="overflow-h"><h4> <?php echo $sender_nick_name ?> added you as a co-owner for the blog titled <?php  print l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'new blog','class' => array('')))); ?></h4>
                                 <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                             </li>
                                             
                     <?php 
                        break;
                        case 'BLOG_BECOME_EDITOR':
                      ?>
                        <li> 
                            <div class="pull-left">
                                <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                            </div>
                             <div class="overflow-h"><h4> <?php echo $sender_nick_name ?> added you as an editor for the blog titled <?php  print l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'new blog','class' => array('')))); ?></h4>
                             <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                         </li>
                                                                     
                     <?php 
                        break;
                        case 'LIKE_ON_BLOG':
                    ?>
                    <li> 
                        <div class="pull-left">
                            <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                        </div>
                       <div class="overflow-h"> <h4> <?php echo $sender_nick_name .' likes blog '; ?><?php print  l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'followed  post','class' => array('')))); ?></h4>
                        <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                     <?php 
                        break; 
                        case 'POST_CREATE':
                    ?>
                    <li> 
                        <div class="pull-left">
                            <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                        </div>
                        <div class="overflow-h"> <h4> <?php echo $sender_nick_name .' created a post '; ?> <?php print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'new post','class' => array('')))); ?></h4>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                    <?php 
                        break; 
                        case 'POST_NEW_COMMENT':
                    ?>
                    <li> 
                        <div class="pull-left">
                            <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                         </div>
                        <div class="overflow-h"> <h4> <?php echo $sender_nick_name.' replied to your comment in the post titled '; ?> <?php print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'a comment on post','class' => array('')))); ?></h4>
                        <small><?php  echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li> 
                    
                    <?php 
                        break; 
                        case 'FOLLOW_POST':
                    ?>
                    <li> 
                        <div class="pull-left">
                            <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                         </div>
                       <div class="overflow-h"> <h4><?php echo $sender_nick_name .' followed  post '; ?><?php print  l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'followed  post','class' => array('')))); ?></h4>
                        <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                    
                    <?php 
                        break; 
                        case 'LIKE_ON_POST':
                    ?>
                    <li> 
                        <div class="pull-left">
                            <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                        </div>
                       <div class="overflow-h"> <h4><?php echo $sender_nick_name .' likes a post '; ?><?php print  l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'followed  post','class' => array('')))); ?></h4>
                        <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                    <?php 
                        break;
                        case 'LIKE_ON_POST_COMMENT':
                            ?>
                                <li> 
                                    <div class="pull-left">
                                        <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                                    </div>
                                   <div class="overflow-h"> <h4><?php echo $sender_nick_name .' likes your comment on post titled '; ?><?php print  l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'followed  post','class' => array('')))); ?></h4>
                                    <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                                </li>
                    <?php 
                        break;
                        case 'LIKE_ON_POST_COMMENT_REPLY':
                            ?>
                                <li> 
                                    <div class="pull-left">
                                        <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                                    </div>
                                   <div class="overflow-h"> <h4><?php echo $sender_nick_name .' likes your reply on post titled '; ?><?php print  l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'followed  post','class' => array('')))); ?></h4>
                                    <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                                </li>
                    <?php 
                      break;  
                      case 'BLOG_COMMENT_AUTHOR_ABUSE_NOTIFY':
                        $img_uri1 = "public://default_images/default_user_img.png";
                         $style_url_default = image_style_url('simplecrop', $img_uri1); 
                    ?>
                        <li> 
                        <div class="pull-left">
                             <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url_default ?>' alt=''> 
                        </div>
                            <!-- no nee of user image -->
                            <div class="overflow-h">
                            <h4> Your comment over the post titled <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?> has been marked report as abuse  </h4>
                             <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div> 
                        </li>
                    
                    <?php 
                            break;
                        case 'BLOG_COMMENT_ABUSE_NOTIFY':
                            $img_uri1 = "public://default_images/default_user_img.png";                    
                            $style_url_default = image_style_url('simplecrop', $img_uri1); 
                    ?>
                            <li> 

                        <div class="pull-left">
                             <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url_default ?>' alt=''> 
                         </div>
                            <!-- no nee of user image -->
                            <div class="overflow-h">
                            <h4>Comment over the post titled <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?> has been marked report as abuse  </h4>
                             <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div> 
                        </li>
                    
                    <?php 
                        break;
                        case 'BLOG_COMMENT_AUTHOR_REFUSE_ABUSE_NOTIFY':
                            $img_uri1 = "public://default_images/default_user_img.png";
                            $style_url_default = image_style_url('simplecrop', $img_uri1); 
                    ?>
                            <li> 

                                                        <div class="pull-left">
                             <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url_default ?>' alt=''> 
                        </div>
                                <!-- no nee of user image -->
                                <div class="overflow-h">
                                <h4>Your 
                                <?php  print l('comment','node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?> which was reported abuse on post titled <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?> is resumed by customer admin </h4>
                                 <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div> 
                            </li>
                        
                    <?php 
                        break;
                        case 'BLOG_COMMENT_REFUSE_ABUSE_NOTIFY':
                            $img_uri1 = "public://default_images/default_user_img.png";
                            $style_url_default = image_style_url('simplecrop', $img_uri1); 
                    ?>
                            <li> 

                                                        <div class="pull-left">
                             <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url_default ?>' alt=''> 
                        </div>
                                <!-- no nee of user image -->
                                <div class="overflow-h">
                                <h4>A reported abuse 
                                <?php  print l('comment','node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?> on your  post titled <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?> is resumed by customer admin </h4>
                                 <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div> 
                            </li>
                        
                    <?php 
                        break;
                        case 'BLOG_REPORTER_REFUSE_ABUSE_NOTIFY':
                            $img_uri1 = "public://default_images/default_user_img.png";
                            $style_url_default = image_style_url('simplecrop', $img_uri1); 
                    ?>
                            <li> 

                          <div class="pull-left">
                             <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url_default ?>' alt=''> 
                           </div>
                                <!-- no nee of user image -->
                                <div class="overflow-h">
                                <h4>A reported abuse request by you on a
                                <?php  print l('comment','node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?> on <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?> is declined by customer admin. </h4>
                                 <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div> 
                            </li>
                    <?php 
                        break;
                        case 'BLOG_COMMENT_ACCEPT_ABUSE_NOTIFY':
                            $img_uri1 = "public://default_images/default_user_img.png";
                    
                         $style_url_default = image_style_url('simplecrop', $img_uri1); 
                    ?>
                            <li> 

                                                        <div class="pull-left">
                             <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url_default ?>' alt=''> 
                        </div>
                                <!-- no need of user image -->
                                <div class="overflow-h">
                                <h4>A reported abuse comment on your blog titled
                                 <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?>  is deleted by customer admin. </h4>
                                 <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div> 
                            </li>
                    <?php 
                        break;
                        case 'BLOG_COMMENT_AUTHOR_ACCEPT_ABUSE_NOTIFY':
                            $img_uri1 = "public://default_images/default_user_img.png";
                    
                         $style_url_default = image_style_url('simplecrop', $img_uri1); 
                    ?>
                            <li> 

                                                        <div class="pull-left">
                             <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url_default ?>' alt=''> 
                        </div>
                                <!-- no nee of user image -->
                                <div class="overflow-h">
                                <h4>Your comment which was reported abuse on wiki titled
                                 <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?>  is deleted by customer admin. </h4>
                                 <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div> 
                            </li>
                    <?php 
                        break;
                        case 'BLOG_REPORTER_ACCEPT_ABUSE_NOTIFY':
                            $img_uri1 = "public://default_images/default_user_img.png";
                    
                         $style_url_default = image_style_url('simplecrop', $img_uri1); 
                    ?>
                            <li> 

                            <div class="pull-left">
                             <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url_default ?>' alt=''> 
                                </div>
                                <!-- no nee of user image -->
                                <div class="overflow-h">
                                <h4>A comment reported abuse by you on post titled
                                 <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?>   is deleted by customer admin. </h4>
                                 <small><?php echo time_elapsed_string(format_date($row->created)); ?></small>
                                 </div> 
                            </li>
                    <?php 
                        break;
                        case 'BLOG_ABUSE_MARK_REPORTER_NOTIFY':
                         $img_uri1 = "public://default_images/default_user_img.png";
                         $style_url_default = image_style_url('simplecrop', $img_uri1); 
                    ?>
                            <li> 

                                                        <div class="pull-left">
                             <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url_default ?>' alt=''> 
                        </div>


                                <!-- no nee of user image -->
                                <div class="overflow-h">
                                <h4>A comment is reported abuse by you on blog titled 
                                 <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?> . </h4>
                                 <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div> 
                            </li>
                    <?php 
                        break;
                    case 'POST_REJECT_NOTIFY_EDITOR':
                        ?>
                            <?php 
                                // find blog title
                                $blog_object = get_blog_title_from_post_nid($row->entity_id);                            
                            ?>
                            <li> 
                                <div class="pull-left">
                                    <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                                </div>
                                <div class="overflow-h">
                                <h4> <?php echo $sender_nick_name; ?> has rejected your post titled 
                                 <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?>  
                                 
                                 for the blog titled 
                                 <?php  print l($blog_object->title,'node/'.$blog_object->nid,array( 'attributes' => array('title' => '','class' => array('')))); ?>  
                                 
                                 
                                 </h4>
                                 <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div> 
                            </li>
                    <?php 
                        break;
                        case 'LESSON_CREATE':
                    ?>
                    <li> 
                        <div class="pull-left">
                            <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                        </div>
                         <div class="overflow-h"><h4> 
                        <?php
                           $string = strip_tags($sender_nick_name);
                          $string_trimmed = str_replace(' ', '', $string);
                            if($string_trimmed == 'You') {
                                  ?>
                                <?php echo 'Your lesson '; ?> <?php print l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => ' new lesson ','class' => array('')))); ?>
                                <?php echo 'has been published.'; ?>                    

                            <?php
                                } else {

                                    echo $sender_nick_name .' created a lesson '; ?> <?php print l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => ' new lesson ','class' => array('')))); 
                                
                                    }
                             ?> 


                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                    <?php 
                        break; 
 
                        case 'LESSON_LIKE':
                    ?>
                    <li> 
                        <div class="pull-left">
                            <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                        </div>
                        <?php 
                            $string = strip_tags($sender_nick_name);
                          $string_trimmed = str_replace(' ', '', $string);
                            if($string_trimmed == 'You') {
                                $var_like = " like";
                            } else {
                                $var_like = " likes";
                            }


                            
                        ?>
                         <div class="overflow-h"><h4> <?php echo $sender_nick_name . $var_like .' your lesson titled '; ?> <?php print l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => ' lesson ','class' => array('')))); ?>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                    <?php 
                        break;  
                        case 'LESSON_COMMENT_LIKE':
                    ?>
                    <li> 
                        <div class="pull-left">
                            <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                        </div>
                        <?php 
                            $string = strip_tags($sender_nick_name);
                          $string_trimmed = str_replace(' ', '', $string);
                            if($string_trimmed == 'You') {
                                $var_like = " like";
                            } else {
                                $var_like = " likes";
                            }
                        ?>                        
                         <div class="overflow-h"><h4> <?php echo $sender_nick_name . $var_like .' a Comment on lesson '; ?> <?php print l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => ' lesson ','class' => array('')))); ?>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                    <?php 
                        break;                                                
                        case 'LESSON_UPDATED':
                    ?>
                    <li> 
                        <div class="pull-left">
                            <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                        </div>
                        <div class="overflow-h"><h4><?php echo $sender_nick_name.' updated a lesson '; ?> <?php print l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'updated lesson','class' => array('')))); ?></h4>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                    <?php 
                        break; 
                        case 'LESSON_COMMENT':
                    ?>
                    <li> 
                        <div class="pull-left">
                            <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                        </div>
                        <div class="overflow-h"><h4> <?php echo $sender_nick_name.' commented on lesson '; ?> <?php print l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'updated lesson','class' => array('')))); ?></h4>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                    <?php 
                            break;
                        case 'WALL_POST_COMMENT':
                    ?>
                    <li> 
                        <div class="pull-left">
                            <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                        </div>
                        

                        <div class="overflow-h"><h4> <?php echo $sender_nick_name.' replied on your VOICE Update '; ?>

                        <?php
                            if (drupal_is_front_page()) {
                        ?>
                            <?php print $md_title; ?>
                               <?php } else { ?>

                            <?php print l($md_title ,'/',array( 'attributes' => array('title' => 'updated lesson','class' => array('')))); ?>

                         <?php } ?>
                         
                            </h4>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>


                    </li>
                    <?php 
                            break;                            
                        case 'LESSON_COMMENT_AUTHOR_ABUSE_NOTIFY':
                            $img_uri1 = "public://default_images/default_user_img.png";
                    
                         $style_url_default = image_style_url('simplecrop', $img_uri1); 
                    ?>
                            <li> 

                                                        <div class="pull-left">
                             <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url_default ?>' alt=''> 
                        </div>
                            <!-- no nee of user image -->
                            <div class="overflow-h">
                            <h4> Your comment over the lesson titled <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'Report Abuse','class' => array('')))); ?> has been marked report as abuse  </h4>
                             <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div> 
                        </li>
                    
                    <?php 
                            break;
                        case 'LESSON_COMMENT_ABUSE_NOTIFY':
                            $img_uri1 = "public://default_images/default_user_img.png";
                    
                         $style_url_default = image_style_url('simplecrop', $img_uri1); 
                    ?>
                            <li> 

                                                        <div class="pull-left">
                             <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url_default ?>' alt=''> 
                        </div>
                            <!-- no nee of user image -->
                            <div class="overflow-h">
                            <h4> Comment over the lesson titled <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'Report Abuse','class' => array('')))); ?> has been marked report as abuse  </h4>
                             <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div> 
                        </li>
                    
                    <?php 
                        break;
                        case 'LESSON_COMMENT_AUTHOR_REFUSE_ABUSE_NOTIFY':
                            $img_uri1 = "public://default_images/default_user_img.png";
                    
                         $style_url_default = image_style_url('simplecrop', $img_uri1); 
                    ?>
                            <li> 

                                                        <div class="pull-left">
                             <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url_default ?>' alt=''> 
                        </div>
                                <!-- no nee of user image -->
                                <div class="overflow-h">
                                <h4>Your 
                                <?php  print l('comment','node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?> which was reported abuse on lesson titled <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?> is resumed by customer admin </h4>
                                 <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div> 
                            </li>
                        
                    <?php 
                        break;
                        case 'LESSON_COMMENT_REFUSE_ABUSE_NOTIFY':
                            $img_uri1 = "public://default_images/default_user_img.png";
                    
                         $style_url_default = image_style_url('simplecrop', $img_uri1); 
                    ?>
                            <li> 

                                                        <div class="pull-left">
                             <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url_default ?>' alt=''> 
                        </div>
                                <!-- no nee of user image -->
                                <div class="overflow-h">
                                <h4>A reported abuse 
                                <?php  print l('comment','node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?> on your  lesson titled <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?> is resumed by customer admin </h4>
                                 <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div> 
                            </li>                        
                    <?php  
                        break;
                        case 'LESSON_REPORTER_REFUSE_ABUSE_NOTIFY':
                            $img_uri1 = "public://default_images/default_user_img.png";
                    
                         $style_url_default = image_style_url('simplecrop', $img_uri1); 
                    ?>
                            <li> 

                                                        <div class="pull-left">
                             <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url_default ?>' alt=''> 
                        </div>
                                <!-- no nee of user image -->
                                <div class="overflow-h">
                                <h4>A reported abuse request by you on a
                                <?php  print l('comment','node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?> on <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?> is declined by customer admin. </h4>
                                 <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div> 
                            </li>
                    <?php 
                        break;case 'LESSON_COMMENT_ACCEPT_ABUSE_NOTIFY':
                            $img_uri1 = "public://default_images/default_user_img.png";
                    
                         $style_url_default = image_style_url('simplecrop', $img_uri1); 
                    ?>
                            <li> 

                                                        <div class="pull-left">
                             <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url_default ?>' alt=''> 
                        </div>
                                <!-- no nee of user image -->
                                <div class="overflow-h">
                                <h4>A reported abuse comment on your lesson titled
                                 <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?>  is deleted by customer admin. </h4>
                                 <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div> 
                            </li>
                    <?php 
                        break;
                        case 'LESSON_COMMENT_AUTHOR_ACCEPT_ABUSE_NOTIFY':
                         $img_uri1 = "public://default_images/default_user_img.png";
                                            
                         $style_url_default = image_style_url('simplecrop', $img_uri1); 
                        ?>
                            <li> 
                            <div class="pull-left">
                                 <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url_default ?>' alt=''> 
                            </div>
                                <!-- no nee of user image -->
                                <div class="overflow-h">
                                <h4>Your comment which was reported abuse on lesson titled
                                 <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?>  is deleted by customer admin. </h4>
                                 <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div> 
                            </li>
                    <?php 
                        break;
                        case 'LESSON_REPORTER_ACCEPT_ABUSE_NOTIFY':
                            $img_uri1 = "public://default_images/default_user_img.png";
                    
                         $style_url_default = image_style_url('simplecrop', $img_uri1); 
                    ?>
                            <li> 

                                                        <div class="pull-left">
                             <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url_default ?>' alt=''> 
                        </div>
                                <!-- no nee of user image -->
                                <div class="overflow-h">
                                <h4>A comment reported abuse by you on lesson titled
                                 <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?>   is deleted by customer admin. </h4>
                                 <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div> 
                            </li>
                    <?php 
                        break;
                        case 'LESSON_ABUSE_MARK_REPORTER_NOTIFY':
                            $img_uri1 = "public://default_images/default_user_img.png";
                    
                         $style_url_default = image_style_url('simplecrop', $img_uri1); 
                    ?>
                            <li> 

                                                        <div class="pull-left">
                             <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url_default ?>' alt=''> 
                        </div>
                                <!-- no nee of user image -->
                                <div class="overflow-h">
                                <h4>A comment is reported abuse by you on lesson titled 
                                 <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?>  . </h4>
                                 <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div> 
                            </li>
                    <?php 
                        break;
                        case 'QUERY_COMMENT':
                    ?>
                    <li> 
                        <div class="pull-left">
                               <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                         </div>
                         <div class="overflow-h"><h4><?php echo $sender_nick_name .' commented on your query titled '; ?> <?php  print l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'new query','class' => array('') ))); ?></h4>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                    
                    <?php 
                       break;
                        case 'WIKI_COMMENT':
                    ?>
                    <li> 
                        <div class="pull-left">
                               <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                         </div>
                         <div class="overflow-h"><h4><?php echo $sender_nick_name .' commented on your wiki titled '; ?> <?php  print l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'new query','class' => array('') ))); ?></h4>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                    
                    <?php 
                       break;                       
                       case 'COMMENT_COMMENT':
                    ?>
                    <li> 
                        <div class="pull-left">
                               <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                         </div>
                         <div class="overflow-h"><h4><?php echo $sender_nick_name .' replied on your comment '; ?> <?php  print l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'Comment','class' => array('') ))); ?></h4>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                    
                    <?php 
                       break;                       
                       case 'QUERY_LIKE':
                    ?>
                    <li> 
                        <div class="pull-left">
                            <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                        </div>
                        <?php 
                            $string = strip_tags($sender_nick_name);
                          $string_trimmed = str_replace(' ', '', $string);
                            if($string_trimmed == 'You') {
                                $var_like = " like";
                            } else {
                                $var_like = " likes";
                            }
                        ?>                         
                         <div class="overflow-h"><h4> <?php echo $sender_nick_name . $var_like .' your query titled '; ?> <?php print l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => ' query ','class' => array('')))); ?>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                    <?php 
                        break;  
                        case 'QUERY_COMMENT_LIKE':
                    ?>
                    <li> 
                        <div class="pull-left">
                            <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                        </div>
                        <?php 
                            $string = strip_tags($sender_nick_name);
                          $string_trimmed = str_replace(' ', '', $string);
                            if($string_trimmed == 'You') {
                                $var_like = " like";
                            } else {
                                $var_like = " likes";
                            }
                        ?>                         
                         <div class="overflow-h"><h4> <?php echo $sender_nick_name . $var_like .' your comment on query titled '; ?> <?php print l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => ' query ','class' => array('')))); ?>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                    <?php 
                        break;      
                      case 'QUERY_ClOSED_PRIVATE':
                    ?>
                    <li> 
                        <div class="pull-left">
                            <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                        </div>
                         <div class="overflow-h"><h4> <?php print "Query ". l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => ' query ','class' => array('')))) ." has been marked as private"; ?>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                    <?php 
                        break;    
                     case 'QUERY_ClOSED_PUBLIC':
                    ?>
                    <li> 
                        <div class="pull-left">
                            <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                        </div>
                         <div class="overflow-h"><h4> 
                        <?php print "Query ". l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => ' query ','class' => array('')))) ." has been marked as public"; ?>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                    <?php 
                        break;                                                                   
                     case 'TASK_CREATE':
                    ?>
                    <li> 
                        <div class="pull-left">
                              <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                         </div>
                         <div class="overflow-h"><h4><?php echo $sender_nick_name .' created a task  '; ?> <?php  print l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'New Task','class' => array('') ))); ?></h4>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                    <?php 
                       break;
                       case 'TASK_ASSIGN':
                           ?>
                           <li> 
                               <div class="pull-left">
                                     <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                                </div>
                                <div class="overflow-h"><h4><?php echo $sender_nick_name .' assign  task  '; ?> <?php  print l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'New Task','class' => array('') ))); ?></h4>
                                <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                           </li>
                           <?php 
                              break;
                     case 'PROJECT_CREATE':
                    ?>
                    <li> 
                        <div class="pull-left">
                              <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                         </div>
                         <div class="overflow-h"><h4><?php echo $sender_nick_name .' created a project '; ?> <?php  print l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'new project','class' => array('') ))); ?></h4>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                    <?php 
                       break;                    
                     case 'TEAM_CREATE':
                    ?>
                    <li> 
                        <div class="pull-left">
                              <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                         </div>
                         <div class="overflow-h"><h4><?php echo $sender_nick_name .' added you as a Team member in '; ?> <?php  print l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'Team member','class' => array('') ))); ?></h4>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                    
                    
                    <?php 
                       break;
                       case 'WIKI_CREATE':
                     ?>
                    <li> 
                        <div class="pull-left">
                               <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                         </div>
                         <div class="overflow-h"><h4><?php echo $sender_nick_name .' created new wiki '; ?> <?php  print l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'Wiki','class' => array('') ))); ?></h4>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                    <?php 
                       break;   
                            case 'WIKI_ARCHIEVED':
                     ?>
                    <li> 
                        <div class="pull-left">
                               <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                         </div>
                         <div class="overflow-h"><h4><?php echo $sender_nick_name .' have archieved your wiki titled '; ?> <?php  print l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'Wiki','class' => array('') ))); ?></h4>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                    <?php 
                       break;                    
                       case 'WIKI_UPDATED':
                    ?>
                    <li> 
                        <div class="pull-left">
                               <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                         </div>
                         <div class="overflow-h"><h4><?php echo $sender_nick_name .' published wiki titled '; ?> <?php  print l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'Wiki','class' => array('') ))); ?></h4>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                    
                    <?php 
                       break;    
                       case 'WIKI_SAVE_DRAFT':
                    ?>
                    <li> 
                        <div class="pull-left">
                               <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                         </div>
                         <div class="overflow-h"><h4><?php echo $sender_nick_name .' saved wiki as draft'; ?> <?php  print l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'Wiki','class' => array('') ))); ?></h4>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                    
                    <?php 
                            break; 
                      case 'WIKI_LIKE':
                    ?>
                    <li> 
                        <div class="pull-left">
                            <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                        </div>
                        <?php 
                            $string = strip_tags($sender_nick_name);
                          $string_trimmed = str_replace(' ', '', $string);
                            if($string_trimmed == 'You') {
                                $var_like = " like";
                            } else {
                                $var_like = " likes";
                            }


                            
                        ?>
                         <div class="overflow-h"><h4> <?php echo $sender_nick_name . $var_like .' your wiki titled '; ?> <?php print l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => ' lesson ','class' => array('')))); ?>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                    <?php 
                        break;   
                        case 'WIKI_COMMENT_AUTHOR_ABUSE_NOTIFY':
                            $img_uri1 = "public://default_images/default_user_img.png";
                    
                         $style_url_default = image_style_url('simplecrop', $img_uri1); 
                    ?>
                            <li> 

                                                        <div class="pull-left">
                             <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url_default ?>' alt=''> 
                        </div>
                           <!-- no need of user image -->
                           <div class="overflow-h">
                           <h4> Your comment over the wiki titled <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'Report abuse','class' => array('')))); ?> has been marked report as abuse  </h4>
                            <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div> 
                       </li>
                   <?php 
                           break;
                       case 'WIKI_COMMENT_ABUSE_NOTIFY':
                            $img_uri1 = "public://default_images/default_user_img.png";
                    
                         $style_url_default = image_style_url('simplecrop', $img_uri1); 
                    ?>
                            <li> 

                                                        <div class="pull-left">
                             <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url_default ?>' alt=''> 
                        </div>
                              <!-- no need of user image -->
                              <div class="overflow-h">
                              <h4>Comment over the wiki titled <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'Report abuse','class' => array('')))); ?> has been marked report as abuse  </h4>
                               <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div> 
                          </li>
                    <?php 
                           break;
                           case 'WIKI_COMMENT_AUTHOR_REFUSE_ABUSE_NOTIFY':
                            $img_uri1 = "public://default_images/default_user_img.png";
                    
                         $style_url_default = image_style_url('simplecrop', $img_uri1); 
                    ?>
                            <li> 

                                                        <div class="pull-left">
                             <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url_default ?>' alt=''> 
                        </div>
                                <!-- no nee of user image -->
                                <div class="overflow-h">
                                <h4>Your 
                                <?php  print l('comment','node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?> which was reported abuse on wiki titled <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?> is resumed by customer admin </h4>
                                 <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div> 
                            </li>
                        
                    <?php 
                        break;
                        case 'WIKI_COMMENT_REFUSE_ABUSE_NOTIFY':
                        $img_uri1 = "public://default_images/default_user_img.png";
                    
                         $style_url_default = image_style_url('simplecrop', $img_uri1); 
                    ?>
                            <li> 

                                                        <div class="pull-left">
                             <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url_default ?>' alt=''> 
                        </div>
                                <!-- no nee of user image -->
                                <div class="overflow-h">
                                <h4>A reported abuse 
                                <?php  print l('comment','node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?> on your  wiki titled <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?> is resumed by customer admin </h4>
                                 <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div> 
                            </li>                        
                    <?php 
                        break;
                        case 'WIKI_REPORTER_REFUSE_ABUSE_NOTIFY':
                        $img_uri1 = "public://default_images/default_user_img.png";
                    
                         $style_url_default = image_style_url('simplecrop', $img_uri1); 
                    ?>
                            <li> 

                                                        <div class="pull-left">
                             <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url_default ?>' alt=''> 
                        </div>
                                <!-- no nee of user image -->
                                <div class="overflow-h">
                                <h4>A reported abuse request by you on a
                                <?php  print l('comment','node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?> on <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?> is declined by customer admin. </h4>
                                 <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div> 
                            </li>
                    <?php 
                        break;
                        break;case 'WIKI_COMMENT_ACCEPT_ABUSE_NOTIFY':
                        $img_uri1 = "public://default_images/default_user_img.png";
                    
                         $style_url_default = image_style_url('simplecrop', $img_uri1); 
                    ?>
                            <li> 

                                                        <div class="pull-left">
                             <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url_default ?>' alt=''> 
                        </div>
                                <!-- no nee of user image -->
                                <div class="overflow-h">
                                <h4>A reported abuse comment on your wiki titled
                                 <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?>  is deleted by customer admin. </h4>
                                 <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div> 
                            </li>
                    <?php 
                        break;
                        case 'WIKI_COMMENT_AUTHOR_ACCEPT_ABUSE_NOTIFY':
                            $img_uri1 = "public://default_images/default_user_img.png";
                    
                         $style_url_default = image_style_url('simplecrop', $img_uri1); 
                    ?>
                            <li> 

                                                        <div class="pull-left">
                             <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url_default ?>' alt=''> 
                        </div>
                                <!-- no nee of user image -->
                                <div class="overflow-h">
                                <h4>Your comment which was reported abuse on wiki titled
                                 <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?>  is deleted by customer admin. </h4>
                                 <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div> 
                            </li>
                    <?php 
                        break;
                        case 'WIKI_REPORTER_ACCEPT_ABUSE_NOTIFY':
                            $img_uri1 = "public://default_images/default_user_img.png";
                    
                         $style_url_default = image_style_url('simplecrop', $img_uri1); 
                    ?>
                            <li> 

                                                        <div class="pull-left">
                             <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url_default ?>' alt=''> 
                        </div>
                                <!-- no nee of user image -->
                                <div class="overflow-h">
                                <h4>A comment reported abuse by you on wiki titled
                                 <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?>   is deleted by customer admin. </h4>
                                 <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div> 
                            </li>
                    <?php 
                        break;
                        case 'LESSON_ABUSE_MARK_REPORTER_NOTIFY':
                        $img_uri1 = "public://default_images/default_user_img.png";
                    
                         $style_url_default = image_style_url('simplecrop', $img_uri1); 
                    ?>
                            <li> 

                                                        <div class="pull-left">
                             <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url_default ?>' alt=''> 
                        </div>
                                <!-- no nee of user image -->
                                <div class="overflow-h">
                                <h4>A comment is reported abuse by you on wiki titled 
                                 <?php  print l($md_title,'node/'.$row->entity_id,array( 'attributes' => array('title' => '','class' => array('')))); ?> . </h4>
                                 <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div> 
                            </li>
                    <?php 
                        break;
                       case 'KM_FOLDER_CREATE':
                           // get cid of folder or reach  that location through link
                           
                           // display($row->entity_id);
                           
                           $folder_array = get_filedepot_folder_from_nid($row->entity_id);     
                    ?>
                    <li> 
                        <div class="pull-left">
                               <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                         </div>
                         <div class="overflow-h"><h4><?php echo $sender_nick_name.' created a folder'; ?> <?php  print l($md_title ,'knowledge-repository/folder/'.$folder_array['cid'],array( 'attributes' => array('title' => 'Repository','class' => array('') ))); ?></h4>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                    
                    <?php 
                       break;                    
                       case 'KM_FOLDER_UPDATE':
                            
                           // get File name 
                           
                           $folder_array = get_filedepot_folder_from_nid($row->entity_id);
                    ?>
                    <li> 
                        <div class="pull-left">
                              <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                         </div>
                         <div class="overflow-h"><h4><?php echo $sender_nick_name .' updated folder'; ?> <?php  print l($md_title ,'knowledge-repository/folder/'.$folder_array['cid'],array( 'attributes' => array('title' => 'Repository','class' => array('') ))); ?></h4>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                    
                    <?php 
                       break;                    
                       
                       case 'KM_FOLDER_SHARE':
                           $file_array = get_filedepot_folder_from_cid($row->entity_id); // here $row->entity_id is folder cid 
                    ?>
                    <li> 
                        <div class="pull-left">
                               <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>                              
                         </div>
                         <div class="overflow-h"><h4><?php echo $sender_nick_name .' shared a folder'; ?> <?php  print l($file_array['name'] ,'knowledge-repository/folder/'.$row->entity_id,array( 'attributes' => array('title' => 'Repository','class' => array('') ))); ?> with you</h4>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                    
                    <?php 
                       break;                    
                       case 'KM_FILE_UPLOAD':
                           // var_dump($row->entity_id);
                           $folder_array = get_filedepot_folder_from_nid($row->entity_id);
                           $otheraray =  !empty($row->other_val) ? json_decode($row->other_val) : NULL;
                           $getfileobject = null;
                           if($otheraray) {
                               // display($otheraray->file_id);
                                $getfileobject = getKrFileNameWithFid($otheraray->file_id);
                               // display($getfileobject);
                           }
                           // display($getfileobject);  
                    ?>
                    <li> 
                        <div class="pull-left">
                              <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                         </div>
                         <div class="overflow-h"><h4><?php echo $sender_nick_name .' have uploaded the file titled  ';?>  <?php echo $getfileobject['title'] ?>  in the folder   <?php  print l($md_title ,'knowledge-repository/folder/'.$folder_array['cid'],array( 'attributes' => array('title' => 'Repository','class' => array('') ))); ?></h4>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                    
                    <?php 
                       break;                    
                       case 'KM_FILE_VERSION_UPDATE': // this is file version update notification
                           $folder_array = get_filedepot_folder_from_nid($row->entity_id);
                    ?>
                    <li>       
                        <div class="pull-left">
                               <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                         </div>
                         <div class="overflow-h"><h4><?php echo $sender_nick_name .' add new file version in'; ?> <?php  print l($md_title ,'knowledge-repository/folder/'.$folder_array['cid'],array( 'attributes' => array('title' => 'Repository','class' => array('') ))); ?></h4>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                    
                    <?php 
                       break;                    
                       case 'KM_FOLDER_UPLOAD':
                    ?>
                    <li> 
                        <div class="pull-left">
                              <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                         </div>
                         <div class="overflow-h"><h4><?php echo $sender_nick_name .' upload a folder'; ?> <?php  print l($md_title ,'knowledge-repository/folder/'.$row->entity_id,array( 'attributes' => array('title' => 'Repository','class' => array('') ))); ?></h4>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                    
                    <?php 
                       break;                    
                       case 'KM_UPLOAD_RIGHT':
                           $file_array = get_filedepot_folder_from_cid($row->entity_id);
                    ?>
                    <li> 
                        <div class="pull-left">
                              <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                         </div>
                         <div class="overflow-h"><h4><?php echo $sender_nick_name .' provided rights to upload file in folder '; ?> <?php  print l($file_array['name'] ,'knowledge-repository/folder/'.$row->entity_id,array( 'attributes' => array('title' => 'Repository','class' => array('') ))); ?></h4>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                    
                    <?php 
                       break;                    
                       case 'KM_FIRST_APPROVER':
                       $file_array = get_filedepot_folder_from_cid($row->entity_id);
                    ?>
                    <li> 
                        <div class="pull-left">
                               <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                         </div>
                         <div class="overflow-h"><h4><?php echo $sender_nick_name .' made you 1st level approver  for folder '; ?> <?php  print l($file_array['name'] ,'knowledge-repository/folder/'.$row->entity_id,array( 'attributes' => array('title' => 'Repository','class' => array('') ))); ?></h4>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                    
                    
                    <?php 
                       break; 
                       case 'KR_GLOBAL_FILE_UPLOAD_NOTIFICATION':
                           $folder_array = get_filedepot_folder_from_nid($row->entity_id);
                           $otheraray =  !empty($row->other_val) ? json_decode($row->other_val) : NULL;
                           $getfileobject = null;
                           $file_title = '';
                           if($otheraray) {
                               // display($otheraray->file_id);
                               $getfileobject = getKrFileNameWithFid($otheraray->file_id);
                               // display($getfileobject);
                               $file_title = $getfileobject['title'];
                           }
                           
                           $withoutExt = preg_replace('/\\.[^.\\s]{3,4}$/', '', $file_title);
                           // display($folder_array);
                           ?>
                                           <li> 
                                               <div class="pull-left">
                                                      <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                                                </div>
                                                <div class="overflow-h"><h4><?php echo $sender_nick_name .' has published a document <strong>'.  $withoutExt .'</strong> in Organizational Drive - '; ?> <?php  print l($folder_array['name'] ,'knowledge-repository/folder/'.$folder_array['cid'],array( 'attributes' => array('title' => 'Repository','class' => array('') ))); ?></h4>
                                                <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                                           </li>
                    <?php 
                       break;
                       case 'KM_FILE_APPROVED':
                       $file_array = get_filedepot_folder_from_cid($row->entity_id);
                    ?>
                    <li> 
                        <div class="pull-left">
                               <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                         </div>
                         <div class="overflow-h"><h4><?php echo $sender_nick_name .' has approved your file in folder '; ?> <?php  print l($file_array['name'] ,'knowledge-repository/folder/'.$row->entity_id,array( 'attributes' => array('title' => 'Repository','class' => array('') ))); ?></h4>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                    <?php 
                       break;  
                       case 'KM_FILE_REJECTED':
                       $file_array = get_filedepot_folder_from_cid($row->entity_id);
                    ?>
                    <li> 
                        <div class="pull-left">
                               <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                         </div>
                         <div class="overflow-h"><h4><?php echo $sender_nick_name .' has rejected your file in folder '; ?> <?php  print l($file_array['name'] ,'knowledge-repository/folder/'.$row->entity_id,array( 'attributes' => array('title' => 'Repository','class' => array('') ))); ?></h4>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                    
                    <?php 
                       break; 
                       case 'KM_FILE_FOR_APPROVAL':
                       $file_array = get_filedepot_folder_from_cid($row->entity_id);
                    ?>
                    <li> 
                        <div class="pull-left">
                               <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                         </div>
                         <div class="overflow-h"><h4><?php echo $sender_nick_name .' sent you file for approval file name '; ?> <?php  print l($file_array['name'] ,'knowledge-repository/folder/'.$row->entity_id,array( 'attributes' => array('title' => 'Repository','class' => array('') ))); ?></h4>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                    
                    
                    <?php 
                       break;
                       case 'KM_FILE_UPLOAD_FOR_APPOVAL_01':  // not use here
                       $file_array = get_filedepot_folder_from_cid($row->entity_id);
                       ?>
                       <li> 
                           <div class="pull-left">
                                  <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                            </div>
                            <div class="overflow-h"><h4><?php echo $sender_nick_name .' sent you file for approval file name '; ?> <?php  print l($file_array['name'] ,'knowledge-repository/folder/'.$row->entity_id,array( 'attributes' => array('title' => 'Repository','class' => array('') ))); ?></h4>
                            <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                       </li>
                       
                       <?php 
                        break;
                       case 'KM_SECOND_APPROVER':
                       $file_array = get_filedepot_folder_from_cid($row->entity_id);
                    ?>
                    <li> 
                        <div class="pull-left">
                               <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                         </div>
                         <div class="overflow-h"><h4><?php echo $sender_nick_name .' made you 2nd level approver for folder '; ?> <?php   print l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'Repository','class' => array('') ))); ?></h4>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                    </li>
                    
                    
                    <?php 
                       break;
                       case 'CERTIFICATION_CREATE':
                           ?>
                    <li> 
                        <div class="pull-left">
                               <a href="<?php echo $base_url.'/my-profile/'; ?>" target="_blank" title="<?php echo $sender_name ?>" ><img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt=''>
                        </div> 
                        <div class="overflow-h"><h4><?php print l('You have added certification in your profile.','my-profile',array('attributes' => array('title' => 'certification update','class' => array('')))); ?></h4>
                        <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                   </li>       
                        <?php 
                        break; 
                        case 'CERTIFICATION_UPDATE':
                            ?>
                        <li> 
                            <div class="pull-left">
                               <a href="<?php echo $base_url.'/my-profile/'; ?>" target="_blank" title="<?php echo $sender_name ?>" ><img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt=''>
                            </div> 
                            <div class="overflow-h"><h4><?php print l('You have updated certification','my-profile',array('attributes' => array('title' => 'certification update','class' => array('')))); ?></h4>
                            <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                       </li>       
                         <?php 
                         break; 
                         case 'EXPERIENCE_CREATE':
                             ?>
                        <li> 
                            <div class="pull-left">
                               <a href="<?php echo $base_url.'/my-profile/'; ?>" target="_blank" title="<?php echo $sender_name ?>" ><img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt=''>
                            </div> 
                            <div class="overflow-h"><h4><?php print l('You have added working experience in your profile.','my-profile',array('attributes' => array('title' => 'experience update','class' => array('')))); ?></h4>
                            <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                       </li>       
                           <?php 
                           break;
                           case 'EXPERIENCE_UPDATE':
                              ?>
                          <li> 
                              <div class="pull-left">
                                 <a href="<?php echo $base_url.'/my-profile/'; ?>" target="_blank" title="<?php echo $sender_name ?>" ><img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt=''>
                              </div> 
                              <div class="overflow-h"><h4><?php print l('You have updated working experience in your profile.','my-profile',array('attributes' => array('title' => 'experience update','class' => array('')))); ?></h4>
                              <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                          </li>       
                            <?php 
                            break;
                             case 'ACCOUNT_CREATE':
                             ?>
                        <li> 
                            <div class="pull-left">
                               <a href="<?php echo $base_url.'/my-profile/'; ?>" target="_blank" title="<?php echo $sender_name ?>" ><img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt=''>
                            </div> 
                            <div class="overflow-h"><h4><?php print l('You have added Basic Information in your profile.','my-profile',array('attributes' => array('title' => 'experience update','class' => array('')))); ?></h4>
                            <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                       </li>       
                           <?php 
                           break;
                            case 'SKILL_UPDATE':
                             ?>
                        <li> 
                            <div class="pull-left">
                               <a href="<?php echo $base_url.'/my-profile/'; ?>" target="_blank" title="<?php echo $sender_name ?>" ><img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt=''>
                            </div> 
                            <div class="overflow-h"><h4><?php print l('You have Updated Skills in your profile.','my-profile',array('attributes' => array('title' => 'experience update','class' => array('')))); ?></h4>
                            <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                       </li>       
                           <?php 
                           break;

                           case 'ACCOUNT_UPDATE':
                              ?>
                          <li> 
                              <div class="pull-left">
                                 <a href="<?php echo $base_url.'/my-profile/'; ?>" target="_blank" title="<?php echo $sender_name ?>" ><img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt=''>
                              </div> 
                              <div class="overflow-h"><h4><?php print l('You have updated Account Information in your profile.','my-profile',array('attributes' => array('title' => 'experience update','class' => array('')))); ?></h4>
                              <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                          </li>       
                            <?php 
                            break;
                            case 'PHONE_UPDATE':
                              ?>
                          <li> 
                              <div class="pull-left">
                                 <a href="<?php echo $base_url.'/my-profile/'; ?>" target="_blank" title="<?php echo $sender_name ?>" ><img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt=''>
                              </div> 
                              <div class="overflow-h"><h4><?php print l('You have updated Contact Number in your profile.','my-profile',array('attributes' => array('title' => 'experience update','class' => array('')))); ?></h4>
                              <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                          </li>       
                            <?php 
                            break;                            
                            case 'BASIC_UPDATE':
                              ?>
                          <li> 
                              <div class="pull-left">
                                 <a href="<?php echo $base_url.'/my-profile/'; ?>" target="_blank" title="<?php echo $sender_name ?>" ><img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt=''>
                              </div> 
                              <div class="overflow-h"><h4><?php print l('You have updated Basic Information in your profile.','my-profile',array('attributes' => array('title' => 'experience update','class' => array('')))); ?></h4>
                              <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                          </li>       
                            <?php 
                            break;
                            case 'EDUCATION_CREATE':
                               ?>
                           <li> 
                               <div class="pull-left">
                                  <a href="<?php echo $base_url.'/my-profile/'; ?>" target="_blank" title="<?php echo $sender_name ?>" ><img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt=''>
                               </div> 
                               <div class="overflow-h"><h4><?php print l('You have added your education in your profile.','my-profile',array('attributes' => array('title' => 'education update','class' => array('')))); ?></h4>
                               <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                          </li>       
                            <?php 
                            break;
                            case 'EDUCATION_UPDATE':
                                ?>
                            <li> 
                                <div class="pull-left">
                                   <a href="<?php echo $base_url.'/my-profile/'; ?>" target="_blank" title="<?php echo $sender_name ?>" ><img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt=''>
                                </div> 
                                <div class="overflow-h"><h4><?php print l('You have updated your education in your profile.','my-profile',array('attributes' => array('title' => 'education update','class' => array('')))); ?></h4>
                                <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                            </li>       
                             <?php 
                             break;
                             case 'EMAIL_UPDATE':
                                 ?>
                             <li> 
                                 <div class="pull-left">
                                    <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" ><img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt=''>
                                 </div> 
                                 <div class="overflow-h"><h4><?php echo $sender_nick_name ;?><?php  print l(' has updated your email address in your profile.','my-profile',array('attributes' => array('title' => 'email update','class' => array('')))); ?></h4>
                                 <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                             </li>       
                             <?php 
                             break;
                         case 'QUERY_UPDATED':
                    ?>
                   
                        <?php 
                          $string = strip_tags($sender_nick_name);
                          $string_trimmed = str_replace(' ', '', $string);
                            if($string_trimmed == 'You') {
                        ?>
 
                        <li> 
                        <div class="pull-left">
                            <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                        </div>


                         <div class="overflow-h"><h4><?php echo 'Your query titled '; ?> <?php  print l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'new query','class' => array('') ))); ?> has been updated </h4>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                            </li>
                        <?php

                            }  
                        ?> 


                 
                    
                    <?php 
                        break;                             
                              case 'COMMUNITY_CREATE':
                    ?>
                    <li> 
                        <div class="pull-left">
                            <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name; ?>'> </a>
                        </div>



                        <?php 
                          $string = strip_tags($sender_nick_name);
                          $string_trimmed = str_replace(' ', '', $string);
                            if($string_trimmed == 'You') {
                        ?>
 
                         <div class="overflow-h"><h4><?php echo 'Your Community titled '; ?> <?php  print l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'new Community','class' => array('') ))); ?> has been created </h4>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                        <?php

                            } else {
                        ?>
                         <div class="overflow-h"><h4><?php echo $sender_nick_name .' posted a  community titled '; ?> <?php  print l($md_title ,'node/'.$row->entity_id,array( 'attributes' => array('title' => 'new query','class' => array('') ))); ?></h4>
                         <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                        <?php

                            }
                        ?> 


                    </li>
                    
                    <?php 
                        break;
  
                    case 'USER_FOLLOW':
                           ?>
                             <?php if($row->sender_id != $row->receiver_id) { ?>
                             
                                 <li> 
                                      <div class="pull-left">
                                         <a href="<?php echo $base_url.'/profile/'.$row->name; ?>" target="_blank" title="<?php echo $sender_name; ?>" > <img typeof='foaf:Image' class='img-circle' src='<?php echo $style_url ?>' alt='<?php echo $sender_name ?>'> </a>                                   
                                      </div> 
                                      <div class="overflow-h">
                                      <h4><?php  echo  $sender_nick_name;?> <?php print l('has started following you.' ,'my-profile',array('attributes' => array('title' => 'follow','class' => array('')))); ?></h4>
                                      <small><?php echo time_elapsed_string(format_date($row->created)); ?></small></div>
                                 </li>
                             <?php } ?>
                      <?php 
                      break;   
                    ?>
                                      
                <?php 
                    }
                 endforeach;
                }else{
                    echo '<li> You have no new notification .</li>';
                }
                ?>
                </ul>
                </li>
        <!--  end notification html  -->
    <li>
   </li> 
   </ul> 
   </li>

<!-- Two End -->   








    <!--<li><a href='#' title='Help'><i class='fa fa-question-circle-o' aria-hidden='true'></i><span class='hidden-xs'> Help</span></a></li>-->
    <li class='dropdown user user-menu'><a href='#' class='dropdown-toggle' data-toggle='dropdown'>
                    <img src="<?php echo get_profile_img($img_url) ?>&cd=<?php echo rand(); ?>" class='user-image' alt='User Image'/>  
                    <span class='hidden-xs'><?php echo $user_first_name ?></span>
                    <i class='fa fa-caret-down' aria-hidden='true'></i>
              </a>
    <ul class='dropdown-menu'>
                <li class='user-header clearfix'>
                    <div class='user-figure'><img src="<?php echo get_profile_img($img_url) ?>&cd=<?php echo rand(); ?>" class='img-circle' alt='User Image'></div>
                    <div class='user-info'><p> <?php echo $user_first_name." " .@$user_middle_name." ".$user_last_name ?></p><small><?php echo $job_title ?></small>
                    </div>
                </li>
                <li class='user-footer clearfix'>
                    <ul class='menu'>
                        <li>
                            <a href="<?php echo $base_url.'/my-profile' ?>">Profile</a>
                        </li>
                        <li>
                            <a href="<?php echo $base_url.'/user/'.$user->uid.'/edit' ?>">Edit Profile</a>
                        </li>
                        <li>
                            <a href="<?php echo $base_url.'/user/logout'; ?>">Sign out</a>
                        </li>
                    </ul>
                </li>
            </ul>
         </ul>