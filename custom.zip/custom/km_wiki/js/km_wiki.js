(function ($) {
	Drupal.behaviors.km_wiki = {
	    attach: function (context, settings) {
	    	$(document).ready(function() {
	    		$('.book-explorer .book-block-menu').find( 'ul' ).addClass('menu');
	    	});
	    }
    }
})(jQuery);