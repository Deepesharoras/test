(function ($) {
	Drupal.behaviors.km_wiki_form = {
	    attach: function (context, settings) {
	    	$('#edit-field-wiki-wiki-type-und-public').click(function() {
	    		$('#edit-og-group-ref').hide();
	    		$('#edit-field-wiki-read-access').show();
	    		$('#edit-field-wiki-read-members').show();
	    		$('#edit-field-wiki-edit-access').show();
    			$('#edit-field-field-wiki-edit-comm-acce').hide();
    			$('#edit-field-wiki-edit-members').hide();
    			if( true == $('#edit-field-wiki-read-access-und-all-users').is(':checked') ) {
    				$('#edit-field-wiki-read-members').hide();
    			}
	    	});
	    	$('#edit-field-wiki-wiki-type-und-community').click(function() {
	    		$('#edit-og-group-ref').show();
	    		$('#edit-field-wiki-read-access').hide();
	    		$('#edit-field-wiki-read-members').hide();
	    		$('#edit-field-wiki-edit-access').hide();
    			$('#edit-field-field-wiki-edit-comm-acce').show();
    			if( true == $('#edit-field-field-wiki-edit-comm-acce-und-wiki-members').is(':checked') ) {
    				$('#edit-field-wiki-edit-members').show();
    			}
	    	});
	    	$('#edit-field-wiki-read-access-und-all-users').click(function() {
	    		$('#edit-field-wiki-edit-access-und-all-users').removeAttr( 'disabled', 'disabled' );
	    		$('#edit-field-wiki-edit-access-und-wiki-only').removeAttr( 'checked' );
	    		$('#edit-field-wiki-edit-access-und-all-users').prop("checked", true);
	    		$('#edit-field-wiki-edit-members').hide();
	    		$('#edit-field-wiki-read-members').hide();
	    	});
	    	$('#edit-field-wiki-read-access-und-wiki-members-only').click(function() {
	    		$('#edit-field-wiki-edit-access-und-all-users').attr( 'disabled', 'disabled' );
	    		$('#edit-field-wiki-edit-access-und-all-users').removeAttr( 'checked' );
	    		$('#edit-field-wiki-edit-access-und-wiki-only').prop("checked", true);
	    		$('#edit-field-wiki-edit-members').show();
	    		$('#edit-field-wiki-read-members').show();
	    	});
	    	$('#edit-field-wiki-edit-access-und-wiki-only').click(function() {
	    		$('#edit-field-wiki-edit-members').show();
	    	});
	    	$('#edit-field-wiki-edit-access-und-all-users').click(function() {
	    		$('#edit-field-wiki-edit-members').hide();
	    	});
	    	$('#edit-field-field-wiki-edit-comm-acce-und-wiki-members').click(function() {
	    		$('#edit-field-wiki-edit-members').show();
	    	});
	    	$('#edit-field-field-wiki-edit-comm-acce-und-all-comm-users').click(function() {
	    		$('#edit-field-wiki-edit-members').hide();
	    	});

	    	$(document).ready(function() {
	    		if( true == $('#edit-field-wiki-wiki-type-und-public').is(':checked') ) {
	    			$('#edit-og-group-ref').hide();
	    			$('#edit-field-field-wiki-edit-comm-acce').hide();
	    			$('#edit-field-wiki-read-members').hide();
		    		if( true == $('#edit-field-wiki-read-access-und-wiki-members-only').is(':checked') ) {
			    		$('#edit-field-wiki-edit-access-und-all-users').attr( 'disabled', 'disabled' );
		    			$('#edit-field-wiki-read-members').show();
		    		}
		    		if( true == $('#edit-field-wiki-read-access-und-all-users').is(':checked') ) {
		    			$('#edit-field-wiki-edit-members').hide();
		    		}
	    		}
	    		if( true == $('#edit-field-wiki-wiki-type-und-community').is(':checked') ) {
		    		$('#edit-field-wiki-read-access').hide();
		    		$('#edit-field-wiki-read-members').hide();
		    		$('#edit-field-wiki-edit-access').hide();
	    			$('#edit-field-field-wiki-edit-comm-acce').show();
	    			if( true == $('#edit-field-field-wiki-edit-comm-acce-und-all-comm-users').is(':checked') ) {
	    				$('#edit-field-wiki-edit-members').hide();
	    			}
	    			if( true == $('#edit-field-field-wiki-edit-comm-acce-und-wiki-members').is(':checked') ) {
		    			$('#edit-field-wiki-edit-members').show();
		    		}
	    		}
	    	});
	    }
	}
})(jQuery);